# Lz Overlays

Requires Fusion mod v1.2.0+ from https://www.curseforge.com/minecraft/mc-mods/fusion-connected-textures


For versions with different requirements, or for other minecraft versions, go to 

https://legacy.curseforge.com/minecraft/texture-packs/lz-block-overlays



