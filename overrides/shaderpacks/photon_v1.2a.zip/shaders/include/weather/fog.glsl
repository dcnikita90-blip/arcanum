#if !defined INCLUDE_WEATHER_FOG
#define INCLUDE_WEATHER_FOG

#include "/include/fog/overworld/parameters.glsl"
#include "/include/utility/color.glsl"
#include "/include/weather/core.glsl"

uniform float biome_pale_garden;

float get_winter_biome_factor() {
	float cold_temperature = clamp01((0.10 - biome_temperature) * 3.5);
	return max(max(biome_snowy, biome_may_snow), cold_temperature);
}

vec3 get_biome_foliage_fog_tint() {
	const vec3 tint_temperate   = vec3(0.34, 0.58, 0.22);
	const vec3 tint_arid        = vec3(0.60, 0.54, 0.22);
	const vec3 tint_snowy       = vec3(0.38, 0.54, 0.34);
	const vec3 tint_taiga       = vec3(0.22, 0.40, 0.20);
	const vec3 tint_jungle      = vec3(0.14, 0.56, 0.14);
	const vec3 tint_swamp       = vec3(0.34, 0.44, 0.14);
	const vec3 tint_pale_garden = vec3(0.58, 0.58, 0.50);
	const vec3 tint_winter_leaf = vec3(0.34, 0.50, 0.30);

	vec3 tint = tint_temperate   * biome_temperate
	          + tint_arid        * biome_arid
	          + tint_snowy       * biome_snowy
	          + tint_taiga       * biome_taiga
	          + tint_jungle      * biome_jungle
	          + tint_swamp       * biome_swamp
	          + tint_pale_garden * biome_pale_garden;

	vec3 climate_tint = mix(
		vec3(0.64, 0.56, 0.24),
		vec3(0.20, 0.58, 0.18),
		clamp01(0.45 * biome_temperature + 0.55 * biome_humidity)
	);

	float winter_factor = get_winter_biome_factor();

	tint = mix(tint, tint_winter_leaf, 0.78 * winter_factor);
	return mix(tint, climate_tint, 0.25 * (1.0 - 0.85 * winter_factor));
}

OverworldFogParameters get_fog_parameters(Weather weather) {
	OverworldFogParameters params;

	// Rayleigh coefficient

	const vec3 rayleigh_normal      = from_srgb(vec3(AIR_FOG_RAYLEIGH_R,        AIR_FOG_RAYLEIGH_G,        AIR_FOG_RAYLEIGH_B       )) * AIR_FOG_RAYLEIGH_DENSITY;
	const vec3 rayleigh_rain        = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_RAIN,   AIR_FOG_RAYLEIGH_G_RAIN,   AIR_FOG_RAYLEIGH_B_RAIN  )) * AIR_FOG_RAYLEIGH_DENSITY_RAIN;
	const vec3 rayleigh_arid        = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_ARID,   AIR_FOG_RAYLEIGH_G_ARID,   AIR_FOG_RAYLEIGH_B_ARID  )) * AIR_FOG_RAYLEIGH_DENSITY_ARID; 
	const vec3 rayleigh_snowy       = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_SNOWY,  AIR_FOG_RAYLEIGH_G_SNOWY,  AIR_FOG_RAYLEIGH_B_SNOWY )) * AIR_FOG_RAYLEIGH_DENSITY_SNOWY;
	const vec3 rayleigh_taiga       = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_TAIGA,  AIR_FOG_RAYLEIGH_G_TAIGA,  AIR_FOG_RAYLEIGH_B_TAIGA )) * AIR_FOG_RAYLEIGH_DENSITY_TAIGA;
	const vec3 rayleigh_jungle      = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_JUNGLE, AIR_FOG_RAYLEIGH_G_JUNGLE, AIR_FOG_RAYLEIGH_B_JUNGLE)) * AIR_FOG_RAYLEIGH_DENSITY_JUNGLE;
	const vec3 rayleigh_swamp       = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_SWAMP,  AIR_FOG_RAYLEIGH_G_SWAMP,  AIR_FOG_RAYLEIGH_B_SWAMP )) * AIR_FOG_RAYLEIGH_DENSITY_SWAMP;
	const vec3 rayleigh_pale_garden = from_srgb(vec3(AIR_FOG_RAYLEIGH_R_PALE_GARDEN,  AIR_FOG_RAYLEIGH_G_PALE_GARDEN,  AIR_FOG_RAYLEIGH_B_PALE_GARDEN )) * AIR_FOG_RAYLEIGH_DENSITY_PALE_GARDEN;
	const vec3 rayleigh_winter_leaf = from_srgb(vec3(0.34, 0.50, 0.30)) * 0.0031;

	params.rayleigh_scattering_coeff 
		= rayleigh_normal * biome_temperate
		+ rayleigh_arid   * biome_arid
	    + rayleigh_snowy  * biome_snowy
		+ rayleigh_taiga  * biome_taiga
		+ rayleigh_jungle * biome_jungle
		+ rayleigh_swamp  * biome_swamp
		+ rayleigh_pale_garden * biome_pale_garden;

	float winter_factor = get_winter_biome_factor();
	params.rayleigh_scattering_coeff = mix(
		params.rayleigh_scattering_coeff,
		rayleigh_winter_leaf,
		0.82 * winter_factor
	);

	// rain
	params.rayleigh_scattering_coeff = mix(
		params.rayleigh_scattering_coeff * (1.0 + weather.humidity * weather.temperature), 
		rayleigh_rain, 
		rainStrength * biome_may_rain
	);

	// Mie coefficient

	// Increased mie density and scattering strength during late sunset / blue hour
	float blue_hour = linear_step(0.05, 1.0, exp(-190.0 * sqr(sun_dir.y + 0.07283)));

	float mie 
		= AIR_FOG_MIE_DENSITY_MORNING   * time_sunrise
		+ AIR_FOG_MIE_DENSITY_NOON      * time_noon
		+ AIR_FOG_MIE_DENSITY_EVENING   * time_sunset
		+ AIR_FOG_MIE_DENSITY_MIDNIGHT  * time_midnight
		+ AIR_FOG_MIE_DENSITY_BLUE_HOUR * blue_hour;

	// Weather influence
	mie = mix(
		mie + 8.0 * AIR_FOG_MIE_DENSITY_NOON * sqr(clamp01(weather.humidity * rcp(0.8))), 
		AIR_FOG_MIE_DENSITY_RAIN, 
		rainStrength * biome_may_rain
	);
	mie = mix(mie, AIR_FOG_MIE_DENSITY_SNOW, rainStrength * biome_may_snow);

	float mie_albedo = mix(0.9, 0.5, rainStrength * biome_may_rain);
	params.mie_scattering_coeff = vec3(mie_albedo * mie);
	params.mie_extinction_coeff = vec3(mie);

#ifdef DESERT_SANDSTORM
	const float desert_sandstorm_density    = 0.2;
	const float desert_sandstorm_scattering = desert_sandstorm_density * 0.5;
	const vec3  desert_sandstorm_extinction = desert_sandstorm_density * vec3(0.2, 0.27, 0.45);

	params.mie_scattering_coeff += desert_sandstorm * desert_sandstorm_scattering;
	params.mie_extinction_coeff += desert_sandstorm * desert_sandstorm_extinction;
#endif

	params.biome_tint = get_biome_foliage_fog_tint();

	return params;
}

#endif // INCLUDE_WEATHER_FOG
