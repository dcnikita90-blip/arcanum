
const float ambientOcclusionLevel = 0.0;

#include "/settings.glsl"
#include "/include/waving.glsl"
#include "/include/hovering.glsl"
#include "/include/shadow.glsl"

out vec2 texcoord;
out vec4 glcolor;
out float viewDistance;
out float outlineMask;
out float skylight;
out float blocklight;
flat out float emissive;
flat out float emissiveType;
out vec3 worldPos;
flat out float isGrassGeometry;  // Flat to prevent interpolation artifacts
flat out float isHeatSource;
flat out float isHologram;
flat out float metalness;  // 0 = non-metal, 1 = metal, 2 = gem
flat out float reflective; // 1.0 = reflective material (SSR)
out vec4 shadowPos;  // xyz = shadow screen pos (after distortion), w = lightDot
out vec3 normal;
flat out vec3 geoNormal;  // Flat geometric normal for shadow bias
flat out float blockId;    // Block ID for connected texture detection
out float leafAO;          // Reserved for future use
#ifdef PBR_ENABLED
out vec3 tangentVec;       // Tangent vector for TBN matrix (view space)
out vec3 binormalVec;      // Binormal/bitangent vector for TBN matrix (view space)
#endif

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
attribute vec4 at_midBlock;
#ifdef PBR_ENABLED
attribute vec4 at_tangent;
#endif

void main() {
	// Initialize shadow position
	shadowPos = vec4(0.0);
	
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	outlineMask = 1.0;

	float maxChannel = max(max(gl_Color.r, gl_Color.g), gl_Color.b);
	vec3 flatColor = (maxChannel > 0.001) ? (gl_Color.rgb / maxChannel) : gl_Color.rgb;

	skylight = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);
	blocklight = clamp(gl_MultiTexCoord1.x / 240.0, 0.0, 1.0);
	
	vec2 uv = texcoord;
	bool is_top_vertex = uv.y < mc_midTexCoord.y;
	
	int block_id_raw = int(mc_Entity.x);
	bool has_block_properties_id = (block_id_raw >= 10000);
	int block_id = has_block_properties_id ? (block_id_raw - 10000) : 0;
	blockId = float(block_id_raw);  // Pass raw block ID to fragment shader

	if (has_block_properties_id) {
		#ifdef GRASS_3D_RP_MODE
		bool is_outline_blacklisted = (block_id == 2 || block_id == 3 || block_id == 4 || block_id == 5 || block_id == 15 || block_id == 18 || block_id == 19);
		#else
		bool is_outline_blacklisted = (block_id == 2 || block_id == 3 || block_id == 4 || block_id == 5 || block_id == 18 || block_id == 19);
		#endif
		if (is_outline_blacklisted) {
			outlineMask = 0.0;
		}
		// Emissive blocks: 10020-10031 (original emissives) AND 10032-10063 (LPV light sources)
		// Also include lanterns (block_id 6)
		bool is_emissive = (block_id >= 20 && block_id <= 63) || block_id == 6;
		emissive = is_emissive ? 1.0 : 0.0;
		emissiveType = float(block_id - 20);
		
		// Heat sources: campfire (20), soul campfire (21), lava/fire (22),
		// torch/wall_torch family (36), and LPV lava/fire aliases (39/40).
		bool is_heat = (block_id == 20 || block_id == 21 || block_id == 22 || block_id == 36 || block_id == 39 || block_id == 40);
		isHeatSource = is_heat ? 1.0 : 0.0;

		// Glass block IDs: 14 (glass), 64-79 (colored glass for LPV), 80 (hologram glass)
		bool isGlass = (block_id == 14 || block_id == 80 || (block_id >= 64 && block_id <= 79));
		isHologram = isGlass ? 1.0 : 0.0;
		
		// Metalness: 12 = metals (iron, gold, copper, netherite), 13 = gems (diamond, emerald, etc.)
		if (block_id == 12) {
			metalness = 1.0; // Metal blocks
		} else if (block_id == 13) {
			metalness = 2.0; // Gem blocks
		} else {
			metalness = 0.0;
		}

		// Reflective materials: 17 = polished/smooth/glazed, 12 = metals, 13 = gems
		reflective = (block_id == 17 || block_id == 12 || block_id == 13) ? 1.0 : 0.0;
	} else {
		// No block.properties ID - cannot reliably detect emissive
		// NOTE: Do NOT use blocklight to detect emissive - that detects LIT surfaces, not LIGHT SOURCES
		emissive = 0.0;
		emissiveType = 0.0;
		isHeatSource = 0.0;
		isHologram = 0.0;
		metalness = 0.0;
		reflective = 0.0;
	}

	glcolor = vec4(flatColor, gl_Color.a);
	leafAO = 0.0;

	bool should_wave = false;
	#ifdef WAVING_PLANTS
	should_wave = should_wave || (block_id == 2 || block_id == 3 || block_id == 4);
	#ifdef GRASS_3D_RP_MODE
	should_wave = should_wave || (block_id == 15);
	#endif
	#endif
	#ifdef WAVING_LEAVES
	should_wave = should_wave || (block_id == 5);
	#endif
	#ifdef SWAYING_LANTERNS
	should_wave = should_wave || (block_id == 6);
	#endif

	should_wave = should_wave && has_block_properties_id;

	// Get normals
	normal = normalize(gl_NormalMatrix * gl_Normal);
	geoNormal = normal;  // Geometric normal (flat, no interpolation)
	#ifdef PBR_ENABLED
	tangentVec = normalize(gl_NormalMatrix * at_tangent.xyz);
	binormalVec = normalize(cross(normal, tangentVec) * at_tangent.w);
	#endif

	if (!should_wave) {
		vec3 view_pos = (gl_ModelViewMatrix * gl_Vertex).xyz;
		vec3 scene_pos = (gbufferModelViewInverse * vec4(view_pos, 1.0)).xyz;
		vec3 world_pos_temp = scene_pos + cameraPosition;
		
		// Apply hovering zone offset - ALWAYS use custom transform to ensure consistency
		float hoverOffset = getHoverOffset(world_pos_temp);
		world_pos_temp.y += hoverOffset;
		scene_pos = world_pos_temp - cameraPosition;
		view_pos = (gbufferModelView * vec4(scene_pos, 1.0)).xyz;
		gl_Position = gl_ProjectionMatrix * vec4(view_pos, 1.0);
		
		worldPos = world_pos_temp;
		viewDistance = length(view_pos);
		
		// Check if this is thin foliage GEOMETRY (cross-shaped grass, flowers)
		// Block IDs 2,3,4,15 can have thin foliage, but we need to check the geometry
		// Thin foliage has diagonal normals (not axis-aligned), solid blocks have axis-aligned normals
		bool isFoliageBlock = has_block_properties_id && (block_id == 2 || block_id == 3 || block_id == 4 || block_id == 15);
		vec3 n = abs(gl_Normal);
		float maxAxis = max(max(n.x, n.y), n.z);
		bool isAxisAligned = maxAxis > 0.95;
		bool isThinFoliage = isFoliageBlock && !isAxisAligned;
		#ifdef GRASS_3D_RP_MODE
		isGrassGeometry = isThinFoliage ? 1.0 : 0.0;
		#else
		isGrassGeometry = (isThinFoliage && block_id != 15) ? 1.0 : 0.0;
		#endif
		
		// Calculate shadow (per tutorial - compute in vertex shader)
		#ifdef SHADOWS_ENABLED
		float lightDot = dot(normalize(shadowLightPosition), normalize(gl_NormalMatrix * gl_Normal));
		// Foliage/leaves/crops/bushes: always face sun (don't darken back faces)
		// block_id 2 = small plants, bushes, crops
		// block_id 81 = bamboo (no face shading, but does cast shadows)
		if (isThinFoliage || block_id == 5 || block_id == 2 || block_id == 18 || block_id == 19 || block_id == 81) lightDot = 1.0;

		// Always compute shadow position (fragment shader decides whether to use it)
		// This allows zenith-time shadows to work on back-facing surfaces
		{
			// Transform to shadow clip space
			vec4 shadowClipPos4 = shadowProjection * shadowModelView * vec4(scene_pos, 1.0);
			vec3 shadowClipPosXYZ = shadowClipPos4.xyz;
			
			// Compute bias BEFORE distortion
			float bias = computeBias(shadowClipPosXYZ);
			
			// Apply distortion
			vec3 distorted = distortShadowClipPos(shadowClipPosXYZ);
			
			// Convert to screen space [0,1]
			shadowPos.xyz = distorted * 0.5 + 0.5;
			
			// Normal bias (per tutorial): project normal to shadow space and offset
			vec4 normal = shadowProjection * vec4(mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal)), 1.0);
			shadowPos.xyz += normal.xyz / normal.w * bias;
		}
		shadowPos.w = lightDot;
		#endif
		return;
	}

	vec3 view_pos = (gl_ModelViewMatrix * gl_Vertex).xyz;
	vec3 scene_pos = (gbufferModelViewInverse * vec4(view_pos, 1.0)).xyz;
	vec3 world_pos = scene_pos + cameraPosition;

	#ifdef WAVING_PLANTS
	// Thin foliage blocks: 2=flowers, 3=saplings, 4=crops, 15=short grass
	bool isFoliageBlock = (block_id == 2 || block_id == 3 || block_id == 4 || block_id == 15);
	// Detect thin foliage GEOMETRY by normal - thin foliage has diagonal normals
	vec3 n = abs(gl_Normal);
	float maxAxis = max(max(n.x, n.y), n.z);
	bool isAxisAligned = maxAxis > 0.95;
	bool isThinFoliage = isFoliageBlock && !isAxisAligned;
	if (block_id == 15) {
		vec3 world_pos_animated = animate_vertex(world_pos, is_top_vertex, skylight, block_id, at_midBlock.xyz);
		vec3 n = normalize(gl_Normal);
		float horiz = 1.0 - step(0.2, abs(n.y));
		float axis_aligned = step(0.98, max(abs(n.x), abs(n.z)));
		float rotated_blade_mask = horiz * (1.0 - axis_aligned);
		
		if (rotated_blade_mask > 0.5) {
			world_pos = world_pos_animated;
		}
	} else {
		world_pos = animate_vertex(world_pos, is_top_vertex, skylight, block_id, at_midBlock.xyz);
	}
	#ifdef GRASS_3D_RP_MODE
	isGrassGeometry = isThinFoliage ? 1.0 : 0.0;
	#else
	isGrassGeometry = (isThinFoliage && block_id != 15) ? 1.0 : 0.0;
	#endif
	#else
	world_pos = animate_vertex(world_pos, is_top_vertex, skylight, block_id, at_midBlock.xyz);
	// Still mark thin foliage for shadow skipping even without waving
	// Detect by geometry (diagonal normals) not just block_id
	bool isFoliageBlock2 = (block_id == 2 || block_id == 3 || block_id == 4 || block_id == 15);
	vec3 n2 = abs(gl_Normal);
	float maxAxis2 = max(max(n2.x, n2.y), n2.z);
	bool isAxisAligned2 = maxAxis2 > 0.95;
	bool isThinFoliage2 = isFoliageBlock2 && !isAxisAligned2;
	#ifdef GRASS_3D_RP_MODE
	isGrassGeometry = isThinFoliage2 ? 1.0 : 0.0;
	#else
	isGrassGeometry = (isThinFoliage2 && block_id != 15) ? 1.0 : 0.0;
	#endif
	#endif

	// Apply hovering zone offset (after waving animation)
	float hoverOffset = getHoverOffset(world_pos);
	world_pos.y += hoverOffset;
	scene_pos = world_pos - cameraPosition;
	view_pos = (gbufferModelView * vec4(scene_pos, 1.0)).xyz;

	gl_Position = gl_ProjectionMatrix * vec4(view_pos, 1.0);
	viewDistance = length(view_pos);
	worldPos = world_pos;
	
	// Calculate shadow (per tutorial - compute in vertex shader)
	#ifdef SHADOWS_ENABLED
	float lightDot = dot(normalize(shadowLightPosition), normalize(gl_NormalMatrix * gl_Normal));
	// Foliage/leaves/crops/bushes/grass blades: always face sun (don't darken back faces)
	// block_id 15 = grass block (3D blades), block_id 81 = bamboo
	if (isGrassGeometry > 0.5 || block_id == 5 || block_id == 2 || block_id == 15 || block_id == 19 || block_id == 81) lightDot = 1.0;
	
	// Always compute shadow position (fragment shader decides whether to use it)
	// This allows zenith-time shadows to work on back-facing surfaces
	{
		// Transform to shadow clip space
		vec4 shadowClipPos4 = shadowProjection * shadowModelView * vec4(scene_pos, 1.0);
		vec3 shadowClipPosXYZ = shadowClipPos4.xyz;
		
		// Compute bias BEFORE distortion
		float bias = computeBias(shadowClipPosXYZ);
		
		// Apply distortion
		vec3 distorted = distortShadowClipPos(shadowClipPosXYZ);
		
		// Convert to screen space [0,1]
		shadowPos.xyz = distorted * 0.5 + 0.5;
		
		// Normal bias (per tutorial): project normal to shadow space and offset
		vec4 normal = shadowProjection * vec4(mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal)), 1.0);
		shadowPos.xyz += normal.xyz / normal.w * bias;
	}
	shadowPos.w = lightDot;
	#endif
}
