/* RENDERTARGETS: 0,1,3,4,5 */

#include "/settings.glsl"
#include "/include/hovering.glsl"
#include "/include/water_waves.glsl"
#include "/include/water_color.glsl"

uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjectionInverse;
uniform mat4 dhProjectionInverse;
uniform mat4 gbufferModelView;
uniform vec3 shadowLightPosition;
uniform float far;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform float sunAngle;
uniform int isEyeInWater;

in vec4 vColor;
in float viewDistance;
in vec3 viewPos;
in vec3 worldPos;
in vec3 normal;
flat in int materialId;

// Returns view-space normal for DH water waves (computed per-fragment, LOD independent)
vec3 getDhWaterNormalView(vec3 wPos, vec3 baseNormalView) {
	#ifdef WATER_WAVES_ENABLED
	if (materialId == DH_BLOCK_WATER) {
		vec3 wN = waterCalcWaveNormal(wPos.xz, frameTimeCounter);
		return normalize(mat3(gbufferModelView) * wN);
	}
	#endif
	return baseNormalView;
}

// Returns world-space normal for packing (0,1,0 for non-water)
vec3 getDhWaterNormalWorld(vec3 wPos) {
	#ifdef WATER_WAVES_ENABLED
	if (materialId == DH_BLOCK_WATER) {
		return waterCalcWaveNormal(wPos.xz, frameTimeCounter);
	}
	#endif
	return vec3(0.0, 1.0, 0.0);
}

float interleaved_gradient_noise(vec2 v) {
	return fract(52.9829189 * fract(0.06711056 * v.x + 0.00583715 * v.y));
}

void main() {
	vec4 color = vColor;

	bool isWater = (materialId == DH_BLOCK_WATER);

	// Discard DH water surface when underwater — final.fsh underwater fog handles the visuals.
	if (isWater && isEyeInWater == 1) {
		discard;
	}
	if (isWater) {
		// Base color: DH biome tint — match MC water base (glcolor.rgb * 0.85)
		vec3 waterColorSetting = vColor.rgb * 0.85;

		// Lighting
		color.rgb = waterLitColor(waterColorSetting, sunAngle);

		// --- Color grading (DH_WATER_* constants — edit in water_color.glsl) ---
		color.rgb *= DH_WATER_EXPOSURE;
		{
			float cMid = dot(color.rgb, vec3(0.299, 0.587, 0.114));
			color.rgb = (color.rgb - cMid) * DH_WATER_CONTRAST + cMid;
		}
		{
			float cLum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
			color.rgb = mix(vec3(cLum), color.rgb, WATER_SATURATION * DH_WATER_SATURATION);
		}
		{
			float cLum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
			float maxC = max(max(color.rgb.r, color.rgb.g), color.rgb.b);
			float sat = (maxC > 0.001) ? (maxC - min(min(color.rgb.r, color.rgb.g), color.rgb.b)) / maxC : 0.0;
			color.rgb = mix(color.rgb, vec3(cLum) + (color.rgb - vec3(cLum)) * (1.0 + DH_WATER_VIBRANCE * (1.0 - sat)), 1.0);
		}
		color.rgb = pow(max(color.rgb, vec3(0.0)), vec3(DH_WATER_GAMMA));
		color.rgb = (color.rgb - DH_WATER_BLACK_POINT) / max(DH_WATER_WHITE_POINT - DH_WATER_BLACK_POINT, 0.001);
		color.rgb *= DH_WATER_TINT * DH_WATER_BRIGHTNESS;
		color.rgb = max(color.rgb, vec3(0.0));

		// Opacity
		if (isEyeInWater == 1) {
			color.a = DH_WATER_OPACITY * UNDERWATER_SURFACE_VISIBILITY;
		} else {
			color.a = DH_WATER_OPACITY;
		}

		// Specular (shared formula, above water only)
		if (isEyeInWater != 1) {
			vec3 viewDir = normalize(-viewPos);
			vec3 sunDir = normalize(shadowLightPosition);
			vec3 waterNormalView = getDhWaterNormalView(worldPos, normal);
			color.rgb += waterSpecular(viewDir, sunDir, waterNormalView, sunAngle);
		}

		// NOTE: Sky reflections handled in composite7.fsh (no extra fresnel tint here)
	} else {
		// Non-water: apply DH brightness
		color.rgb *= DH_BRIGHTNESS;
	}

	// Discard DH geometry when MC geometry is present at the same pixel.
	ivec2 pixel = ivec2(gl_FragCoord.xy);
	float mcDepth = texelFetch(depthtex0, pixel, 0).r;
	float mcOpaqueDepth = texelFetch(depthtex1, pixel, 0).r;
	if (isWater) {
		// For DH water: discard whenever MC has any geometry (opaque or translucent) at
		// this pixel. MC water always takes priority over DH water. DH water only renders
		// where MC hasn't drawn anything (beyond MC render distance).
		if (mcDepth < 1.0) {
			discard;
		}
	} else {
		// For non-water DH geometry: discard when MC opaque geometry is present.
		if (mcOpaqueDepth < 1.0) {
			vec2 texSize = vec2(textureSize(depthtex1, 0));
			vec2 uv = (gl_FragCoord.xy + vec2(0.5)) / texSize;

			vec4 mcClip = vec4(uv * 2.0 - 1.0, mcOpaqueDepth * 2.0 - 1.0, 1.0);
			vec4 mcView = gbufferProjectionInverse * mcClip;
			float mcDist = -mcView.z / mcView.w;

			vec4 dhClip = vec4(uv * 2.0 - 1.0, gl_FragCoord.z * 2.0 - 1.0, 1.0);
			vec4 dhView = dhProjectionInverse * dhClip;
			float dhDist = -dhView.z / dhView.w;

			if (mcDist + 1e-4 < dhDist) {
				discard;
			}
		}
	}

	// Fade out DH near vanilla render distance to avoid seams.
	// Water is exempt: MC and DH use the same color, and the MC depth test
	// above already prevents overlap. No dither/fade needed.
	if (!isWater) {
		float fade_start = max(far - DH_OVERDRAW_DISTANCE - DH_OVERDRAW_FADE_LENGTH, 0.0);
		float fade_end = max(far - DH_OVERDRAW_DISTANCE, 0.0);
		float fade = smoothstep(fade_start, fade_end, viewDistance);
		float dither = interleaved_gradient_noise(gl_FragCoord.xy + float(frameCounter));
		if (dither > fade) {
			discard;
		}
	}

	float emissive = 0.0;
	vec3 lightColor = vec3(0.0);

	// Detect ice-like blocks by color
	vec3 testColor = vColor.rgb;
	float maxC = max(max(testColor.r, testColor.g), testColor.b);
	float minC = min(min(testColor.r, testColor.g), testColor.b);
	float saturation = (maxC > 0.01) ? (maxC - minC) / maxC : 0.0;
	bool isIceLike = (testColor.b > testColor.r * 1.2) && (testColor.b > testColor.g * 1.1) && (maxC > 0.4) && (saturation < 0.45);

	bool isSlimeLike = false;
	bool isGlass = !isWater && !isIceLike;

	// Ice: apply shared water lighting (same formula)
	if (isIceLike) {
		color.rgb = waterLitColor(color.rgb, sunAngle);
	}

	if (isGlass) {
		// Glass - apply time-of-day lighting
		vec3 glassColor = vColor.rgb;
		float brightness = dot(glassColor, vec3(0.299, 0.587, 0.114));
		vec3 saturatedColor = mix(vec3(brightness), glassColor, 3.0);
		saturatedColor = max(saturatedColor, vec3(0.0));
		float maxC2 = max(max(saturatedColor.r, saturatedColor.g), saturatedColor.b);
		if (maxC2 > 0.01) {
			saturatedColor = saturatedColor / maxC2 * max(brightness * 2.0, 0.4);
		} else {
			saturatedColor = vec3(0.4, 0.6, 0.8);
		}
		color.rgb = waterLitColor(saturatedColor, sunAngle);
		color.a = max(color.a, 0.5);
	}

	gl_FragData[0] = color;
	gl_FragData[1] = vec4(1.0, emissive, 1.0, 1.0);
	gl_FragData[2] = vec4(lightColor, 1.0);

	// Glass tint for color filtering
	if (isGlass) {
		float tintStrength = 0.6;
		gl_FragData[3] = vec4(vColor.rgb, tintStrength);
	} else {
		gl_FragData[3] = vec4(0.0);
	}

	// Output water data for reflections (colortex5)
	#ifdef WATER_REFLECTIONS_ENABLED
	if (isWater) {
		float packedLmcoord = dot(floor(255.0 * vec2(0.0, 1.0) + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
		float packedReflect = dot(floor(255.0 * vec2(WATER_REFLECTION_AMOUNT, 0.0) + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
		vec3 worldNormal = getDhWaterNormalWorld(worldPos);
		vec3 encodedNormal = worldNormal * 0.5 + 0.5;
		gl_FragData[4] = vec4(packedLmcoord, packedReflect, encodedNormal.x, encodedNormal.y);
	} else {
		gl_FragData[4] = vec4(0.0);
	}
	#else
	gl_FragData[4] = vec4(0.0);
	#endif
}
