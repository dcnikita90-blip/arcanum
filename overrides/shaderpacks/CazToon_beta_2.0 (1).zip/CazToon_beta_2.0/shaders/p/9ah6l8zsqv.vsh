
out vec3 viewPos;
out vec4 starColor;

void main() {
    gl_Position = ftransform();
    // Sky direction must ignore camera translation to avoid parallax/drifting layers.
    viewPos = (mat3(gl_ModelViewMatrix) * gl_Vertex.xyz);
    // Pass vertex color - used to detect vanilla stars
    starColor = gl_Color;
}
