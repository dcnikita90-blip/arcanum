/* RENDERTARGETS: 0,2,3 */

// Composite pass 0: Extract emissive for bloom + End sky rendering

#include "/settings.glsl"

#ifdef END_SHADER
#include "/include/end_sky.glsl"
#endif

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
uniform sampler2D dhDepthTex;

uniform float sunAngle;
uniform float near;
uniform float far;
uniform float dhNearPlane;
uniform float dhFarPlane;

#ifdef END_SHADER
uniform float frameTimeCounter;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
#endif

in vec2 texcoord;

float linearizeDepth(float depth) {
    return (near * far) / (depth * (near - far) + far);
}

float linearizeDepthDH(float depth) {
    return (dhNearPlane * dhFarPlane) / (depth * (dhNearPlane - dhFarPlane) + dhFarPlane);
}

// Get combined linear depth from MC and DH
float getCombinedLinearDepth(vec2 coord) {
    float depthMC = texture(depthtex0, coord).r;
    float depthDH = texture(dhDepthTex, coord).r;

    // If MC depth is at far plane, use DH depth
    if (depthMC >= 0.9999 && depthDH < 0.9999) {
        return linearizeDepthDH(depthDH);
    }
    return linearizeDepth(depthMC);
}

// Get emissive light color from type (duplicated from gbuffers_terrain.fsh)
vec3 getEmissiveLightColor(float type) {
    int t = int(type + 0.5);
    // Original emissive IDs (10020-10031, type 0-11)
    if (t == 0)  return vec3(1.0, 0.7, 0.4);   // Torch, lantern, campfire
    if (t == 1)  return vec3(0.3, 0.8, 1.0);   // Soul torch, soul campfire
    if (t == 2)  return vec3(1.0, 0.4, 0.1);   // Lava, fire
    if (t == 3)  return vec3(1.0, 0.85, 0.5);  // Glowstone
    if (t == 4)  return vec3(0.6, 0.9, 1.0);   // Sea lantern
    if (t == 5)  return vec3(1.0, 0.6, 0.3);   // Shroomlight
    if (t == 6)  return vec3(1.0, 0.2, 0.1);   // Redstone torch
    if (t == 7)  return vec3(1.0, 0.85, 0.3);  // Ochre froglight
    if (t == 8)  return vec3(0.5, 1.0, 0.4);   // Verdant froglight
    if (t == 9)  return vec3(1.0, 0.6, 0.9);   // Pearlescent froglight
    if (t == 10) return vec3(1.0, 1.0, 1.0);   // Light block (white)
    if (t == 11) return vec3(1.0, 1.0, 1.0);   // End rod (white)
    
    // LPV emissive IDs (10032-10063, type 12-43)
    if (t == 12) return vec3(0.6, 0.9, 1.0);   // Sea lantern (strong white-blue)
    if (t == 13) return vec3(1.0, 1.0, 1.0);   // End rod (medium white)
    if (t == 14) return vec3(0.8, 1.0, 0.9);   // Glow lichen (weak white-green)
    if (t == 15) return vec3(1.0, 0.85, 0.5);  // Glowstone, lantern (strong golden)
    if (t == 16) return vec3(1.0, 0.7, 0.4);   // Torch, campfire (medium golden)
    if (t == 17) return vec3(1.0, 0.7, 0.4);   // Cave vines (weak golden)
    if (t == 18) return vec3(1.0, 0.2, 0.1);   // Redstone components
    if (t == 19) return vec3(1.0, 0.45, 0.1);  // Lava
    if (t == 20) return vec3(1.0, 0.5, 0.15);  // Fire, magma, shroomlight
    if (t == 21) return vec3(1.0, 0.75, 0.2);  // Brewing stand
    if (t == 22) return vec3(1.0, 0.7, 0.4);   // Jack o' Lantern
    if (t == 23) return vec3(0.45, 0.73, 1.0); // Soul lights
    if (t == 24) return vec3(0.45, 0.73, 1.0); // Beacon
    if (t == 25) return vec3(0.75, 1.0, 0.83); // End portal frame
    if (t == 26) return vec3(0.3, 0.9, 0.7);   // Sculk
    if (t == 27) return vec3(0.8, 0.3, 1.0);   // Crying obsidian, spawner
    if (t == 28) return vec3(0.75, 1.0, 0.5);  // Sea pickle
    if (t == 29) return vec3(1.0, 0.5, 0.25);  // Nether plants
    if (t == 30) return vec3(1.0, 0.7, 0.4);   // Candles
    if (t == 31) return vec3(1.0, 0.75, 0.35); // Ochre froglight
    if (t == 32) return vec3(0.7, 1.0, 0.4);   // Verdant froglight
    if (t == 33) return vec3(0.85, 0.5, 1.0);  // Pearlescent froglight
    if (t == 34) return vec3(0.6, 0.1, 1.0);   // Enchanting table
    if (t == 35) return vec3(0.75, 0.44, 1.0); // Amethyst cluster
    if (t == 36) return vec3(0.3, 0.9, 0.7);   // Calibrated sculk sensor
    if (t == 37) return vec3(0.3, 0.9, 0.7);   // Active sculk sensor
    if (t == 38) return vec3(1.0, 0.2, 0.1);   // Redstone block
    if (t == 39) return vec3(1.0, 0.5, 0.25);  // Open eyeblossom
    if (t == 42) return vec3(0.6, 0.1, 1.0);   // Nether portal
    if (t == 43) return vec3(0.2, 0.8, 0.6);   // End portal
    
    return vec3(1.0, 0.7, 0.4); // Default warm light
}

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;

    // End sky: render procedural sky on sky pixels
    #if defined(END_SHADER) && defined(END_SKY_ENABLED)
    {
        float depth = texture(depthtex0, texcoord).r;
        #ifdef DISTANT_HORIZONS
        float depthDH = texture(dhDepthTex, texcoord).r;
        if (depth >= 0.9999 && depthDH >= 0.9999) {
        #else
        if (depth >= 0.9999) {
        #endif
            // Reconstruct world direction from screen coordinates
            vec4 clipPos = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
            vec4 viewPos = gbufferProjectionInverse * clipPos;
            viewPos.xyz /= viewPos.w;
            vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * viewPos.xyz);
            color = renderEndSky(worldDir, frameTimeCounter, cameraPosition);
        }
    }
    #endif

    gl_FragData[0] = vec4(color, 1.0);

    // Bloom extraction
    #ifdef BLOOM_ENABLED
    // Read emissive flag and skylight from colortex1
    vec3 tex1Data = texture(colortex1, texcoord).rgb;
    float emissive = tex1Data.g;
    float skylight = tex1Data.b;
    
    // Optional pre-computed bloom color.
    // NOTE: Some geometry paths store non-color data in colortex3 (e.g., block IDs packed into R).
    // Treat colortex3 as a usable color only when it looks like an RGB color (not R-only data).
    vec3 precomputedColor = texture(colortex3, texcoord).rgb;
    
    // Use precomputed color if available (for consistent glass bloom), otherwise use scene color
    vec3 bloomColor = vec3(0.0);
    if (emissive >= 0.5) {
        bool looksLikePackedId = (precomputedColor.g + precomputedColor.b) < 0.0005;
        bool hasPrecomputed = (length(precomputedColor) > 0.1) && !looksLikePackedId;
        bloomColor = hasPrecomputed ? precomputedColor : color;

        // Scale bloom by emissive magnitude (particles write higher values for stronger bloom)
        bloomColor *= max(emissive, 1.0);

        // Distance-based bloom compensation
        // Far objects get diluted by blur, so boost their intensity
        float depth = getCombinedLinearDepth(texcoord);
        float distBoost = 1.0 + clamp(depth / 128.0, 0.0, 2.0) * BLOOM_DISTANCE_COMPENSATION;
        bloomColor *= distBoost;
    }

    // Sunlight-based bloom strength
    // sunAngle: 0=sunrise, 0.25=noon, 0.5=sunset, 0.75=midnight, 1.0=sunrise
    float distFromNoon = abs(sunAngle - 0.25);
    float isDay = 1.0 - smoothstep(0.20, 0.30, distFromNoon);  // 1.0 at noon, 0.0 at night
    
    // Only reduce bloom if BOTH in daylight AND exposed to sky (high skylight)
    // Underground (low skylight) always gets full bloom
    float sunlightExposure = isDay * skylight;  // 0 = underground or night, 1 = surface + day
    float bloomStrength = mix(1.0, BLOOM_DAY_STRENGTH, sunlightExposure);

    // End dimension: boost bloom extraction so emissive blocks glow strongly
    #ifdef END_SHADER
    bloomColor *= END_BLOOM_BOOST;
    #endif

    gl_FragData[1] = vec4(bloomColor * BLOOM_INTENSITY * bloomStrength, 1.0);
    gl_FragData[2] = vec4(bloomColor * bloomStrength, 1.0);  // Apply strength to colored light too
    #else
    gl_FragData[1] = vec4(0.0);
    gl_FragData[2] = vec4(0.0);
    #endif
}
