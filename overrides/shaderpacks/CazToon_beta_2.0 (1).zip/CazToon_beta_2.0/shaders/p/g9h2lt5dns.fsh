/* RENDERTARGETS: 2,3 */

// Composite pass 1: Horizontal blur for bloom and colored light

#include "/settings.glsl"

uniform sampler2D colortex2;
uniform sampler2D colortex3;

in vec2 texcoord;

// Wider gaussian weights for smoother blur
const float weights[9] = float[9](
    0.152781, 0.144599, 0.122589, 0.093095, 0.063327, 0.038579, 0.021045, 0.010281, 0.004496
);

void main() {
    #ifdef BLOOM_ENABLED
    vec2 texelSize = 1.0 / vec2(textureSize(colortex2, 0));
    vec2 direction = vec2(texelSize.x * BLOOM_RADIUS * 12.0, 0.0);
    
    vec3 bloom = texture(colortex2, texcoord).rgb * weights[0];
    vec3 coloredLight = texture(colortex3, texcoord).rgb * weights[0];
    
    for (int i = 1; i < 9; i++) {
        vec2 offset = direction * float(i);
        bloom += texture(colortex2, texcoord + offset).rgb * weights[i];
        bloom += texture(colortex2, texcoord - offset).rgb * weights[i];
        coloredLight += texture(colortex3, texcoord + offset).rgb * weights[i];
        coloredLight += texture(colortex3, texcoord - offset).rgb * weights[i];
    }
    
    gl_FragData[0] = vec4(bloom, 1.0);
    gl_FragData[1] = vec4(coloredLight, 1.0);
    #else
    gl_FragData[0] = vec4(0.0);
    gl_FragData[1] = vec4(0.0);
    #endif
}
