/* RENDERTARGETS: 0,1,3,4,5 */

// Particles shader - handles flames, smoke, etc.

#include "/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;
uniform float frameTimeCounter;

in vec2 texcoord;
in vec4 glcolor;
in vec3 worldPos;
in vec3 normal;
in float isHologram;

float random(float x) {
    return fract(sin(x * 12.9898) * 43758.5453);
}

void main() {
    vec4 color = texture(gtexture, texcoord) * glcolor;
    
    // Texture palette limiting
    #ifdef TEXTURE_PALETTE_ENABLED
    {
        float levels = float(TEXTURE_PALETTE_LEVELS);
        color.rgb = floor(color.rgb * levels) / levels;
    }
    #endif
    
    if (color.a < alphaTestRef) {
        discard;
    }

    // Detect emissive particles based on final color brightness and warmth
    float brightness = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    float warmth = color.r - color.b; // Fire/flame particles are warm (more red than blue)

    // Emissive if bright OR warm (catches flames, lava, glow particles)
    float emissive = 0.0;

    if (brightness > 0.7 || (warmth > 0.2 && brightness > 0.4)) {
        emissive = 1.0;
        color.rgb *= EMISSIVE_BRIGHTNESS;
    }

    gl_FragData[0] = color;
    // R = outline mask (0 = no outline for particles), G = emissive for bloom
    gl_FragData[1] = vec4(0.0, emissive, 0.0, 0.0); // Alpha=0 = not heat source
    gl_FragData[2] = vec4(0.0);
    gl_FragData[3] = vec4(0.0);
    gl_FragData[4] = vec4(0.0);
}
