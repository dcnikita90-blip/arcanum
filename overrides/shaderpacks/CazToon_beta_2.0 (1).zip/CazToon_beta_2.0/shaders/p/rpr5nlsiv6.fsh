/* RENDERTARGETS: 2,3 */

// Composite pass 5: Third horizontal blur - very wide

#include "/settings.glsl"

uniform sampler2D colortex2;
uniform sampler2D colortex3;

in vec2 texcoord;

const float weights[7] = float[7](
    0.198596, 0.175713, 0.121703, 0.065984, 0.028002, 0.009300, 0.002216
);

void main() {
    #ifdef BLOOM_ENABLED
    vec2 texelSize = 1.0 / vec2(textureSize(colortex2, 0));
    vec2 direction = vec2(texelSize.x * BLOOM_RADIUS * 16.0, 0.0);
    
    vec3 bloom = texture(colortex2, texcoord).rgb * weights[0];
    vec3 coloredLight = texture(colortex3, texcoord).rgb * weights[0];
    
    for (int i = 1; i < 7; i++) {
        vec2 offset = direction * float(i);
        bloom += texture(colortex2, texcoord + offset).rgb * weights[i];
        bloom += texture(colortex2, texcoord - offset).rgb * weights[i];
        coloredLight += texture(colortex3, texcoord + offset).rgb * weights[i];
        coloredLight += texture(colortex3, texcoord - offset).rgb * weights[i];
    }
    
    gl_FragData[0] = vec4(bloom, 1.0);
    gl_FragData[1] = vec4(coloredLight, 1.0);
    #else
    gl_FragData[0] = vec4(0.0);
    gl_FragData[1] = vec4(0.0);
    #endif
}
