/* RENDERTARGETS: 0,1 */

#include "/settings.glsl"

in vec4 glcolor;

void main() {
	// Vanilla stars are rendered as semi-transparent white quads via gbuffers_basic
	// When procedural stars enabled, discard vanilla stars
	#ifdef STARS_ENABLED
	// Stars have alpha < 1.0 and are whitish
	if (glcolor.a < 0.99 && glcolor.r > 0.5 && glcolor.g > 0.5 && glcolor.b > 0.5) {
		discard;
	}
	#endif
	
	gl_FragData[0] = glcolor;
	gl_FragData[1] = vec4(1.0, 0.0, 0.0, 0.0); // G=0 = no bloom, A=0 = not heat source
}
