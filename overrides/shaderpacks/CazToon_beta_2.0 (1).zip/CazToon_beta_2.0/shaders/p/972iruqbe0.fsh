/* RENDERTARGETS: 0 */

// Composite pass 7: Water + Material Reflections (ILV-style SSR)
// This pass applies screen-space reflections to water and reflective material surfaces

#include "/settings.glsl"

uniform sampler2D colortex0;  // Scene color
uniform sampler2D colortex1;  // Mask data (use .b skylight gate)
uniform sampler2D colortex5;  // Water data (packed: lmcoord, reflectiveness, normal)
uniform sampler2D depthtex0;  // Depth with translucents
uniform sampler2D depthtex1;  // Depth without translucents
uniform sampler2D depthtex2;  // Depth without translucents or handheld
uniform sampler2D dhDepthTex; // DH depth (with translucents)

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 dhProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;
uniform float sunAngle;
uniform int frameCounter;
uniform int isEyeInWater;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform int worldDay;
uniform int worldTime;

in vec2 texcoord;

#if defined(WATER_REFLECTIONS_ENABLED) || defined(MATERIAL_REFLECTIONS_ENABLED)

// Mark rainStrength as already declared so ilv_reflections.glsl doesn't redeclare it
#define RAIN_STRENGTH_DECLARED

// Include cloud systems for reflection sampling (before ilv_reflections which uses them)
#ifdef CLOUDS_3D_ENABLED
#include "/include/volumetric_clouds.glsl"
#endif
#ifdef CLOUDS_VANILLA_ENABLED
#include "/include/vanilla_clouds.glsl"
#endif
#include "/include/ilv_reflections.glsl"
#endif

#if (defined(WATER_REFLECTIONS_ENABLED) || defined(MATERIAL_REFLECTIONS_ENABLED)) && defined(PUDDLES_ENABLED)
float puddleHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float puddleNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = puddleHash(i);
    float b = puddleHash(i + vec2(1.0, 0.0));
    float c = puddleHash(i + vec2(0.0, 1.0));
    float d = puddleHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
#endif

#if (defined(WATER_REFLECTIONS_ENABLED) || defined(MATERIAL_REFLECTIONS_ENABLED)) && defined(WALL_RUNOFF_ENABLED)
float runoffHash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float runoffNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = runoffHash(i);
    float b = runoffHash(i + vec2(1.0, 0.0));
    float c = runoffHash(i + vec2(0.0, 1.0));
    float d = runoffHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
#endif

void main() {
    ivec2 texelcoord = ivec2(gl_FragCoord.xy);
    vec3 color = texelFetch(colortex0, texelcoord, 0).rgb;
    
    #if defined(WATER_REFLECTIONS_ENABLED) || defined(MATERIAL_REFLECTIONS_ENABLED)

    // Read reflection data from colortex5 (written by gbuffers_water or gbuffers_terrain)
    vec4 reflData = texelFetch(colortex5, texelcoord, 0);

    // Detect any reflection data by checking encoded normal (zw components)
    bool hasReflection = (reflData.z > 0.001 || reflData.w > 0.001);

    // Decode world normal to distinguish water (horizontal) from ice side faces (vertical)
    float nx = reflData.z * 2.0 - 1.0;
    float ny = reflData.w * 2.0 - 1.0;
    float nz = sqrt(max(1.0 - nx * nx - ny * ny, 0.0));
    vec3 decodedWorldNormal = vec3(nx, ny, nz);
    // Water top surface has normal.y > 0.7; ice/glass side faces have normal.y < 0.5
    bool isHorizontalSurface = (decodedWorldNormal.y > 0.5);

    // Distinguish water from solid materials: water has translucent depth != opaque depth
    float depth0 = texelFetch(depthtex0, texelcoord, 0).r;
    float depth1 = texelFetch(depthtex1, texelcoord, 0).r;
    float dhDepth = texelFetch(dhDepthTex, texelcoord, 0).r;
    // Only classify as water if depth mismatch AND surface is horizontal (not ice side faces)
    bool isWater = hasReflection && (abs(depth0 - depth1) > 0.000001) && isHorizontalSurface;
    // DH water: vanilla depth is sky, DH has geometry, and colortex5 has reflection data
    bool isDhWater = hasReflection && !isWater && (depth0 >= 0.9999) && (dhDepth < 0.9999);
    bool isMaterialRefl = hasReflection && !isWater && !isDhWater;

    #ifdef WATER_REFLECTION_DEBUG
    if (isWater) color = vec3(1.0, 0.0, 1.0);
    if (isDhWater) color = vec3(1.0, 1.0, 0.0);
    if (isMaterialRefl) color = vec3(0.0, 1.0, 1.0);
    #else

    // --- Water SSR (vanilla MC water) ---
    #ifdef WATER_REFLECTIONS_ENABLED
    if (isWater && isEyeInWater != 1) {
        if (depth0 < 1.0) {
            vec3 worldNormal = vec3(0.0, 1.0, 0.0);
            vec3 normal = normalize(mat3(gbufferModelView) * worldNormal);
            // Scale reflection by time of day — dimmer at night, full at day
            float reflAngle = fract(sunAngle);
            float reflDay = smoothstep(0.02, 0.10, reflAngle) * smoothstep(0.48, 0.40, reflAngle);
            float reflNight = smoothstep(0.52, 0.58, reflAngle) * smoothstep(0.98, 0.92, reflAngle);
            float reflTOD = mix(0.15, 1.0, reflDay) + reflNight * 0.08;
            float reflectionStrength = WATER_REFLECTION_AMOUNT * reflTOD;
            vec2 lmcoord = vec2(0.0, 1.0);
            vec3 screenPos = vec3(texcoord, depth0);
            vec3 viewPos = ilv_screenToView(screenPos);
            // Only SSR if reflected ray points upward in world space — downward rays hit the lake floor
            vec3 reflDirView = reflect(normalize(viewPos), normal);
            vec3 reflDirWorld = mat3(gbufferModelViewInverse) * reflDirView;
            if (reflDirWorld.y > 0.0) {
                ilv_addReflection(color, viewPos, normal, lmcoord, reflectionStrength);
            }
        }
    }

    // --- DH Water sky reflection (no SSR — DH geometry too coarse for raytracing) ---
    if (isDhWater && isEyeInWater != 1) {
        // Decode world normal from colortex5 (packed as n * 0.5 + 0.5)
        vec3 dhWorldNormal = vec3(
            reflData.z * 2.0 - 1.0,
            reflData.w * 2.0 - 1.0,
            0.0
        );
        dhWorldNormal.z = sqrt(max(1.0 - dhWorldNormal.x * dhWorldNormal.x - dhWorldNormal.y * dhWorldNormal.y, 0.0));
        vec3 dhNormalView = normalize(mat3(gbufferModelView) * dhWorldNormal);

        // Reconstruct view position from DH depth
        vec3 dhScreenPos = vec3(texcoord, dhDepth);
        vec3 dhNdc = dhScreenPos * 2.0 - 1.0;
        vec4 dhViewH = dhProjectionInverse * vec4(dhNdc, 1.0);
        vec3 dhViewPos = dhViewH.xyz / dhViewH.w;

        // Fresnel
        float dhFresnel = 1.0 - abs(dot(normalize(-dhViewPos), dhNormalView));
        dhFresnel *= dhFresnel;
        dhFresnel *= dhFresnel;
        float dhFresnelMod = mix(0.3, 1.0, dhFresnel) * WATER_REFLECTION_FADE;
        dhFresnelMod = clamp(dhFresnelMod, 0.0, 1.0);

        // Sky color in reflected direction
        vec3 dhReflDir = reflect(normalize(dhViewPos), dhNormalView);
        vec3 dhSkyColor = ilv_getSkyColor(dhReflDir) * 1.5;

        float dhReflStrength = WATER_REFLECTION_AMOUNT * dhFresnelMod * WATER_SKY_REFLECTION;
        color = mix(color, dhSkyColor, dhReflStrength);
    }
    #endif

    // --- Material SSR (polished/smooth/glazed surfaces) ---
    #ifdef MATERIAL_REFLECTIONS_ENABLED
    // Skip material SSR on hand/entity pixels: colortex5 can't be reliably
    // cleared under alpha blending (vec4(0.0) with alpha=0 is a blend no-op).
    // Hand pixels: depthtex2 excludes handheld, so depth0 < depth2 means hand.
    // Entity pixels: colortex1.a = 0.5 is the entity/hand marker from gbuffers.
    float depth2 = texelFetch(depthtex2, texelcoord, 0).r;
    bool isHandPixel = (depth0 < depth2 - 0.000001) && (abs(depth0 - depth1) < 0.000001);
    // Entity pixels: colortex1.a = 0.5 is the entity/hand marker from gbuffers.
    // Under alpha blending (translucent player skin layers), this dilutes toward 0.
    // Terrain ONLY writes exactly 0.0 or 1.0 — any intermediate value is entity.
    float entityMarker = texelFetch(colortex1, texelcoord, 0).a;
    bool isEntityPixel = (entityMarker > 0.001 && entityMarker < 0.999);
    if (isMaterialRefl && isEyeInWater != 1 && !isHandPixel && !isEntityPixel) {
        if (depth0 < 1.0) {
            // Decode world normal from colortex5 (encoded as n * 0.5 + 0.5)
            float nx = reflData.z * 2.0 - 1.0;
            float ny = reflData.w * 2.0 - 1.0;
            float nz = sqrt(max(1.0 - nx * nx - ny * ny, 0.0));
            vec3 worldNormal = vec3(nx, ny, nz);
            vec3 normal = normalize(mat3(gbufferModelView) * worldNormal);

            float reflectionStrength = MATERIAL_REFLECTION_AMOUNT;
            vec3 screenPos = vec3(texcoord, depth0);
            vec3 viewPos = ilv_screenToView(screenPos);

            // Fresnel: glancing angles reflect more
            vec3 V = normalize(-viewPos);
            float NdotV = max(dot(normal, V), 0.0);
            float fresnel = pow(1.0 - NdotV, 3.0) * MATERIAL_REFLECTION_FRESNEL;
            reflectionStrength = mix(reflectionStrength * 0.4, reflectionStrength, fresnel);

            ilv_addMaterialReflection(color, viewPos, normal, reflectionStrength);
        }
    }
    #endif

    // --------------------------------------------------------------------
    // Rain puddles (SSR) on opaque, mostly-upward surfaces
    // --------------------------------------------------------------------
    #if defined(PUDDLES_ENABLED)
    {
        float rs = clamp(rainStrength, 0.0, 1.0);
        float puddleStrength = clamp(PUDDLES_STRENGTH, 0.0, 1.0) * rs;

        // Only when it's raining and this pixel is NOT water
        if (!isWater && puddleStrength > 0.0001 && isEyeInWater != 1) {
            float depth = texelFetch(depthtex2, texelcoord, 0).r;
            if (depth < 0.9999) {
                vec2 px = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));

                // Reconstruct view-space position and normal from depth
                vec3 viewPos = ilv_screenToView(vec3(texcoord, depth));
                float dR = texelFetch(depthtex2, ivec2(texelcoord + ivec2(1, 0)), 0).r;
                float dL = texelFetch(depthtex2, ivec2(texelcoord + ivec2(-1, 0)), 0).r;
                float dU = texelFetch(depthtex2, ivec2(texelcoord + ivec2(0, -1)), 0).r;
                float dD = texelFetch(depthtex2, ivec2(texelcoord + ivec2(0, 1)), 0).r;

                vec3 vR = ilv_screenToView(vec3(texcoord + vec2(px.x, 0.0), dR));
                vec3 vL = ilv_screenToView(vec3(texcoord - vec2(px.x, 0.0), dL));
                vec3 vU = ilv_screenToView(vec3(texcoord - vec2(0.0, px.y), dU));
                vec3 vD = ilv_screenToView(vec3(texcoord + vec2(0.0, px.y), dD));

                vec3 dx = vR - vL;
                vec3 dy = vD - vU;
                vec3 viewNormal = normalize(cross(dx, dy));

                // Up direction in view space (matches ILV sky function)
                vec3 upV = normalize(gbufferModelView[1].xyz);
                float upness = clamp(abs(dot(viewNormal, upV)), 0.0, 1.0);

                // Only puddle on surfaces that are close to horizontal
                float flatMask = smoothstep(0.85, 0.98, upness);

                // World-space noise for patchy puddle coverage
                vec3 scenePos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
                vec3 worldPos = scenePos + cameraPosition;
                float n = puddleNoise(worldPos.xz * 0.12);
                // Sharper, more defined puddle edges
                float patches = smoothstep(0.62, 0.86, n);
                patches = pow(patches, 1.35);

                // Outline band around puddles (darker edge + slight highlight)
                float outer = smoothstep(0.56, 0.82, n);
                float inner = patches;
                float edgeBand = clamp(outer - inner, 0.0, 1.0);

                float puddleMask = puddleStrength * flatMask * patches;
                if (puddleMask > 0.0001) {
                    // Darken base color to look wet (more contrast/definition)
                    float wetDarken = mix(1.0, 0.80, puddleMask);
                    // Darker outline on the edge band
                    wetDarken *= mix(1.0, 0.82, edgeBand * puddleStrength);
                    color *= wetDarken;

                    // Subtle highlight along the puddle edge (helps definition)
                    color += vec3(0.03) * edgeBand * puddleStrength;

                    // Use a smoothed normal for puddle reflections
                    vec3 reflNormal = normalize(mix(viewNormal, upV, 0.75));

                    // Animated ripples: small, detailed normal perturbation (avoid super-wavy mirrors)
                    float t = float(frameCounter) * 0.016;
                    float r1 = sin(worldPos.x * 18.0 + t * 6.0);
                    float r2 = sin(worldPos.z * 21.0 - t * 5.2);
                    float r3 = sin((worldPos.x + worldPos.z) * 14.0 + t * 7.4);
                    float r4 = sin((worldPos.x - worldPos.z) * 32.0 - t * 8.1);
                    float ripple = (r1 + r2 + 0.65 * r3 + 0.35 * r4) / 3.0; // ~[-1..1]
                    float rippleAmp = 0.014 * rs * puddleStrength; // very subtle
                    // Build a tangent basis around upV
                    vec3 tangent = normalize(cross(upV, vec3(0.0, 0.0, 1.0)));
                    if (length(tangent) < 0.01) tangent = normalize(cross(upV, vec3(1.0, 0.0, 0.0)));
                    vec3 bitangent = normalize(cross(upV, tangent));
                    reflNormal = normalize(reflNormal + tangent * (ripple * rippleAmp) + bitangent * (r2 * rippleAmp * 0.35));
                    float reflStrength = puddleMask * clamp(PUDDLES_REFLECTION_STRENGTH, 0.0, 1.0);
                    // Slightly boost reflection where puddle is strongest
                    reflStrength *= mix(0.85, 1.20, patches);
                    // Ripples reduce sharp reflection slightly
                    reflStrength *= (1.0 - 0.05 * abs(ripple) * rs);

                    ilv_addReflection(color, viewPos, reflNormal, vec2(0.0, 1.0), reflStrength);
                }
            }
        }
    }
    #endif

    // --------------------------------------------------------------------
    // Wall runoff (flowing water streaks) on vertical surfaces during rain
    // --------------------------------------------------------------------
    #if defined(WALL_RUNOFF_ENABLED)
    {
        float rs = clamp(rainStrength, 0.0, 1.0);
        float runoffStrength = clamp(WALL_RUNOFF_STRENGTH, 0.0, 1.0) * rs;
        if (!isWater && runoffStrength > 0.0001 && isEyeInWater != 1) {
            // Gate runoff to outdoor-ish pixels using the per-pixel skylight channel
            float pxSkylight = texelFetch(colortex1, texelcoord, 0).b;
            float outdoor = smoothstep(0.15, 0.60, pxSkylight);
            if (outdoor > 0.001) {
                float depth = texelFetch(depthtex2, texelcoord, 0).r;
                if (depth < 0.9999) {
                    vec2 px = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));
                    vec3 viewPos = ilv_screenToView(vec3(texcoord, depth));

                    // Depth-derived normal
                    float dR = texelFetch(depthtex2, ivec2(texelcoord + ivec2(1, 0)), 0).r;
                    float dL = texelFetch(depthtex2, ivec2(texelcoord + ivec2(-1, 0)), 0).r;
                    float dU = texelFetch(depthtex2, ivec2(texelcoord + ivec2(0, -1)), 0).r;
                    float dD = texelFetch(depthtex2, ivec2(texelcoord + ivec2(0, 1)), 0).r;
                    vec3 vR = ilv_screenToView(vec3(texcoord + vec2(px.x, 0.0), dR));
                    vec3 vL = ilv_screenToView(vec3(texcoord - vec2(px.x, 0.0), dL));
                    vec3 vU = ilv_screenToView(vec3(texcoord - vec2(0.0, px.y), dU));
                    vec3 vD = ilv_screenToView(vec3(texcoord + vec2(0.0, px.y), dD));
                    vec3 dx = vR - vL;
                    vec3 dy = vD - vU;
                    vec3 viewNormal = normalize(cross(dx, dy));
                    vec3 upV = normalize(gbufferModelView[1].xyz);
                    float upness = clamp(abs(dot(viewNormal, upV)), 0.0, 1.0);

                    // Vertical-ish surfaces only
                    float vertical = 1.0 - smoothstep(0.30, 0.70, upness);

                    // World position
                    vec3 scenePos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
                    vec3 worldPos = scenePos + cameraPosition;

                    // Coherent streak pattern based on world XZ (so it "sticks" to blocks)
                    float laneLayout = runoffNoise(worldPos.xz * 0.90);
                    float lanes = worldPos.x * 2.2 + worldPos.z * 1.7 + laneLayout * 2.0;
                    float laneCell = fract(lanes);
                    float laneCore = 1.0 - abs(laneCell - 0.5) * 2.0;
                    laneCore = pow(clamp(laneCore, 0.0, 1.0), 6.0); // thin streaks

                    // Downward flow animation along world Y
                    float t = float(frameCounter) * 0.016 * clamp(WALL_RUNOFF_SPEED, 0.0, 5.0);
                    float flow = fract(worldPos.y * 1.25 - t + laneLayout);
                    float drops = smoothstep(0.10, 0.00, flow) + smoothstep(0.90, 1.00, flow);
                    drops = clamp(drops, 0.0, 1.0);

                    float mask = runoffStrength * outdoor * vertical * laneCore;
                    // Modulate with moving droplet pulses so it looks like flowing water
                    mask *= mix(0.55, 1.0, drops);
                    mask = clamp(mask, 0.0, 1.0);

                    if (mask > 0.0001) {
                        // Darken the wall slightly where wet
                        color *= mix(1.0, 0.86, mask);
                        // Add a thin spec-like highlight line
                        color += vec3(0.05, 0.06, 0.07) * mask;
                    }
                }
            }
        }
    }
    #endif // WALL_RUNOFF_ENABLED

    #endif // WATER_REFLECTION_DEBUG

    #endif // WATER_REFLECTIONS_ENABLED || MATERIAL_REFLECTIONS_ENABLED
    
    gl_FragData[0] = vec4(color, 1.0);
}
