

#include "/settings.glsl"

#include "/include/color_utils.glsl"
#include "/include/biome_overrides.glsl"
#include "/include/water_color.glsl"
#include "/include/volumetric_clouds.glsl"

#ifdef END_SHADER
#if defined(END_EVENT_ENABLED)
#include "/include/end_event.glsl"
#endif
#ifdef END_SKY_ENABLED
#include "/include/end_sky.glsl"
#endif
#endif

// 3D clouds now rendered in composite8.fsh

uniform sampler2D colortex0; // Scene color (sharp original)
uniform sampler2D colortex1; // Outline mask, emissive flag, heat source
uniform sampler2D colortex2; // Bloom (blurred glow)
uniform sampler2D colortex3; // Colored light (blurred)
uniform sampler2D colortex4; // Glass tint (RGB = tint, A = strength)
uniform sampler2D colortex6; // Block ID (R) for connected texture detection
uniform sampler2D colortex8; // Vanilla cloud depth buffer (R)
uniform sampler2D colortex5; // Water data (ILV packed format)
uniform sampler2D depthtex0; // Depth without translucents
uniform sampler2D depthtex1; // Depth with translucents (glass, water, etc)
uniform sampler2D dhDepthTex;
uniform float near;
uniform float far;
uniform float dhNearPlane;
uniform float dhFarPlane;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform float sunAngle;
uniform int worldDay;
uniform int worldTime;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 fogColor;   // Biome fog color from Minecraft
uniform vec3 skyColor;   // Biome sky color from Minecraft
uniform int biome;
uniform int biome_category;
uniform float biome_jungle;
uniform float biome_swamp;
uniform float biome_snowy;
uniform float biome_arid;
uniform vec3 shadowLightPosition; // Sun/moon direction in view space
uniform vec3 sunPosition;  // Sun direction in view space
uniform vec3 moonPosition; // Moon direction in view space
uniform int heldItemId;
uniform int heldItemId2;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform float viewWidth;
uniform float viewHeight;
uniform int isEyeInWater; // 0 = air, 1 = water, 2 = lava
uniform vec3 eyePosition; // Player head position in world space (not camera)
uniform float rainStrength;
uniform float thunderStrength;

// NOTE: Reflections are now handled in composite7.fsh

// Shadow map uniforms for god rays (needed by VFOG and underwater shafts)
#if defined(VFOG_GOD_RAYS) || defined(UNDERWATER_LIGHT_SHAFTS)
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1; // Ignores transparent objects (particles, etc)
uniform sampler2D shadowcolor0; // Color of transparent shadow casters (stained glass)
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
#endif

in vec2 texcoord;

// Forward declarations (GLSL requires functions to be declared before use)
vec3 getHorizonColor();
float linearizeDepth(float depth);

// End dimension detection
// Primary: END_SHADER define from world1/ wrapper via dimension.properties
// Fallback: fogColor+skyColor both near zero (unique to End)
bool isEndDimension() {
    #ifdef END_SHADER
    return true;
    #else
    #ifdef CAT_THE_END
    return biome_category == CAT_THE_END;
    #else
    return isForcedEndBiome(biome);
    #endif
    #endif
}

bool isSkylessWorldHeuristic() {
	float sunLen = length(sunPosition);
	float shadowLen = length(shadowLightPosition);
	vec3 skyMax = max(skyColor, vec3(0.0));
	vec3 fogMax = max(fogColor, vec3(0.0));
	float skyPeak = max(max(skyMax.r, skyMax.g), skyMax.b);
	float fogPeak = max(max(fogMax.r, fogMax.g), fogMax.b);
	bool noDirectionalLight = (sunLen < 0.001 && shadowLen < 0.001);
	bool darkFlatAtmosphere = (skyPeak < 0.06 && fogPeak < 0.08);
	return darkFlatAtmosphere && noDirectionalLight;
}

// ============================================================================
// Sun Screen Position (shared by sun shafts and sun glow)
// ============================================================================
vec2 getSunScreenUV() {
	// Project a far point in the sun direction into screen space.
	// Use shadowLightPosition (used by the shadow pipeline) for consistent direction.
	vec3 sunDirView = normalize(shadowLightPosition);
	vec3 sunPosView = sunDirView * 1000.0;
	vec4 clip = gbufferProjection * vec4(sunPosView, 1.0);
	if (clip.w <= 0.00001) return vec2(-1.0);
	vec2 ndc = clip.xy / clip.w;
	return ndc * 0.5 + 0.5;
}

// ============================================================================
// Screen-Space Sun Shafts (Crepuscular Rays)
// ============================================================================
#ifdef SS_SUN_SHAFTS_ENABLED

vec3 computeScreenSpaceSunShafts(vec2 uv) {
	// Day only (avoid moon shafts here; VFOG/LSFOG already handle moon-ish shafts)
	float angle = fract(sunAngle);
	float dayFactor = smoothstep(0.0, 0.12, angle) * (1.0 - smoothstep(0.48, 0.52, angle));
	if (dayFactor <= 0.001) return vec3(0.0);

	vec2 rawSunUV = getSunScreenUV();
	// If the sun is just off-screen (common when looking forward/down), keep shafts by clamping
	// to the nearest screen edge and fading out as it goes further off-screen.
	vec2 sunUV = clamp(rawSunUV, vec2(0.0), vec2(1.0));
	float offX = max(-rawSunUV.x, rawSunUV.x - 1.0);
	float offY = max(-rawSunUV.y, rawSunUV.y - 1.0);
	float off = max(offX, offY); // 0 when on-screen
	float offscreenFade = 1.0 - smoothstep(0.0, 0.35, off);
	if (offscreenFade <= 0.001) return vec3(0.0);

	// Receiver selection + depth limiter.
	float centerDepth = texture(depthtex0, uv).r;
	bool isSkyPx = (centerDepth >= 0.9999);
	float depthMask = 1.0;

	// Receiver mode:
	// 0 = sky only, 1 = sky + near scene, 2 = near scene only.
	#if SS_SHAFT_RECEIVER_MODE == 0
		if (!isSkyPx) return vec3(0.0);
	#elif SS_SHAFT_RECEIVER_MODE == 2
		if (isSkyPx) return vec3(0.0);
	#endif

	// Only distance-limit geometry receivers (sky has no depth).
	if (!isSkyPx) {
		float centerViewDist = linearizeDepth(centerDepth);
		depthMask = 1.0 - smoothstep(SS_SHAFT_DEPTH_START, SS_SHAFT_DEPTH_END, centerViewDist);
		if (depthMask <= 0.001) return vec3(0.0);
	}

	// March from the current pixel toward the sun.
	vec2 delta = (sunUV - uv) * (SS_SHAFT_DENSITY / float(SS_SHAFT_SAMPLES));
	vec2 coord = uv;

	// Dither the starting position slightly to reduce banding
	float dither = fract(sin(dot(gl_FragCoord.xy + float(frameCounter) * 0.25, vec2(12.9898, 78.233))) * 43758.5453);
	coord += delta * dither;

	float illumination = 1.0;
	float accumOpen = 0.0;
	float accumEdge = 0.0;
	float total = 0.0;
	// Track changes in sky/occluder along the march: rays appear where occlusion varies (tree gaps),
	// and are suppressed in uniform occlusion (under bridges) or uniform open sky.
	float prevOpen = 0.0;

	for (int i = 0; i < SS_SHAFT_SAMPLES; i++) {
		coord += delta;
		// Off-screen safety
		if (coord.x < 0.0 || coord.y < 0.0 || coord.x > 1.0 || coord.y > 1.0) break;

		float d = texture(depthtex0, coord).r;
		// Treat sky as "open". Geometry occludes.
		float openToSun = step(0.9999, d);
		accumOpen += openToSun * illumination;
		accumEdge += abs(openToSun - prevOpen) * illumination;
		total += illumination;
		prevOpen = openToSun;
		illumination *= SS_SHAFT_DECAY;
	}

	if (total <= 0.0001) return vec3(0.0);
	float openN = clamp(accumOpen / total, 0.0, 1.0);
	float edgeN = clamp(accumEdge / total, 0.0, 1.0);
	// Convert to a "ray strength" that is mostly edge-driven, not a blanket brightness boost.
	float rayStrength = openN * pow(edgeN, 0.85);
	// Make weak rays more visible without turning into a broad brightness lift.
	rayStrength = pow(clamp(rayStrength, 0.0, 1.0), 0.70);

	#ifdef SS_SUN_SHAFTS_DEBUG
		return vec3(rayStrength);
	#endif

	// Color: use current horizon/fog color so shafts blend naturally.
	vec3 shaftColor = getHorizonColor();
	// NOTE: rayStrength is already normalized; keep the result visible by not re-multiplying by SS_SHAFT_WEIGHT.
	vec3 shaftAdd = shaftColor * rayStrength * SS_SHAFT_INTENSITY * dayFactor * offscreenFade;
	shaftAdd *= clamp(depthMask, 0.0, 1.0);

	// Clamp luminance so it never blinds players.
	float lum = dot(shaftAdd, vec3(0.299, 0.587, 0.114));
	if (lum > SS_SHAFT_MAX_LUM && lum > 0.0001) {
		shaftAdd *= SS_SHAFT_MAX_LUM / lum;
	}

	return shaftAdd;
}
#endif

// Apply posterization (color palette limiting) - defined early for use in multiple places
vec3 applyPosterize(vec3 color, float levels, float dither, vec2 fragCoord, int frameCount) {
	// Add dithering to reduce banding
	float noise = fract(sin(dot(fragCoord + float(frameCount) * 0.1, vec2(12.9898, 78.233))) * 43758.5453);
	noise = (noise - 0.5) * dither / levels;
	
	color += noise;
	color = floor(color * levels + 0.5) / levels;
	
	return clamp(color, 0.0, 1.0);
}

vec3 getHeldItemLightColor(int heldId) {
	if (heldId == 10021 || heldId == 10043) return vec3(0.35, 0.82, 1.0); // soul lights
	if (heldId == 10022 || heldId == 10039) return vec3(1.0, 0.42, 0.15); // lava / fire
	if (heldId == 10024 || heldId == 10032 || heldId == 10044) return vec3(0.70, 0.92, 1.0); // sea lantern / beacon
	if (heldId == 10026 || heldId == 10038 || heldId == 10058) return vec3(1.0, 0.25, 0.15); // redstone
	if (heldId == 10052) return vec3(0.45, 1.00, 0.70); // verdant froglight
	if (heldId == 10053) return vec3(0.95, 0.72, 1.00); // pearlescent froglight
	if (heldId == 10027 || heldId == 10051) return vec3(1.0, 0.80, 0.45); // ochre froglight
	return vec3(1.0, 0.78, 0.50); // generic warm fallback
}


float saturate(in float x) {
	return clamp(x, 0.0, 1.0);
}

// ============================================================================
// Color Grading Helper Functions
// ============================================================================

#ifdef COLOR_GRADING_ENABLED
// RGB to HSV conversion
vec3 rgbToHsv(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
	float d = q.x - min(q.w, q.y);
	float e = 1.0e-10;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

// HSV to RGB conversion
vec3 hsvToRgb(vec3 c) {
	vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

// Apply temperature shift (warm/cool)
vec3 applyTemperature(vec3 color, float temp) {
	// Temperature affects the blue-orange axis
	float t = temp * 0.15;
	color.r += t;
	color.b -= t;
	return clamp(color, 0.0, 1.0);
}

// Apply tint shift (green/magenta)
vec3 applyTint(vec3 color, float tint) {
	float t = tint * 0.1;
	color.g += t;
	color.r -= t * 0.5;
	color.b -= t * 0.5;
	return clamp(color, 0.0, 1.0);
}

// Apply split toning - color shadows and highlights differently
vec3 applySplitToning(vec3 color, vec3 shadowTint, vec3 highlightTint, float intensity, float balance) {
	float lum = dot(color, vec3(0.299, 0.587, 0.114));
	
	// Balance shifts the crossover point
	float crossover = 0.5 + balance * 0.3;
	
	// Shadow influence (stronger in darks)
	float shadowWeight = 1.0 - smoothstep(0.0, crossover, lum);
	
	// Highlight influence (stronger in brights)
	float highlightWeight = smoothstep(crossover, 1.0, lum);
	
	vec3 tint = mix(shadowTint * shadowWeight, highlightTint * highlightWeight, 0.5);
	
	// Blend tint with original color
	return mix(color, color + (tint - 0.5) * color, intensity);
}

// Apply Lift/Gamma/Gain
vec3 applyLiftGammaGain(vec3 color, vec3 lift, vec3 gamma, vec3 gain) {
	// Lift affects shadows (additive in dark areas)
	// Gamma affects midtones (power adjustment)
	// Gain affects highlights (multiplicative overall)
	
	vec3 result = color;
	
	// Gain (multiply)
	result *= gain;
	
	// Lift (add offset scaled by inverse of value - affects shadows more)
	vec3 liftOffset = (lift - 1.0) * (1.0 - result);
	result += liftOffset * 0.5;
	
	// Gamma (power curve)
	result = pow(max(result, vec3(0.001)), 1.0 / gamma);
	
	return clamp(result, 0.0, 1.0);
}

// Apply vignette
vec3 applyVignette(vec3 color, vec2 uv, float intensity, float radius, float softness, float roundness) {
	vec2 center = uv - 0.5;
	center.x *= roundness; // Adjust for aspect ratio / roundness
	
	float dist = length(center) * 2.0;
	float vignette = smoothstep(radius, radius - softness, dist);
	
	// Mix towards black based on vignette
	return mix(color * (1.0 - intensity), color, vignette);
}

// Apply film grain
vec3 applyFilmGrain(vec3 color, vec2 uv, float intensity, float size, bool luminanceOnly, float time, int frameCount) {
	// Generate animated noise
	vec2 noiseCoord = uv * size * 200.0;
	float t = time * 10.0 + float(frameCount);
	
	float noise = fract(sin(dot(noiseCoord + t, vec2(12.9898, 78.233))) * 43758.5453);
	noise += fract(sin(dot(noiseCoord.yx - t * 0.7, vec2(93.9898, 67.345))) * 28462.1253);
	noise = noise * 0.5 - 0.5;
	
	if (luminanceOnly) {
		color += vec3(noise * intensity);
	} else {
		vec3 colorNoise;
		colorNoise.r = noise;
		colorNoise.g = fract(sin(dot(noiseCoord + t * 1.1, vec2(45.233, 97.113))) * 32145.6789) - 0.5;
		colorNoise.b = fract(sin(dot(noiseCoord - t * 0.9, vec2(78.345, 23.897))) * 54321.9876) - 0.5;
		color += colorNoise * intensity;
	}
	
	return clamp(color, 0.0, 1.0);
}

// Apply hue shift
vec3 applyHueShift(vec3 color, float degrees) {
	vec3 hsv = rgbToHsv(color);
	hsv.x = fract(hsv.x + degrees / 360.0);
	return hsvToRgb(hsv);
}

// Apply vibrance (smart saturation that protects already saturated colors)
vec3 applyVibrance(vec3 color, float vibrance) {
	float maxC = max(max(color.r, color.g), color.b);
	float minC = min(min(color.r, color.g), color.b);
	float sat = maxC - minC;
	
	// Less saturated colors get boosted more
	float vibranceWeight = 1.0 - sat;
	vibranceWeight = pow(vibranceWeight, 1.5); // Curve the response
	
	float lum = dot(color, vec3(0.299, 0.587, 0.114));
	vec3 saturatedColor = mix(vec3(lum), color, 1.0 + vibrance * vibranceWeight);
	
	return clamp(saturatedColor, 0.0, 1.0);
}

// Apply preset style
vec3 applyStylePreset(vec3 color, int preset, float intensity) {
	if (preset == 0) return color;
	
	vec3 styled = color;
	
	if (preset == 1) {
		// Cinematic: warm highlights, cool shadows, slight desaturation
		float lum = dot(color, vec3(0.299, 0.587, 0.114));
		vec3 shadowTint = vec3(0.08, 0.1, 0.18);
		vec3 highlightTint = vec3(0.22, 0.18, 0.12);
		styled = applySplitToning(color, shadowTint, highlightTint, 0.35, 0.1);
		styled = applyVibrance(styled, -0.15);
		styled = applyLiftGammaGain(styled, vec3(0.98, 0.98, 1.02), vec3(1.0), vec3(1.05, 1.02, 0.98));
	}
	else if (preset == 2) {
		// Vintage: sepia-ish, reduced contrast, warm
		styled = applyTemperature(color, 0.4);
		styled = applyVibrance(styled, -0.3);
		styled = applyLiftGammaGain(styled, vec3(1.05, 1.02, 0.95), vec3(0.95), vec3(0.95, 0.93, 0.88));
		// Add slight sepia overlay
		float lum = dot(styled, vec3(0.299, 0.587, 0.114));
		vec3 sepia = vec3(lum * 1.1, lum * 0.95, lum * 0.75);
		styled = mix(styled, sepia, 0.2);
	}
	else if (preset == 3) {
		// Cyberpunk: teal & orange, high contrast, saturated
		vec3 shadowTint = vec3(0.0, 0.25, 0.35);
		vec3 highlightTint = vec3(0.35, 0.2, 0.05);
		styled = applySplitToning(color, shadowTint, highlightTint, 0.5, 0.0);
		styled = applyVibrance(styled, 0.4);
		styled = (styled - 0.5) * 1.15 + 0.5; // Boost contrast
		styled = applyLiftGammaGain(styled, vec3(0.95, 1.0, 1.08), vec3(1.0), vec3(1.08, 1.0, 0.92));
	}
	else if (preset == 4) {
		// Horror: desaturated, green tint, crushed blacks
		styled = applyVibrance(color, -0.5);
		styled = applyTint(styled, -0.3);
		styled = applyLiftGammaGain(styled, vec3(0.9, 0.95, 0.9), vec3(1.1), vec3(0.9, 0.92, 0.88));
		// Crush blacks
		styled = max(styled - 0.05, vec3(0.0));
	}
	else if (preset == 5) {
		// Fantasy: vibrant, purple shadows, golden highlights
		vec3 shadowTint = vec3(0.18, 0.08, 0.28);
		vec3 highlightTint = vec3(0.28, 0.22, 0.1);
		styled = applySplitToning(color, shadowTint, highlightTint, 0.4, 0.15);
		styled = applyVibrance(styled, 0.35);
		styled = applyLiftGammaGain(styled, vec3(1.0, 0.95, 1.1), vec3(0.95), vec3(1.1, 1.05, 0.95));
	}
	else if (preset == 6) {
		// Nordic: cold, desaturated, blue shadows
		styled = applyTemperature(color, -0.35);
		styled = applyVibrance(styled, -0.25);
		vec3 shadowTint = vec3(0.1, 0.12, 0.22);
		vec3 highlightTint = vec3(0.18, 0.18, 0.2);
		styled = applySplitToning(styled, shadowTint, highlightTint, 0.3, -0.2);
		styled = applyLiftGammaGain(styled, vec3(0.95, 0.97, 1.05), vec3(1.05), vec3(0.98, 1.0, 1.05));
	}
	else if (preset == 7) {
		// Tropical: warm, saturated greens and blues
		styled = applyTemperature(color, 0.2);
		styled = applyVibrance(styled, 0.4);
		// Boost greens and blues specifically
		styled.g = pow(styled.g, 0.9);
		styled.b = pow(styled.b, 0.95);
		styled = applyLiftGammaGain(styled, vec3(1.0, 1.03, 1.02), vec3(0.95), vec3(1.02, 1.05, 1.08));
	}
	else if (preset == 8) {
		// Noir: heavy desaturation, slight blue tint, high contrast
		styled = applyVibrance(color, -0.7);
		styled = applyTemperature(styled, -0.15);
		styled = (styled - 0.5) * 1.25 + 0.5; // High contrast
		styled = applyLiftGammaGain(styled, vec3(0.9, 0.9, 0.95), vec3(1.1), vec3(1.1, 1.08, 1.05));
	}
	
	return mix(color, clamp(styled, 0.0, 1.0), intensity);
}

// Main color grading function
vec3 applyColorGrading(vec3 color, vec2 uv, float time, int frameCount) {
	vec3 result = color;
	
	// Apply style preset first (provides base look)
	#if CG_STYLE_PRESET > 0
	result = applyStylePreset(result, CG_STYLE_PRESET, CG_STYLE_INTENSITY);
	#endif
	
	// Temperature and tint
	#if CG_TEMPERATURE != 0.0
	result = applyTemperature(result, CG_TEMPERATURE);
	#endif
	
	#if CG_TINT != 0.0
	result = applyTint(result, CG_TINT);
	#endif
	
	// Hue shift
	#if CG_HUE_SHIFT != 0.0
	result = applyHueShift(result, CG_HUE_SHIFT);
	#endif
	
	// Vibrance
	#if CG_VIBRANCE != 0.0
	result = applyVibrance(result, CG_VIBRANCE);
	#endif
	
	// Split toning
	#ifdef CG_SPLIT_TONING_ENABLED
	{
		vec3 shadowTint = vec3(CG_SHADOW_TINT_R, CG_SHADOW_TINT_G, CG_SHADOW_TINT_B);
		vec3 highlightTint = vec3(CG_HIGHLIGHT_TINT_R, CG_HIGHLIGHT_TINT_G, CG_HIGHLIGHT_TINT_B);
		result = applySplitToning(result, shadowTint, highlightTint, CG_SPLIT_TONING_INTENSITY, CG_SPLIT_TONING_BALANCE);
	}
	#endif
	
	// Lift/Gamma/Gain
	{
		vec3 lift = vec3(CG_LIFT_R, CG_LIFT_G, CG_LIFT_B);
		vec3 gamma = vec3(CG_GAMMA_R, CG_GAMMA_G, CG_GAMMA_B);
		vec3 gain = vec3(CG_GAIN_R, CG_GAIN_G, CG_GAIN_B);
		
		// Only apply if any value differs from 1.0
		if (lift != vec3(1.0) || gamma != vec3(1.0) || gain != vec3(1.0)) {
			result = applyLiftGammaGain(result, lift, gamma, gain);
		}
	}
	
	// Posterization - MOVED to pre-fog section, skipping here
	// #ifdef CG_POSTERIZE_ENABLED
	// result = applyPosterize(result, float(CG_POSTERIZE_LEVELS), CG_POSTERIZE_DITHER, gl_FragCoord.xy, frameCount);
	// #endif
	
	// Vignette
	#ifdef CG_VIGNETTE_ENABLED
	result = applyVignette(result, uv, CG_VIGNETTE_INTENSITY, CG_VIGNETTE_RADIUS, CG_VIGNETTE_SOFTNESS, CG_VIGNETTE_ROUNDNESS);
	#endif
	
	// Film grain (applied last)
	#ifdef CG_FILM_GRAIN_ENABLED
	#ifdef CG_FILM_GRAIN_LUMINANCE
	result = applyFilmGrain(result, uv, CG_FILM_GRAIN_INTENSITY, CG_FILM_GRAIN_SIZE, true, time, frameCount);
	#else
	result = applyFilmGrain(result, uv, CG_FILM_GRAIN_INTENSITY, CG_FILM_GRAIN_SIZE, false, time, frameCount);
	#endif
	#endif
	
	return result;
}
#endif // COLOR_GRADING_ENABLED

float linearizeDepth(float depth) {
	return (near * far) / (depth * (near - far) + far);
}

float linearizeDepthDH(float depth) {
	return (dhNearPlane * dhFarPlane) / (depth * (dhNearPlane - dhFarPlane) + dhFarPlane);
}

bool hasValidDHDepth(float depth) {
	return depth > 0.00001 && depth < 0.9999;
}

// Sample depth from both MC and DH, return the closer one
float sampleCombinedDepth(ivec2 texel) {
	float depthMC = texelFetch(depthtex0, texel, 0).x;
	float depthDH = texelFetch(dhDepthTex, texel, 0).x;
	bool validDH = hasValidDHDepth(depthDH);

	// If MC depth is at far plane, use DH depth
	if (depthMC >= 0.9999 && validDH) {
		return depthDH;
	}
	return depthMC;
}

float linearizeCombinedDepth(ivec2 texel) {
	float depthMC = texelFetch(depthtex0, texel, 0).x;
	float depthDH = texelFetch(dhDepthTex, texel, 0).x;
	bool validDH = hasValidDHDepth(depthDH);

	if (depthMC >= 0.9999 && validDH) {
		return linearizeDepthDH(depthDH);
	}
	return linearizeDepth(depthMC);
}

// Reconstruct world position from MC depth
vec3 getWorldPos(vec2 uv, float depth) {
	vec4 clipPos = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
	vec4 viewPos = gbufferProjectionInverse * clipPos;
	viewPos /= viewPos.w;
	vec4 worldPos = gbufferModelViewInverse * viewPos;
	return worldPos.xyz + cameraPosition;
}

// Reconstruct world position from DH depth using linearized depth + view ray
vec3 getWorldPosDH(vec2 uv, float depth) {
	// Linearize DH depth to get actual view distance
	float linearDepth = linearizeDepthDH(depth);

	// Get view ray direction from screen coordinates
	// We use the MC projection because DH and MC share the same screen space
	vec4 clipPos = vec4(uv * 2.0 - 1.0, -1.0, 1.0); // Point on near plane
	vec4 viewPosNear = gbufferProjectionInverse * clipPos;
	viewPosNear /= viewPosNear.w;
	vec3 viewDir = normalize(viewPosNear.xyz);

	// Scale the view direction by the linear depth
	// In view space, -Z is forward. Linear depth is distance along the view axis.
	// We scale by linearDepth / abs(viewDir.z) to extend the ray to the correct distance
	vec3 viewPos = viewDir * (linearDepth / max(abs(viewDir.z), 0.001));

	// Transform to world space
	vec4 worldPos = gbufferModelViewInverse * vec4(viewPos, 1.0);
	return worldPos.xyz + cameraPosition;
}

// ============================================================================
// Shadow Sampling for Volumetric Effects (god rays)
// ============================================================================
#if defined(VFOG_GOD_RAYS) || defined(UNDERWATER_LIGHT_SHAFTS)
// Quartic length - MUST match shadow.glsl exactly
float pow4fog(float x) { return x * x * x * x; }
float quartic_length_fog(vec2 v) {
	return sqrt(sqrt(pow4fog(v.x) + pow4fog(v.y)));
}

// Distort shadow position - MUST match shadow.vsh / shadow.glsl exactly
vec3 distortShadowClipPosFog(vec3 pos) {
	float factor = quartic_length_fog(pos.xy) + SHADOW_DISTORTION;
	return vec3(pos.xy / factor, pos.z * SHADOW_DEPTH_SCALE);
}

// Sample colored shadow at a world position
// Returns vec3 color multiplier (1,1,1 = fully lit, 0,0,0 = fully shadowed)
vec3 sampleColoredShadowWorld(vec3 worldPos) {
	vec3 scenePos = worldPos - cameraPosition;
	vec4 shadowClip4 = shadowProjection * shadowModelView * vec4(scenePos, 1.0);
	vec3 shadowClip = shadowClip4.xyz;
	vec3 distorted = distortShadowClipPosFog(shadowClip);
	vec3 shadowCoord = distorted * 0.5 + 0.5;
	
	if (shadowCoord.x < 0.0 || shadowCoord.x > 1.0 ||
	    shadowCoord.y < 0.0 || shadowCoord.y > 1.0 ||
	    shadowCoord.z < 0.0 || shadowCoord.z > 1.0) {
		return vec3(1.0);
	}
	
	float transparentShadow = step(shadowCoord.z - 0.001, texture(shadowtex0, shadowCoord.xy).r);
	if (transparentShadow == 1.0) return vec3(1.0);
	
	float opaqueShadow = step(shadowCoord.z - 0.001, texture(shadowtex1, shadowCoord.xy).r);
	if (opaqueShadow == 0.0) return vec3(0.0);
	
	vec4 shadowColor = texture(shadowcolor0, shadowCoord.xy);
	return shadowColor.rgb * (1.0 - shadowColor.a);
}
#endif

// ============================================================================
// Shadow Tint for Fog Darkening (matches lighting.glsl shadow coloring)
// ============================================================================
// Computes the same shadow color tint that the scene lighting uses so that
// fog god-ray shadows darken with the correct hue instead of going to flat
// neutral black. Incorporates both the user SHADOW_HUE/SHADOW_SATURATION
// setting and the time-of-day skylight tint.
vec3 getFogShadowTint() {
	// Use biome fog color as the god ray shadow tint (not the global shadow hue)
	vec3 biomeFog = getForcedBiomeFogColorCat(biome, biome_category, getHorizonColor());
	float fogLum = dot(biomeFog, vec3(0.299, 0.587, 0.114));
	vec3 fogNorm = clamp(biomeFog / max(fogLum, 0.35), vec3(0.0), vec3(2.0));
	return mix(vec3(1.0), fogNorm, clamp(SKYLIGHT_COLOR_TINT, 0.0, 1.0) * SKYLIGHT_TINT_SATURATION);
}

// ============================================================================
// Common Fog Color Function (used by multiple fog systems)
// ============================================================================
// Get the current horizon/fog color based on time of day
// Uses blend of horizon + mid colors to match what the sky looks like near the horizon
// Matches gbuffers_skybasic.fsh sky calculation
vec3 getHorizonColor() {
	if (isSkylessWorldHeuristic()) {
		return max(fogColor, skyColor * 0.8);
	}

	// Calculate time-of-day weights (same as gbuffers_skybasic.fsh)
	float angle = fract(sunAngle);

	float isDay = smoothstep(0.02, 0.09, angle) * (1.0 - smoothstep(0.43, 0.50, angle));
	float twilight = smoothstep(0.44, 0.50, angle) * (1.0 - smoothstep(0.54, 0.60, angle))
	               + smoothstep(0.96, 1.0, angle) + (1.0 - smoothstep(0.0, 0.04, angle));
	float blueHour = smoothstep(0.53, 0.58, angle) * (1.0 - smoothstep(0.62, 0.69, angle));
	float isNight = smoothstep(0.61, 0.68, angle) * (1.0 - smoothstep(0.90, 0.98, angle));

	float rawTwilight = twilight;

	// Normalize weights
	float totalWeight = isDay + twilight + blueHour + isNight;
	if (totalWeight > 0.0001) {
		isDay /= totalWeight;
		twilight /= totalWeight;
		blueHour /= totalWeight;
		isNight /= totalWeight;
	} else {
		isDay = 1.0;
		twilight = 0.0;
		blueHour = 0.0;
		isNight = 0.0;
	}

	// Force nether fog palette for all times (also drives VFOG color).
	if (isForcedNetherBiome(biome)) {
		return getForcedBiomeFogColor(biome, vec3(NETHER_FOG_R, NETHER_FOG_G, NETHER_FOG_B));
	}

	// End: atmospheric purple mist color for fog queries
	#ifdef END_FOG_ENABLED
	if (isEndDimension()) {
		return (vec3(END_FOG_R, END_FOG_G, END_FOG_B) * 3.0 + vec3(0.02, 0.01, 0.04)) * END_SKY_BRIGHTNESS;
	}
	#endif

	float wSnow = clamp(biome_snowy, 0.0, 1.0);
	float wJungle = clamp(biome_jungle, 0.0, 1.0);
	float wSwamp = clamp(biome_swamp, 0.0, 1.0);
	float wArid = clamp(biome_arid, 0.0, 1.0);

	// For matched custom biomes, force full palette override so base sky/fog colors
	// do not bleed through.
	bool hasForcedBiomeSky = (max(max(wSnow, wJungle), max(wSwamp, wArid)) > 0.001)
	                      || isForcedSnowyBiome(biome) || isCategorySnowy(biome_category)
	                      || isForcedJungleBiome(biome) || isCategoryJungle(biome_category)
	                      || isForcedSwampyBiome(biome) || isCategorySwampy(biome_category)
	                      || isForcedSavannaBiome(biome) || isCategorySavanna(biome_category)
	                      || isForcedDesertBiome(biome) || isCategoryDesert(biome_category);
	// Datapack/custom biome fallback for fog:
	// allow daytime biome tint when runtime fog/sky colors differ from configured day palette.
	// Sunset/bluehour/night remain handcrafted unless it's a forced biome override.
	vec3 baseDayHorizon = vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B);
	vec3 baseDayZenith = vec3(DAY_ZENITH_R, DAY_ZENITH_G, DAY_ZENITH_B);
	float dynZenithDelta = length(skyColor - baseDayZenith);
	float dynHorizonDelta = length(fogColor - baseDayHorizon);
	float dynDelta = max(dynZenithDelta, dynHorizonDelta);
	float dynBiomeWeight = smoothstep(0.03, 0.18, dynDelta);

	float biomeBlendStrength = hasForcedBiomeSky ? 1.0 : (SKY_BIOME_BLEND * dynBiomeWeight);
	float biomeTintDay = biomeBlendStrength;
	// Biome palette overrides are daytime-only.
	float biomeTintTwilight = 0.0;
	float biomeTintBlueHour = 0.0;
	float biomeTintNight = 0.0;

	// Sky colors from RGB settings (2-layer: horizon -> zenith)
	// Use a low height to sample near-horizon tint used by fog systems.
	float horizonHeight = 0.15;
	
	// Day colors
	vec3 dayHorizon = vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B);
	vec3 dayZenith = vec3(DAY_ZENITH_R, DAY_ZENITH_G, DAY_ZENITH_B);
	float dayBlend = smoothstep(0.0, max(DAY_ZENITH_HEIGHT, 0.001), horizonHeight);
	vec3 dayColor = mix(dayHorizon, dayZenith, dayBlend);
	vec3 biomeFogOverride = getForcedBiomeFogColorCat(biome, biome_category, fogColor);
	if (wSnow > 0.001) biomeFogOverride = mix(biomeFogOverride, vec3(230.0, 241.0, 252.0) / 255.0, wSnow);
	if (wJungle > 0.001) biomeFogOverride = mix(biomeFogOverride, vec3(81.0, 189.0, 92.0) / 255.0, wJungle);
	if (wSwamp > 0.001) biomeFogOverride = mix(biomeFogOverride, vec3(66.0, 128.0, 75.0) / 255.0, wSwamp);
	if (wArid > 0.001) biomeFogOverride = mix(biomeFogOverride, vec3(235.0, 213.0, 185.0) / 255.0, wArid);
	if (!hasForcedBiomeSky && dynBiomeWeight > 0.001) biomeFogOverride = mix(biomeFogOverride, fogColor, dynBiomeWeight);
	dayColor = mix(dayColor, biomeFogOverride, biomeTintDay);
	
	// Sunset colors
	vec3 sunsetHorizon = vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B);
	vec3 sunsetZenith = vec3(SUNSET_ZENITH_R, SUNSET_ZENITH_G, SUNSET_ZENITH_B);
	float sunsetBlend = smoothstep(0.0, max(SUNSET_ZENITH_HEIGHT, 0.001), horizonHeight);
	vec3 sunsetColor = mix(sunsetHorizon, sunsetZenith, sunsetBlend);
	sunsetColor = mix(sunsetColor, biomeFogOverride, biomeTintTwilight);
	
	// Blue hour colors
	vec3 blueHorizonC = vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B);
	vec3 blueZenith = vec3(BLUEHOUR_ZENITH_R, BLUEHOUR_ZENITH_G, BLUEHOUR_ZENITH_B);
	float blueBlend = smoothstep(0.0, max(BLUEHOUR_ZENITH_HEIGHT, 0.001), horizonHeight);
	vec3 blueColor = mix(blueHorizonC, blueZenith, blueBlend);
	blueColor = mix(blueColor, biomeFogOverride, biomeTintBlueHour);
	
	// Night colors
	vec3 nightHorizon = vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B);
	vec3 nightZenith = vec3(NIGHT_ZENITH_R, NIGHT_ZENITH_G, NIGHT_ZENITH_B);
	float nightBlend = smoothstep(0.0, max(NIGHT_ZENITH_HEIGHT, 0.001), horizonHeight);
	vec3 nightColor = mix(nightHorizon, nightZenith, nightBlend);
	nightColor = mix(nightColor, biomeFogOverride, biomeTintNight);

	// Blend colors by time of day
	float sunsetBrightnessFade = smoothstep(0.06, 0.35, rawTwilight);
	float sunsetBrightness = mix(1.0, SUNSET_BRIGHTNESS, sunsetBrightnessFade);
	vec3 color = dayColor * DAY_BRIGHTNESS * isDay
	           + sunsetColor * sunsetBrightness * twilight
	           + blueColor * BLUEHOUR_BRIGHTNESS * blueHour
	           + nightColor * NIGHT_BRIGHTNESS * isNight;

	return color;
}

// ============================================================================
// Volumetric Fog
// ============================================================================

// ============================================================================
// Horizon Fog - Non-volumetric distant atmospheric layer
// ============================================================================
#ifdef HORIZON_FOG_ENABLED
vec4 computeHorizonFog(vec2 uv, bool isSky, float sceneDistance) {
	// Get view direction in world space
	vec4 clipPos = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
	vec4 viewPos = gbufferProjectionInverse * clipPos;
	vec3 viewDir = normalize(viewPos.xyz);
	vec4 worldDir4 = gbufferModelViewInverse * vec4(viewDir, 0.0);
	vec3 worldDir = normalize(worldDir4.xyz);
	
	// Get vertical angle (Y component of normalized direction)
	// worldDir.y: -1 = looking down, 0 = horizon, +1 = looking up
	float viewAngle = worldDir.y;
	
	// Calculate fog density based on vertical position
	// Fog is densest at HFOG_HEIGHT and fades above/below
	float hfogHeight = HFOG_HEIGHT + SEA_LEVEL_OFFSET;
	float bottomBound = HFOG_BOTTOM + SEA_LEVEL_OFFSET;
	float topBound = HFOG_TOP + SEA_LEVEL_OFFSET;
	float distFromCenter = viewAngle - hfogHeight;
	
	// Calculate vertical bounds
	// bounds include SEA_LEVEL_OFFSET
	
	// Check if within fog layer
	if (viewAngle < bottomBound || viewAngle > topBound) {
		return vec4(0.0);
	}
	
	// Calculate base density (1.0 at center, fading to edges)
	float fogRange = topBound - bottomBound;
	float normalizedPos = (viewAngle - bottomBound) / fogRange;
	
	// Distance from center in normalized space (0 = center, 0.5 = edge)
	float centerHeight = (hfogHeight - bottomBound) / fogRange;
	float distFromNormCenter = abs(normalizedPos - centerHeight);
	
	// Base density - starts at 1 at center
	float density = 1.0;
	
	// Apply bottom fade
	if (viewAngle < hfogHeight && HFOG_FADE_BOTTOM > 0.001) {
		float bottomFadeStart = bottomBound + HFOG_FADE_BOTTOM;
		density *= smoothstep(bottomBound, bottomFadeStart, viewAngle);
	}
	
	// Apply top fade
	if (viewAngle > hfogHeight && HFOG_FADE_TOP > 0.001) {
		float topFadeStart = topBound - HFOG_FADE_TOP;
		density *= smoothstep(topBound, topFadeStart, viewAngle);
	}
	
	// Horizon fog only applies to sky - it should be BEHIND all geometry
	// This creates a distant atmospheric layer visible only through empty sky
	if (!isSky) {
		return vec4(0.0);
	}
	
	// Get fog color
	#ifdef HFOG_USE_SKY_COLOR
	vec3 hfogColor = getHorizonColor();
	#else
	// Time-based fog colors
	float angle = fract(sunAngle);
	
	// Calculate time weights
	float isNoon = smoothstep(0.0, 0.15, angle) * (1.0 - smoothstep(0.20, 0.35, angle));
	float isSunset = smoothstep(0.35, 0.45, angle) * (1.0 - smoothstep(0.50, 0.60, angle))
	               + smoothstep(0.90, 1.0, angle) + (1.0 - smoothstep(0.0, 0.10, angle));
	float isMidnight = smoothstep(0.60, 0.70, angle) * (1.0 - smoothstep(0.80, 0.90, angle));
	
	// Normalize weights
	float totalW = max(isNoon + isSunset + isMidnight, 0.001);
	isNoon /= totalW;
	isSunset /= totalW;
	isMidnight /= totalW;
	
	vec3 noonColor = vec3(HFOG_NOON_R, HFOG_NOON_G, HFOG_NOON_B);
	vec3 sunsetColor = vec3(HFOG_SUNSET_R, HFOG_SUNSET_G, HFOG_SUNSET_B);
	vec3 midnightColor = vec3(HFOG_MIDNIGHT_R, HFOG_MIDNIGHT_G, HFOG_MIDNIGHT_B);
	
	vec3 hfogColor = noonColor * isNoon + sunsetColor * isSunset + midnightColor * isMidnight;
	#endif
	
	// Apply brightness
	hfogColor *= HFOG_BRIGHTNESS;
	
	// Apply fog color saturation
	float hfogGray = dot(hfogColor, vec3(0.299, 0.587, 0.114));
	hfogColor = mix(vec3(hfogGray), hfogColor, VFOG_SATURATION);
	
	// Final opacity
	float opacity = density * HFOG_OPACITY;
	
	return vec4(hfogColor, opacity);
}
#endif

#if defined(VOLUMETRIC_FOG_ENABLED) || defined(NETHER_FOG_ENABLED) || defined(END_FOG_ENABLED)

// Get fog density based on world Y position
float getFogDensityAtHeight(float worldY) {
	// Calculate height factor with smooth fades
	float heightRange = VFOG_HEIGHT_TOP - VFOG_HEIGHT_BOTTOM;
	if (heightRange < 0.01) return 0.0;

	// Position within fog layer (0 at bottom, 1 at top)
	float heightPos = (worldY - VFOG_HEIGHT_BOTTOM) / heightRange;

	// Outside fog bounds
	if (heightPos < 0.0 || heightPos > 1.0) return 0.0;

	// Apply fade at bottom
	float bottomFade = 1.0;
	if (VFOG_FADE_BOTTOM > 0.01) {
		float fadeRange = VFOG_FADE_BOTTOM / heightRange;
		bottomFade = smoothstep(0.0, fadeRange, heightPos);
	}

	// Apply fade at top
	float topFade = 1.0;
	if (VFOG_FADE_TOP > 0.01) {
		float fadeRange = VFOG_FADE_TOP / heightRange;
		topFade = 1.0 - smoothstep(1.0 - fadeRange, 1.0, heightPos);
	}

	return bottomFade * topFade;
}

// Interleaved gradient noise for dithering (reduces banding in raymarched effects)
float interleavedGradientNoise(vec2 screenPos) {
	vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
	return fract(magic.z * fract(dot(screenPos, magic.xy)));
}

// 3D noise for fog variation (procedural, no texture needed)
float hash3D(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.yzx + 33.33);
	return fract((p.x + p.y) * p.z);
}

float noise3D(vec3 p) {
	vec3 i = floor(p);
	vec3 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	
	return mix(
		mix(mix(hash3D(i), hash3D(i + vec3(1,0,0)), f.x),
			mix(hash3D(i + vec3(0,1,0)), hash3D(i + vec3(1,1,0)), f.x), f.y),
		mix(mix(hash3D(i + vec3(0,0,1)), hash3D(i + vec3(1,0,1)), f.x),
			mix(hash3D(i + vec3(0,1,1)), hash3D(i + vec3(1,1,1)), f.x), f.y), f.z);
}

// Mie phase function for light scattering (forward scattering around sun)
// Returns clamped value to prevent sun burn-through in fog
float miePhase(float cosTheta, float g) {
	float g2 = g * g;
	float denom = 1.0 + g2 - 2.0 * g * cosTheta;
	float phase = (1.0 - g2) / (4.0 * 3.14159 * pow(denom, 1.5));
	// Clamp phase to prevent extreme values near sun direction
	return min(phase, 3.0);
}

// Get time-based fog modifier (0.0 to 1.0)
// Blends between VFOG_TIME_* settings based on current sun position
float getTimeFogModifier() {
	float angle = fract(sunAngle);
	
	// Time phases - overlapping smoothly with no gaps
	// sunAngle: 0.0 = sunrise, 0.25 = noon, 0.5 = sunset, 0.75 = midnight
	
	// Noon: centered at 0.25, spans 0.0-0.5
	float noon = smoothstep(0.0, 0.25, angle) * (1.0 - smoothstep(0.25, 0.5, angle));
	
	// Sunset: centered at 0.5, spans 0.25-0.75
	float sunset = smoothstep(0.25, 0.5, angle) * (1.0 - smoothstep(0.5, 0.75, angle));
	
	// Midnight: centered at 0.75, spans 0.5-1.0
	float midnight = smoothstep(0.5, 0.75, angle) * (1.0 - smoothstep(0.75, 1.0, angle));
	
	// Sunrise: centered at 0.0/1.0, spans 0.75-0.25 (wrapping)
	float sunrise = max(smoothstep(0.75, 1.0, angle), 1.0 - smoothstep(0.0, 0.25, angle));
	
	// Normalize so they always sum to ~1
	float total = max(noon + sunset + midnight + sunrise, 0.25);
	noon /= total;
	sunset /= total;
	midnight /= total;
	sunrise /= total;
	
	// Convert slider values (0-100) to multipliers (0.0-1.0)
	float noonMod = float(VFOG_TIME_NOON) / 100.0;
	float sunsetMod = float(VFOG_TIME_SUNSET) / 100.0;
	float midnightMod = float(VFOG_TIME_MIDNIGHT) / 100.0;
	float sunriseMod = float(VFOG_TIME_SUNRISE) / 100.0;
	
	return noon * noonMod + sunset * sunsetMod + midnight * midnightMod + sunrise * sunriseMod;
}

// Get time-based fog brightness modifier
float getTimeFogBrightness() {
	float angle = fract(sunAngle);
	
	// Same time phases as getTimeFogModifier
	float noon = smoothstep(0.0, 0.25, angle) * (1.0 - smoothstep(0.25, 0.5, angle));
	float sunset = smoothstep(0.25, 0.5, angle) * (1.0 - smoothstep(0.5, 0.75, angle));
	float midnight = smoothstep(0.5, 0.75, angle) * (1.0 - smoothstep(0.75, 1.0, angle));
	float sunrise = max(smoothstep(0.75, 1.0, angle), 1.0 - smoothstep(0.0, 0.25, angle));
	
	float total = max(noon + sunset + midnight + sunrise, 0.25);
	noon /= total;
	sunset /= total;
	midnight /= total;
	sunrise /= total;
	
	// Brightness multipliers per time of day
	return noon * VFOG_BRIGHT_NOON + sunset * VFOG_BRIGHT_SUNSET + midnight * VFOG_BRIGHT_MIDNIGHT + sunrise * VFOG_BRIGHT_SUNRISE;
}

// Get fog density at world position
float getFogDensity(vec3 worldPos, float distFromCam, bool isSky) {
	#ifdef NETHER_FOG_ENABLED
	// Nether: constant density fog, ignores height band.
	// Beer-Lambert handles depth naturally ? density controls thickness,
	// distance controls how much fog accumulates along the ray.
	if (isForcedNetherBiome(biome)) {
		if (distFromCam < NETHER_DISTANCE_FOG_START) return 0.0;
		return NETHER_DISTANCE_FOG_OPACITY * 0.04;
	}
	#endif

	#ifdef END_FOG_ENABLED
	// End: light atmospheric haze ? low density so it adds glow without obscuring
	if (isEndDimension()) {
		if (distFromCam < END_FOG_START) return 0.0;
		return END_FOG_DENSITY * 0.015;
	}
	#endif

	float y = worldPos.y;
	float vfogBottom = VFOG_HEIGHT_BOTTOM + SEA_LEVEL_OFFSET;
	float vfogTop = VFOG_HEIGHT_TOP + SEA_LEVEL_OFFSET;
	
	// Height-based density - fog only exists between VFOG_HEIGHT_BOTTOM and VFOG_HEIGHT_TOP
	// Outside this range = no fog
	if (y < vfogBottom - VFOG_FADE_BOTTOM || y > vfogTop + VFOG_FADE_TOP) {
		return 0.0;
	}
	
	// Core fog density (1.0 inside fog layer)
	float heightFactor = 1.0;
	
	// Smooth fade at bottom edge
	if (VFOG_FADE_BOTTOM > 0.01 && y < vfogBottom) {
		heightFactor *= smoothstep(vfogBottom - VFOG_FADE_BOTTOM, vfogBottom, y);
	}
	
	// Smooth fade at top edge - this is key for preventing sky bleed
	if (VFOG_FADE_TOP > 0.01 && y > vfogTop - VFOG_FADE_TOP) {
		heightFactor *= 1.0 - smoothstep(vfogTop - VFOG_FADE_TOP, vfogTop, y);
	}
	
	// Extra hard cutoff above fog layer top
	if (y > vfogTop) {
		return 0.0;
	}
	
	// Distance-based density - fog builds up with distance from camera
	float distFactor = clamp((distFromCam - VFOG_START_DISTANCE) / (VFOG_DEPTH_DISTANCE - VFOG_START_DISTANCE), 0.0, 1.0);

	// Uniform fog density - higher multiplier for denser fog capability
	return heightFactor * distFactor * VFOG_DENSITY * 0.3;
}

float getVFogRenderDistance() {
	#ifdef FAKE_TERRAIN_ENABLED
	// Keep volumetric fog coverage aligned with fake terrain reach.
	return max(float(VFOG_DISTANCE), FAKE_TERRAIN_DISTANCE);
	#else
	return float(VFOG_DISTANCE);
	#endif
}

// Main volumetric fog computation
// Returns: vec4(scatteredLight, transmittance) where transmittance is 1=clear, 0=fully fogged
vec4 computeVolumetricFog(vec2 uv, float sceneDepth, vec3 sceneWorldPos, bool isSky, bool fromDH) {
	vec3 camPos = cameraPosition;
	vec3 rayDir = normalize(sceneWorldPos - camPos);
	bool netherFullFog = isForcedNetherBiome(biome);
	bool endFullFog = isEndDimension();

	// Dedicated Nether fog path: independent from VFOG settings and raymarch.
	if (netherFullFog) {
		float sceneDist = length(sceneWorldPos - camPos);
		float fogStart = max(NETHER_DISTANCE_FOG_START, 0.0);
		float fogEnd = max(float(NETHER_FOG_DISTANCE), fogStart + 1.0);
		float depthT = clamp((sceneDist - fogStart) / max(fogEnd - fogStart, 1.0), 0.0, 1.0);
		float density = max(NETHER_DISTANCE_FOG_OPACITY, 0.01);
		float fogAmount = 1.0 - exp(-depthT * depthT * density * 2.2);
		fogAmount = clamp(fogAmount, 0.0, 0.98);

		vec3 netherFogColor = getForcedBiomeFogColor(biome, vec3(NETHER_FOG_R, NETHER_FOG_G, NETHER_FOG_B));
		netherFogColor *= NETHER_BRIGHTNESS;
		return vec4(netherFogColor, fogAmount);
	}

	#ifndef VOLUMETRIC_FOG_ENABLED
	// If main volumetric fog is disabled, ONLY allow Nether and End fog
	if (!netherFullFog && !endFullFog) return vec4(0.0);
	#endif

	// For sky rays looking up: if camera is above fog layer, skip fog entirely
	// (Nether/End ignore height band, so never skip sky fog there)
	float vfogTop = VFOG_HEIGHT_TOP + SEA_LEVEL_OFFSET;
	if (isSky && rayDir.y > 0.1 && camPos.y > vfogTop && !netherFullFog && !endFullFog) {
		return vec4(vec3(0.0), 0.0); // No fog
	}
	
	// Shafts (god rays) allowed when camera is inside or near the fog layer
	float vfogBottomS = VFOG_HEIGHT_BOTTOM + SEA_LEVEL_OFFSET;
	bool shaftsAllowed = (camPos.y <= vfogTop + 16.0);

	// Raymarch distance - use scene distance or max fog distance
	float sceneDist = length(sceneWorldPos - camPos);
	if (netherFullFog && fromDH) {
		sceneDist *= 0.82;
	}
	float vfogRenderDistance = getVFogRenderDistance();
	// Nether/End use their own shorter max distance for vanilla blocks,
	// but must extend to the full scene distance for DH LODs to ensure
	// LODs far away get completely swallowed by the dense fog.
	if (netherFullFog) {
		vfogRenderDistance = fromDH ? max(sceneDist, float(NETHER_FOG_DISTANCE)) : float(NETHER_FOG_DISTANCE);
	}
	if (endFullFog) {
		vfogRenderDistance = fromDH ? max(sceneDist, float(END_FOG_DISTANCE)) : float(END_FOG_DISTANCE);
	}
	float maxDist = min(sceneDist, vfogRenderDistance);

	// For sky: limit raymarch to where fog layer ends
	// (Nether/End fill the whole volume, so always use full render distance for sky)
	if (endFullFog && isSky) {
		// End sky: don't fog sky pixels ? the procedural End sky is the background
		return vec4(vec3(0.0), 0.0);
	} else if (netherFullFog && isSky) {
		maxDist = vfogRenderDistance;
	} else if (isSky && rayDir.y > 0.0) {
		// Calculate how far until ray exits fog layer top
		float distToTop = (vfogTop - camPos.y) / max(rayDir.y, 0.001);
		maxDist = min(maxDist, max(distToTop, 0.0));
	} else if (isSky && rayDir.y <= 0.0) {
		// For sky rays that are NOT going upward, use full distance
		maxDist = vfogRenderDistance;
	}
	
	// Skip if too close
	if (maxDist < VFOG_START_DISTANCE) return vec4(0.0, 0.0, 0.0, 0.0);
	
	// DEBUG: Test with fixed red fog to verify pipeline
	// TODO: Remove this after debugging
	// float debugDist = min(maxDist, 512.0);
	// float debugOpacity = 1.0 - exp(-debugDist * 0.01);
	// vec3 debugFogColor = vec3(0.8, 0.2, 0.1);
	// return vec4(debugFogColor, debugOpacity);
	
	// Fog/sky color from horizon - use color directly, brightness only affects opacity
	vec3 fogLightColor = getHorizonColor();

	// Compute twilight weight (used for shadow floor adjustment below)
	float vfogAngle = fract(sunAngle);
	float vfogTwilight = smoothstep(0.40, 0.46, vfogAngle) * (1.0 - smoothstep(0.52, 0.58, vfogAngle))
	                   + smoothstep(0.94, 1.0, vfogAngle) + (1.0 - smoothstep(0.0, 0.06, vfogAngle));

	// Disabled explicit warm fog push: this was causing a visible yellow snap at dusk.

	// Sun direction in world space for phase function
	vec3 sunDirView = normalize(shadowLightPosition);
	vec3 sunDirWorld = normalize(mat3(gbufferModelViewInverse) * sunDirView);
	float cosTheta = dot(rayDir, sunDirWorld);
	
	// Phase function - brighter when looking towards sun
	// Use lower anisotropy (g=0.4) to reduce extreme forward scattering
	// Clamp the multiplier to prevent massive sun sphere
	float rawPhase = miePhase(cosTheta, 0.4);
	float phase = min(rawPhase * 0.8 + 0.5, 2.5);
	
	// Additional angular falloff to prevent sun burn-through
	// Reduce phase intensity when looking directly at sun
	float sunProximity = max(cosTheta - 0.9, 0.0) * 10.0; // 0 normally, up to 1 at sun center
	phase = mix(phase, 1.0, sunProximity * 0.7); // Flatten phase near sun
	
	// Time of day brightness - supports both sun and moon light shafts
	float angle = fract(sunAngle);
	// Day: 0.0 - 0.5, Night: 0.5 - 1.0
	float dayBright = smoothstep(0.0, 0.16, angle) * (1.0 - smoothstep(0.46, 0.66, angle));
	float nightBright = smoothstep(0.52, 0.60, angle) * (1.0 - smoothstep(0.90, 0.98, angle));
	float lightBrightness = max(dayBright * 1.0, nightBright * VFOG_MOON_BRIGHTNESS);
	lightBrightness = max(lightBrightness, 0.15); // Minimum during transitions

	// Raymarch settings
	int steps = VFOG_STEPS;
	
	// Smooth dithering for raymarching
	// Use screen-space interleaved gradient noise (very low frequency, minimal pattern)
	float dither = interleavedGradientNoise(gl_FragCoord.xy);
	
	vec3 scatteredLight = vec3(0.0);
	float transmittance = 1.0;
	float stepSize = maxDist / float(steps);
	
	// Shadow accumulation along ray (resets each frame, blends along ray march)
	vec3 smoothShadow = vec3(1.0);
	
	for (int i = 0; i < steps; i++) {
		// Linear stepping with dither
		float dist = (float(i) + dither) * stepSize;
		
		// Skip samples within clear zone around player
		if (dist < VFOG_START_DISTANCE) continue;
		
		vec3 samplePos = camPos + rayDir * dist;
		
		// Get fog density at this point (pass distance for depth-based density)
		float density = getFogDensity(samplePos, dist, isSky);
		
		if (density > 0.0001) {
			// Beer-Lambert extinction uses base density (not boosted)
			float fogCoeff = exp(-density * stepSize);
			
			// Sample colored shadow with smooth blending to prevent artifacts
			vec3 shadowColor = vec3(1.0);
			#if defined(VFOG_GOD_RAYS) && defined(SHADOWS_ENABLED)
			// Shadow sampling range - use most of the shadow map
			float shadowMaxDist = SHADOW_DISTANCE * 0.85;
			float shadowFadeStart = SHADOW_DISTANCE * 0.7;
			// Min distance to avoid player shadow imprinting into shafts
			float godRayShadowMinDist = max(VFOG_START_DISTANCE + 4.0, 16.0);

			bool doShadowSample = !netherFullFog && !endFullFog && shaftsAllowed && dist > godRayShadowMinDist && dist < shadowMaxDist && isEyeInWater != 1;
			#ifndef VFOG_GOD_RAYS
			doShadowSample = false;
			#endif

			if (doShadowSample) {
				vec3 rawShadow = sampleColoredShadowWorld(samplePos);
				// Smoothing controlled by setting - lower = sharper but noisier
				smoothShadow = mix(smoothShadow, rawShadow, VFOG_GOD_RAY_SMOOTHING);

				// Fade out god ray influence near shadow map edge (prevents chunk loading artifacts)
				float distanceFade = 1.0 - smoothstep(shadowFadeStart, shadowMaxDist, dist);

				// Apply sharpness using smoothstep-based curve (smoother than pow, less noise)
				float sharpness = VFOG_GOD_RAY_SHARPNESS;
				vec3 sharpShadow;
				if (sharpness > 1.0) {
					float edge = 0.5 / sharpness;
					sharpShadow = smoothstep(vec3(edge), vec3(1.0 - edge), smoothShadow);
				} else {
					sharpShadow = smoothShadow;
				}

				// Blend toward fully lit (1.0) as we approach shadow edge
				sharpShadow = mix(vec3(1.0), sharpShadow, distanceFade);

				// Intensity controls how DARK shadows get (lit areas stay at 1.0)
				float godRayIntensity = VFOG_GOD_RAY_INTENSITY;
				float shadowFloor = 0.02 / max(godRayIntensity, 0.1);
				shadowFloor = clamp(shadowFloor, 0.0, 0.5);
				// At sunset/sunrise: raise shadow floor so dark areas are less harsh
				shadowFloor = mix(shadowFloor, max(shadowFloor, 0.35), vfogTwilight);

				// Lit areas stay at 1.0, shadowed areas go to a tinted floor.
				// Add tint color so shadows are colorful instead of pure black.
				vec3 tintColor = getFogShadowTint();
				float tintStrength = clamp(VFOG_GOD_RAY_TINT_STRENGTH, 0.0, 2.0);
				vec3 tintedFloor = vec3(shadowFloor) + tintColor * tintStrength * 0.03;
				shadowColor = mix(tintedFloor, vec3(1.0), sharpShadow);
			}
			#endif // VFOG_GOD_RAYS && SHADOWS_ENABLED
			
			// Debug mode - shows shadow as yellow (lit) vs dark (shadow)
			#ifdef VFOG_GOD_RAYS_DEBUG
			vec3 lighting = shadowColor;
			#else
			// Dimension-specific lighting with shadow modulation
			vec3 lighting;
			if (netherFullFog) {
				lighting = fogLightColor;
			} else if (endFullFog) {
				lighting = fogLightColor;
			} else {
				lighting = fogLightColor * shadowColor * phase * lightBrightness;
			}
			// Brighter shafts near the player (do NOT brighten shadowed fog):
			// boost only the lit portion using a scalar multiplier (preserves tint/saturation).
			if (!netherFullFog) {
				float nearFactor = 1.0 - smoothstep(VFOG_START_DISTANCE, VFOG_START_DISTANCE + 56.0, dist);
				float litness = clamp(dot(shadowColor, vec3(0.3333333)), 0.0, 1.0);
				lighting *= 1.0 + nearFactor * 0.35 * litness;
			}
			#endif
			
			// Accumulate scattered light (energy conserving)
			scatteredLight += lighting * (1.0 - fogCoeff) * transmittance;
			
			// Update transmittance
			transmittance *= fogCoeff;
			
			// Early exit
			if (transmittance < 0.005) break;
		}
	}
	
	// Apply scattering intensity
	scatteredLight *= VFOG_SCATTERING;

	// Convert to opacity format for simple mix() blend
	float fogOpacity = 1.0 - transmittance;

	// Above the fog top: heavily attenuate sky fog so high-altitude views don't blow out.
	// Keep a small amount when looking down into the fog layer for depth cues.
	if (isSky && !netherFullFog && !endFullFog && camPos.y > vfogTop) {
		float aboveTop = camPos.y - vfogTop;
		float altitudeFade = 1.0 - smoothstep(2.0, 28.0, aboveTop);
		float downAngle = max(-rayDir.y, 0.0); // 0=horizon/up, 1=straight down
		float directionalKeep = mix(0.08, 0.40, downAngle);
		fogOpacity *= directionalKeep * altitudeFade;
	}
	
	// Apply time-based fog modifier to opacity (skip for nether/end ? no day cycle)
	if (!netherFullFog && !endFullFog) {
		float timeMod = getTimeFogModifier();
		fogOpacity *= timeMod;
	}

	// Sky haze safety: keep only a tiny near-horizon fallback.
	// This avoids the artificial sky film/dome look while preserving horizon continuity.
	if (isSky && !netherFullFog && !endFullFog) {
		float horizonBand = 1.0 - smoothstep(-0.02, 0.06, rayDir.y);
		float skyHaze = horizonBand * horizonBand * (VFOG_DENSITY * 0.03);
		skyHaze = clamp(skyHaze, 0.0, 0.06);
		// Only apply fallback haze when fog march did not already produce visible fog.
		float hazeNeed = 1.0 - smoothstep(0.01, 0.12, fogOpacity);
		fogOpacity = max(fogOpacity, skyHaze * hazeNeed);
	}

	// Normalize scattered light by opacity to get proper fog COLOR for mix() blend
	// This gives us: what color should the fog be when fully opaque?
	float baseFogBrightness = VFOG_BRIGHTNESS * ((netherFullFog || endFullFog) ? 0.72 : 1.0);
	vec3 fogColorFinal = fogLightColor * baseFogBrightness; // Base fog color
	// Avoid over-bright sky when fog is thin: scatter normalization is unstable at low opacity.
	float normMinOpacity = isSky ? 0.10 : 0.02;
	bool useScatterNormalize = !netherFullFog && !endFullFog && fogOpacity > normMinOpacity;
	if (useScatterNormalize) {
		// Blend with accumulated scattering for god ray variation
		vec3 normalizedScatter = scatteredLight / fogOpacity;
		// Clamp to reasonable range
		normalizedScatter = min(normalizedScatter, fogLightColor * (isSky ? 1.35 : 3.0));
		// Mix base fog with god ray variation - keep most of the spatial variation
		float scatterMix = isSky ? 0.35 : 0.85;
		fogColorFinal = mix(fogLightColor * VFOG_BRIGHTNESS, normalizedScatter * VFOG_BRIGHTNESS, scatterMix);
	}

	// Sky safety clamp: fog should not brighten sky when entering dense low clouds/fog.
	if (isSky && !netherFullFog && !endFullFog) {
		vec3 skyFogCap = fogLightColor * baseFogBrightness;
		fogColorFinal = min(fogColorFinal, skyFogCap);
		// Extra high-altitude guard: above fog top, only allow dim fog color contribution.
		if (camPos.y > vfogTop) {
			fogColorFinal = min(fogColorFinal, fogLightColor * (baseFogBrightness * 0.92));
		}
	}
	
	// Apply fog color saturation (global control for all fog colors)
	float fogGray = dot(fogColorFinal, vec3(0.299, 0.587, 0.114));
	fogColorFinal = mix(vec3(fogGray), fogColorFinal, VFOG_SATURATION);

	// Nether full-volume tuning: per-biome fog color, custom RGB for nether wastes.
	if (netherFullFog) {
		vec3 biomeFog = getForcedBiomeFogColor(biome, vec3(NETHER_FOG_R, NETHER_FOG_G, NETHER_FOG_B));
		fogColorFinal = biomeFog * NETHER_BRIGHTNESS;
	}

	// End atmospheric fog ? purple mist, not darkening
	if (endFullFog) {
		vec3 endMist = vec3(END_FOG_R, END_FOG_G, END_FOG_B) * 3.0 + vec3(0.02, 0.01, 0.04);
		fogColorFinal = endMist * VFOG_BRIGHTNESS;
		#if defined(END_SHADER) && defined(END_EVENT_ENABLED)
		// Fade out purple mist during event darkness so it doesn't illuminate surfaces
		float vfogEventDark = getEndEvent(frameTimeCounter).fogDarkness;
		fogColorFinal *= (1.0 - vfogEventDark);
		#endif
	}

	return vec4(fogColorFinal, fogOpacity);
}
#endif

float getOutline(in ivec2 iUv) {
	// Get combined depth (MC + DH)
	float zC = linearizeCombinedDepth(iUv);

	int pixelSize = OUTLINE_PIXEL_SIZE;

	ivec2 topRightCorner = iUv - pixelSize;
	ivec2 bottomLeftCorner = iUv + pixelSize;

	// Sample depths at center and all corners
	float depthMC = texelFetch(depthtex0, iUv, 0).x;
	float depthDH = texelFetch(dhDepthTex, iUv, 0).x;

	float mc0 = texelFetch(depthtex0, topRightCorner, 0).x;
	float mc1 = texelFetch(depthtex0, bottomLeftCorner, 0).x;
	float mc2 = texelFetch(depthtex0, ivec2(topRightCorner.x, bottomLeftCorner.y), 0).x;
	float mc3 = texelFetch(depthtex0, ivec2(bottomLeftCorner.x, topRightCorner.y), 0).x;

	float dh0 = texelFetch(dhDepthTex, topRightCorner, 0).x;
	float dh1 = texelFetch(dhDepthTex, bottomLeftCorner, 0).x;
	float dh2 = texelFetch(dhDepthTex, ivec2(topRightCorner.x, bottomLeftCorner.y), 0).x;
	float dh3 = texelFetch(dhDepthTex, ivec2(bottomLeftCorner.x, topRightCorner.y), 0).x;

	// Determine what type of terrain each sample is
	bool centerIsMC = depthMC < 0.9999;
	bool centerIsDH = depthMC >= 0.9999 && hasValidDHDepth(depthDH);

	bool neighbor0IsMC = mc0 < 0.9999;
	bool neighbor1IsMC = mc1 < 0.9999;
	bool neighbor2IsMC = mc2 < 0.9999;
	bool neighbor3IsMC = mc3 < 0.9999;

	bool neighbor0IsDH = mc0 >= 0.9999 && hasValidDHDepth(dh0);
	bool neighbor1IsDH = mc1 >= 0.9999 && hasValidDHDepth(dh1);
	bool neighbor2IsDH = mc2 >= 0.9999 && hasValidDHDepth(dh2);
	bool neighbor3IsDH = mc3 >= 0.9999 && hasValidDHDepth(dh3);

	// Skip outline at MC/DH boundaries (from either side)
	if (centerIsMC) {
		// Current pixel is MC terrain - check if any neighbor is DH terrain
		if (neighbor0IsDH || neighbor1IsDH || neighbor2IsDH || neighbor3IsDH) {
			return 0.0;
		}
	}

	if (centerIsDH) {
		// Current pixel is DH terrain - check if any neighbor is MC terrain
		if (neighbor0IsMC || neighbor1IsMC || neighbor2IsMC || neighbor3IsMC) {
			return 0.0;
		}

		// Check for huge depth jumps within DH (LOD transitions / chunk borders)
		// Only compare neighbors that HAVE valid DH depth ? sky pixels are skipped.
		// This allows silhouette outlines against sky while still suppressing
		// artifacts at DH chunk loading boundaries.
		float zCenter = linearizeDepthDH(depthDH);
		float maxZ = zCenter;
		float minZ = zCenter;

		if (neighbor0IsDH) { float z = linearizeDepthDH(dh0); maxZ = max(maxZ, z); minZ = min(minZ, z); }
		if (neighbor1IsDH) { float z = linearizeDepthDH(dh1); maxZ = max(maxZ, z); minZ = min(minZ, z); }
		if (neighbor2IsDH) { float z = linearizeDepthDH(dh2); maxZ = max(maxZ, z); minZ = min(minZ, z); }
		if (neighbor3IsDH) { float z = linearizeDepthDH(dh3); maxZ = max(maxZ, z); minZ = min(minZ, z); }

		// Large depth discontinuity between valid DH pixels = LOD/chunk border
		if (maxZ - minZ > 100.0) {
			return 0.0;
		}
	}

	#if OUTLINES == 1
		float depth0 = near / (1.0 - sampleCombinedDepth(topRightCorner));
		float depth1 = near / (1.0 - sampleCombinedDepth(bottomLeftCorner));
		float depth2 = near / (1.0 - sampleCombinedDepth(ivec2(topRightCorner.x, bottomLeftCorner.y)));
		float depth3 = near / (1.0 - sampleCombinedDepth(ivec2(bottomLeftCorner.x, topRightCorner.y)));

		float sumDepth = depth0 + depth1 + depth2 + depth3;
		float depthOrigin = sampleCombinedDepth(iUv);
		return saturate(sumDepth - (near * 4.0) / (1.0 - depthOrigin));
	#else
		float z0 = linearizeCombinedDepth(topRightCorner);
		float z1 = linearizeCombinedDepth(bottomLeftCorner);
		float z2 = linearizeCombinedDepth(ivec2(topRightCorner.x, bottomLeftCorner.y));
		float z3 = linearizeCombinedDepth(ivec2(bottomLeftCorner.x, topRightCorner.y));

		float dz0 = z0 - zC;
		float dz1 = z1 - zC;
		float dz2 = z2 - zC;
		float dz3 = z3 - zC;

		float maxBehind = max(max(max(dz0, dz1), dz2), dz3);

		float diagonal1 = abs(dz0 - dz1);
		float diagonal2 = abs(dz2 - dz3);
		float edgeness = max(diagonal1, diagonal2);

		float rel = maxBehind / max(zC, 1.0);
		float edgeRel = edgeness / max(zC, 1.0);

		// Tighter threshold - require sharper edges to trigger outlines
		// Prevents false positives from grazing angles on flat surfaces
		return smoothstep(0.10, 0.22, rel) * smoothstep(0.05, 0.12, edgeRel);
	#endif
}

// ============================================================================
// Water Screen-Space Reflections (SSR) - Based on I Like Vanilla
// ============================================================================
#ifdef WATER_REFLECTIONS_ENABLED

// SSR implementation replaced by includes

#endif // WATER_REFLECTIONS_ENABLED

// Smooth value noise for organic underwater caustics
#ifdef UNDERWATER_LIGHT_SHAFTS
float uwHash(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}

float uwSmoothNoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = uwHash(i);
	float b = uwHash(i + vec2(1.0, 0.0));
	float c = uwHash(i + vec2(0.0, 1.0));
	float d = uwHash(i + vec2(1.0, 1.0));
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float waterCaustic(vec2 uv, float time) {
	float n1 = uwSmoothNoise(uv * 3.0 + time * 0.3);
	float n2 = uwSmoothNoise(uv * 6.0 - time * 0.2);
	float n3 = uwSmoothNoise(uv * 12.0 + time * 0.15);
	float caustic = n1 * 0.5 + n2 * 0.3 + n3 * 0.2;
	return smoothstep(0.45, 0.75, caustic);
}
#endif

void main() {
	vec2 texelSize = 1.0 / vec2(textureSize(colortex0, 0));
	vec2 distortedUV = texcoord;

	vec3 color = texture(colortex0, distortedUV).rgb;
	float cloudMask = texture(colortex0, distortedUV).a;
	float cloudAlpha = 1.0 - cloudMask;
	float outlineMask = texture(colortex1, texcoord).r;

	// Track fog amount for outline fading
	float fogAmount = 0.0;
	float chunkBorderFogAmount = 0.0;
	vec3 chunkBorderFogColor = vec3(0.0);
	
	// Glass tint from gbuffers_water (used for fog-behind-glass and bloom tinting)
	vec4 glassTint = texture(colortex4, texcoord);

	// ========================================================================
	// Glass Color Enforcement (stained-glass style transmission)
	// ========================================================================
	#ifdef GLASS_FILTER_ENABLED
	{
		ivec2 texelCoordGF = ivec2(gl_FragCoord.xy);
		float depthAllGF = texelFetch(depthtex0, texelCoordGF, 0).x;   // With translucents
		float depthOpaqueGF = texelFetch(depthtex1, texelCoordGF, 0).x; // Opaque only (behind glass)
		bool isTranslucentGF = (depthAllGF < depthOpaqueGF - 0.00001);

		// Water writes a lower alpha (currently ~0.3). Glass writes higher (currently ~0.6).
		bool isGlassLikeGF = (glassTint.a > 0.45);

		float gfStrength = clamp(glassTint.a * GLASS_FILTER_STRENGTH, 0.0, 1.0);
		gfStrength *= (isTranslucentGF && isGlassLikeGF) ? 1.0 : 0.0;

		if (gfStrength > 0.0001) {
			vec3 tint = max(glassTint.rgb, vec3(0.0));
			// Boost saturation of the tint color
			float tLum0 = dot(tint, vec3(0.299, 0.587, 0.114));
			tint = mix(vec3(tLum0), tint, GLASS_FILTER_SATURATION);

			// Normalize tint so it preserves overall brightness better
			float tLum = max(dot(tint, vec3(0.299, 0.587, 0.114)), 0.25);
			vec3 tintNorm = clamp(tint / tLum, vec3(0.0), vec3(3.0));

			float lum = dot(color, vec3(0.299, 0.587, 0.114));
			vec3 multiplied = color * tintNorm;
			vec3 enforced = lum * tintNorm;
			vec3 target = mix(multiplied, enforced, clamp(GLASS_FILTER_ENFORCEMENT, 0.0, 1.0));

			color = mix(color, target, gfStrength);
		}
	}
	#endif

	// NOTE: Water reflections are now handled in composite7.fsh using ILV's algorithm
	// The old reflection code has been removed from here

	// Track fake terrain hit so volumetric fog can be composited above it.
	bool fakeTerrainHitForFog = false;
	vec3 fakeTerrainFogWorldPos = vec3(0.0);

	// ========================================================================
	// Fake Horizon Water (fills gaps beyond DH LODs with ocean)
	// ========================================================================
	#ifdef FAKE_TERRAIN_ENABLED
	{
		// Fake terrain horizon plane is for overworld/ocean filling.
		// In Nether it can appear as a moving horizontal band against DH LODs.
		if (!isForcedNetherBiome(biome) && !isEndDimension()) {
		float ftDepth = texture(depthtex0, texcoord).x;
		float ftDhDepth = texture(dhDepthTex, texcoord).x;
		// Disable fake terrain when DH is not active.
		// Probe a few fixed lowest-screen points too, so sky-center views still detect DH.
		float ftDhProbe1 = texture(dhDepthTex, vec2(0.5, 0.05)).x;
		float ftDhProbe2 = texture(dhDepthTex, vec2(0.15, 0.05)).x;
		float ftDhProbe3 = texture(dhDepthTex, vec2(0.85, 0.05)).x;
		bool dhActiveForFakeTerrain = hasValidDHDepth(ftDhDepth) || hasValidDHDepth(ftDhProbe1) || hasValidDHDepth(ftDhProbe2) || hasValidDHDepth(ftDhProbe3) || (dhFarPlane > far * 1.5);
		if (!dhActiveForFakeTerrain) {
			// Skip entire fake terrain path when DH is off.
		} else {

		bool hasDhAtFtPixel = hasValidDHDepth(ftDhDepth);
		bool isSky = (ftDepth >= 0.9999 && !hasDhAtFtPixel);

		// Check if DH geometry at this pixel is below water level
		bool dhBelowWater = false;
		if (!isSky && ftDepth >= 0.9999 && hasDhAtFtPixel) {
			vec3 dhWorldPos = getWorldPosDH(texcoord, ftDhDepth);
			dhBelowWater = (dhWorldPos.y < float(FAKE_TERRAIN_Y));
		}

		if (isSky || dhBelowWater) {
			// Get view ray direction (world space)
			vec4 ftClipFar = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
			vec4 ftViewFar = gbufferProjectionInverse * ftClipFar;
			ftViewFar /= ftViewFar.w;
			vec3 ftRayDir = normalize(mat3(gbufferModelViewInverse) * ftViewFar.xyz);

			// Ray-plane intersection with Y = FAKE_TERRAIN_Y (water level)
			float planeY = float(FAKE_TERRAIN_Y);
			float camY = cameraPosition.y;

			if (camY > planeY) {
				// Above water: evaluate true mathematical ray-plane intersection.
				// (The previous global "pop out" issue was fixed via robust lowest-point DH screen probes,
				// so we no longer need to synthesize physically impossible upward sky hits).
				float t = -1.0;
				if (ftRayDir.y < -0.001) {
					// Looking down: exact plane intersection.
					t = (planeY - camY) / ftRayDir.y;
				}

				if (t > 0.0 && t < FAKE_TERRAIN_DISTANCE) {
					vec3 hitPos = cameraPosition + ftRayDir * t;
					float hitDist = length(hitPos - cameraPosition);

					if (hitDist > FAKE_TERRAIN_START) {
						vec3 waterColor = vec3(WATER_COLOR_R, WATER_COLOR_G, WATER_COLOR_B);

						// --- Shared water lighting (matches MC + DH water exactly) ---
						vec3 litColor = waterLitColor(waterColor, sunAngle);

						// --- Specular (shared formula) ---
						vec3 viewDir = -ftRayDir;
						vec3 waterNormal = vec3(0.0, 1.0, 0.0);
						vec3 viewDirView = normalize(mat3(gbufferModelView) * viewDir);
						vec3 waterNormalView = normalize(mat3(gbufferModelView) * waterNormal);
						litColor += waterSpecular(viewDirView, normalize(shadowLightPosition), waterNormalView, sunAngle);

						// --- Sky + cloud reflection (matching composite7 DH water formula) ---
						vec3 reflDirView = reflect(normalize(-viewDirView), waterNormalView);
						vec3 reflDirWorld = reflect(-viewDir, waterNormal);

						// Build sky color (ilv_getSkyColor inline)
						float ilvDay = smoothstep(0.02, 0.10, fract(sunAngle)) * smoothstep(0.48, 0.40, fract(sunAngle));
						float ilvSS = smoothstep(0.40, 0.46, fract(sunAngle)) * smoothstep(0.58, 0.52, fract(sunAngle))
						            + smoothstep(0.94, 1.0, fract(sunAngle)) + smoothstep(0.06, 0.0, fract(sunAngle));
						float upDot = max(dot(reflDirView, gbufferModelView[1].xyz), 0.0);
						vec3 skCol = mix(vec3(0.01, 0.012, 0.025), vec3(0.4, 0.65, 1.0), ilvDay);
						vec3 horizCol = mix(vec3(0.02, 0.025, 0.05), vec3(0.7, 0.85, 1.0), ilvDay);
						float hAmt = 1.0 - upDot; hAmt *= hAmt; hAmt *= hAmt; hAmt = 1.0 - hAmt;
						skCol = mix(horizCol, skCol, hAmt);
						float sDot = dot(reflDirView, normalize(shadowLightPosition)) * 0.5 + 0.5;
						sDot = 1.0 - (1.0 - sDot) * (1.0 - sDot);
						sDot *= (1.0 - upDot) * (1.0 - (1.0 - ilvSS) * (1.0 - ilvSS));
						skCol = mix(skCol, (sunAngle > 0.25 && sunAngle < 0.75) ? vec3(1.0, 0.5, 0.3) : vec3(1.0, 0.6, 0.35), sDot);
						skCol = min(skCol, 1.0);
						skCol = 1.0 - (skCol - 1.0) * (skCol - 1.0);
						skCol *= 1.2 * (0.3 + 0.7 * ilvDay);

						// Brightness boost to match ilv_addReflection / composite7
						skCol *= 1.5;

						// Cloud reflection ? clamp min upward angle so ray reaches clouds
						#ifdef CLOUDS_3D_ENABLED
						if (reflDirWorld.y > 0.001) {
							float pxSkylight = texelFetch(colortex1, ivec2(gl_FragCoord.xy), 0).b;
							float cloudSkyGate = step(12.0 / 15.0, pxSkylight);
							float gameTimeSec = (float(worldDay) * 24000.0 + float(worldTime)) / 20.0;
							vec3 worldSunDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
							vec3 cloudReflDir = reflDirWorld;
							cloudReflDir.y = max(cloudReflDir.y, 0.12);
							cloudReflDir = normalize(cloudReflDir);
							vec3 ftReflOrigin = vec3(cameraPosition.x, 63.0, cameraPosition.z);
							vec4 ftCloudRefl = renderCloudReflection(cloudReflDir, gameTimeSec, ftReflOrigin, sunAngle, worldSunDir, gl_FragCoord.xy, frameCounter);
							ftCloudRefl.a *= cloudSkyGate;
							if (ftCloudRefl.a > 0.001) {
								skCol = mix(skCol, ftCloudRefl.rgb, ftCloudRefl.a);
							}
						}
						#endif

						// Fresnel ? match composite7 DH water formula exactly
						float cosTheta = abs(dot(viewDirView, waterNormalView));
						float fresnel = 1.0 - cosTheta;
						fresnel *= fresnel;
						fresnel *= fresnel; // pow4
						float fresnelMod = mix(0.3, 1.0, fresnel) * WATER_REFLECTION_FADE;
						fresnelMod = clamp(fresnelMod, 0.0, 1.0);
						float reflStrength = WATER_REFLECTION_AMOUNT * fresnelMod * WATER_SKY_REFLECTION;
						litColor = mix(litColor, skCol, reflStrength);

						// Distance fade toward sky (only at extreme distance)
						float distFade = smoothstep(FAKE_TERRAIN_DISTANCE * 0.6, FAKE_TERRAIN_DISTANCE * 0.95, hitDist);

						// Fade in from start distance
						float fadeIn = smoothstep(FAKE_TERRAIN_START, FAKE_TERRAIN_START + 32.0, hitDist);

						// Angle fade: near-horizontal rays create a sharp line at the horizon.
						// Fade out as the ray approaches horizontal (ftRayDir.y ? 0).
						float angleFade = smoothstep(0.0, 0.06, -ftRayDir.y);

						litColor = mix(litColor, color.rgb, distFade);
						float cloudProtect = 1.0 - clamp(cloudAlpha, 0.0, 1.0);
						float terrainBlend = fadeIn * cloudProtect * angleFade;
						color.rgb = mix(color.rgb, litColor, terrainBlend);
						if (terrainBlend > 0.001) {
							fakeTerrainHitForFog = true;
							fakeTerrainFogWorldPos = hitPos;
						}
					}
				}
			} else if (ftRayDir.y > 0.001 && camY < planeY) {
				// Looking up at water from below
				float t = (planeY - camY) / ftRayDir.y;

				if (t > 0.0 && t < FAKE_TERRAIN_DISTANCE) {
					vec3 hitPos = cameraPosition + ftRayDir * t;
					float hitDist = length(hitPos - cameraPosition);

					if (hitDist > FAKE_TERRAIN_START) {
						vec3 waterColor = vec3(WATER_COLOR_R, WATER_COLOR_G, WATER_COLOR_B) * 0.2;
						float fadeIn = smoothstep(FAKE_TERRAIN_START, FAKE_TERRAIN_START + 200.0, hitDist);
						float cloudProtect = 1.0 - clamp(cloudAlpha, 0.0, 1.0);
						float terrainBlend = fadeIn * cloudProtect;
						color.rgb = mix(color.rgb, waterColor, terrainBlend);
						if (terrainBlend > 0.001) {
							fakeTerrainHitForFog = true;
							fakeTerrainFogWorldPos = hitPos;
						}
					}
				}
			}
		}
		}
		} // end if (!isForcedNetherBiome(biome))
	}
	#endif

	// ========================================================================
	// Volumetric Fog
	// ========================================================================
	bool postIsSky = false;
	bool postFromDH = false;
	vec3 postSceneWorldPos = cameraPosition;

	// Emissive/entity detection (shared by VFOG and non-VFOG paths)
	vec4 maskData = texture(colortex1, texcoord);
	float emissiveFlag = maskData.g;
	bool isEmissive = emissiveFlag > 0.5;
	bool isEntityPixel = (maskData.a > 0.3 && maskData.a < 0.7);
	bool isParticle = maskData.b > 0.9;

	// Save sun/moon color before any fog ? will be restored after all fog systems.
	// Detect actual sun texture pixels by reading colortex0 at neighboring pixels:
	// the sun texture is drawn on top of the sky gradient, so sun pixels are
	// significantly brighter than their neighbors.
	vec3 savedSunColor = color;

	// Get scene depths (always needed ? used by water depth tint and VFOG):
	// depthtex0 = all geometry (opaque + translucent)
	// depthtex1 = opaque only (ignores glass/water)
	ivec2 texelCoord = ivec2(gl_FragCoord.xy);
	float depthAll = texelFetch(depthtex0, texelCoord, 0).x;      // With translucents
	float depthOpaque = texelFetch(depthtex1, texelCoord, 0).x;   // Without translucents (behind glass)
	float depthDH = texelFetch(dhDepthTex, texelCoord, 0).x;
	bool hasDHAtPixel = hasValidDHDepth(depthDH);

	// Detect translucent pixel types ? needed outside VFOG block for water depth tint
	bool isTranslucentPx = (depthAll < depthOpaque - 0.00001);
	bool isWaterSurface = isTranslucentPx && glassTint.a > 0.01 && glassTint.a <= 0.45;
	// Water surface back face seen from underwater ? marker written by gbuffers_water (a?0.2, no depth diff)
	bool isUnderwaterSurface = (isEyeInWater == 1) && (glassTint.a > 0.15 && glassTint.a < 0.25);

	#ifdef VOLUMETRIC_FOG_ENABLED
	// For fog behind glass, use depthtex1 so fog renders to the wall BEHIND glass

	// isTranslucentPx and isWaterSurface declared above (outside VFOG block)
	bool isTranslucent = isTranslucentPx;
	bool isEntity = isTranslucent && glassTint.a < 0.01;
	bool isGlass = isTranslucent && glassTint.a > 0.45;

	float sceneDepth;
	vec3 sceneWorldPos;
	bool isSky = false;
	bool sceneFromDH = false;

	// Use appropriate depth for fog calculation
	if (isEntity) {
		// Entity: use depthAll so fog stops at the entity, not behind it
		sceneDepth = depthAll;
		sceneWorldPos = getWorldPos(texcoord, sceneDepth);
		sceneFromDH = false;
	} else if (isWaterSurface) {
		// Water surface: treat as opaque for fog/depth purposes.
		// The water surface itself is the scene boundary ? fog stops here,
		// not at the block behind it. This prevents VFOG from running on
		// the underwater block and washing through the water surface.
		sceneDepth = depthAll;
		sceneWorldPos = getWorldPos(texcoord, sceneDepth);
		sceneFromDH = false;
	} else if (isGlass) {
		// Glass: fog to the closest surface behind the glass (MC or DH)
		// Linearize both depths to compare actual distances
		float linearOpaque = (depthOpaque < 0.9999) ? linearizeDepth(depthOpaque) : 1e10;
		float linearDH = hasDHAtPixel ? linearizeDepthDH(depthDH) : 1e10;

		if (linearOpaque < linearDH && depthOpaque < 0.9999) {
			// MC opaque surface is closer
			sceneDepth = depthOpaque;
			sceneWorldPos = getWorldPos(texcoord, sceneDepth);
			sceneFromDH = false;
		} else if (hasDHAtPixel) {
			// DH LOD is closer - use DH depth
			sceneDepth = depthDH;
			sceneWorldPos = getWorldPosDH(texcoord, sceneDepth);
			sceneFromDH = true;
		} else {
			// Both are far/sky - treat as sky
			isSky = true;
			sceneDepth = 1.0;
			vec4 clipPos = vec4(texcoord * 2.0 - 1.0, 0.0, 1.0);
			vec4 viewPos = gbufferProjectionInverse * clipPos;
			vec3 viewDir = normalize(viewPos.xyz);
			vec4 worldDir = gbufferModelViewInverse * vec4(viewDir, 0.0);
			sceneWorldPos = cameraPosition + worldDir.xyz * getVFogRenderDistance();
			sceneFromDH = false;
		}
	} else {
		// Opaque/non-translucent: pick nearest of MC scene depth and DH depth.
		float linearAll = (depthAll < 0.9999) ? linearizeDepth(depthAll) : 1e10;
		float linearDH = hasDHAtPixel ? linearizeDepthDH(depthDH) : 1e10;
		if (linearAll < linearDH && depthAll < 0.9999) {
			sceneDepth = depthAll;
			sceneWorldPos = getWorldPos(texcoord, sceneDepth);
			sceneFromDH = false;
		} else if (hasDHAtPixel) {
			sceneDepth = depthDH;
			sceneWorldPos = getWorldPosDH(texcoord, sceneDepth);
			sceneFromDH = true;
		} else {
			// Sky - use far distance
			isSky = true;
			sceneDepth = 1.0;
			// For sky, cast ray to maximum fog distance
			vec4 clipPos = vec4(texcoord * 2.0 - 1.0, 0.0, 1.0);
			vec4 viewPos = gbufferProjectionInverse * clipPos;
			vec3 viewDir = normalize(viewPos.xyz);
			vec4 worldDir = gbufferModelViewInverse * vec4(viewDir, 0.0);
			sceneWorldPos = cameraPosition + worldDir.xyz * getVFogRenderDistance();
			sceneFromDH = false;
		}
	}

	#ifdef FAKE_TERRAIN_ENABLED
	// Ensure VFOG is layered above fake terrain by fogging to the fake terrain hit depth.
	if (fakeTerrainHitForFog) {
		sceneWorldPos = fakeTerrainFogWorldPos;
		isSky = false;
		sceneFromDH = false;
	}
	#endif

	postIsSky = isSky;
	postFromDH = sceneFromDH;
	postSceneWorldPos = sceneWorldPos;

	// Compute fog
	vec4 fog = vec4(0.0);
	#if defined(VOLUMETRIC_FOG_ENABLED) || defined(NETHER_FOG_ENABLED) || defined(END_FOG_ENABLED)
	fog = computeVolumetricFog(texcoord, sceneDepth, sceneWorldPos, isSky, sceneFromDH);
	// Disable VFOG when camera is underwater to avoid over-bright shafts
	if (isEyeInWater == 1) {
		fog = vec4(0.0);
	}
	#endif
	// NOTE: Indoor fog suppression removed to avoid interfering with fake terrain.
	// TODO: Re-add with proper camera skylight detection.

	// Reduce fog for emissive/hologram pixels within visibility distance
	if ((isEmissive || isParticle) && !isSky) {
		float distToCamera = length(sceneWorldPos - cameraPosition);
		if (distToCamera < VFOG_EMISSIVE_VISIBILITY) {
			// Fade fog based on distance within visibility range
			float visibilityFade = distToCamera / VFOG_EMISSIVE_VISIBILITY;
			visibilityFade = visibilityFade * visibilityFade; // Square for smoother near-camera visibility
			fog.a *= visibilityFade;
		}
	}

	// Clouds are already composited in composite8; applying full scene fog on top
	// makes cloud tops look dim/gray. Keep only a small fraction of fog on cloud pixels.
	float cloudFogAtten = mix(1.0, 0.22, clamp(cloudAlpha, 0.0, 1.0));
	fog.a *= cloudFogAtten;
	
	#ifdef VOLUMETRIC_FOG_DEBUG
	// Debug mode - show depth as grayscale (white = near, black = far)
	// Uses VFOG_DEPTH_DISTANCE as reference for max fog density distance
	float sceneDistance = length(sceneWorldPos - cameraPosition);
	float debugDepth = 1.0 - clamp(sceneDistance / VFOG_DEPTH_DISTANCE, 0.0, 1.0);
	color = vec3(debugDepth);
	#else
	
	// === PRE-FOG POSTERIZE ===
	// Apply posterize BEFORE fog so fog remains smooth
	#ifdef CG_POSTERIZE_ENABLED
	color = applyPosterize(color, float(CG_POSTERIZE_LEVELS), CG_POSTERIZE_DITHER, gl_FragCoord.xy, frameCounter);
	#endif
	
	// Nether: force fog color on sky/void pixels
	#ifdef NETHER_FOG_ENABLED
	if (isForcedNetherBiome(biome) && isSky) {
		color = fog.rgb;
		fog.a = 1.0;
	}
	#endif

	// End: sky pixels already have the procedural End sky from composite pass
	// Only apply fog to non-sky pixels (terrain fading into void)


	// Volumetric fog blending: standard mix blend
	// fog.rgb is the fog color, fog.a is opacity
	// Clarity: reduce how much fog washes out the scene by scaling fog opacity down,
	// then boost the remaining scene contrast so colors stay punchy instead of gray.
	vec4 fogAdj = fog;
	if (VFOG_DETAIL_VISIBILITY > 0.001 && fog.a > 0.001 && !isSky) {
		// Scale fog opacity down ? scene shows through more
		fogAdj.a = fog.a * (1.0 - VFOG_DETAIL_VISIBILITY * 0.9);
		// Boost contrast of the scene relative to the fog color so it doesn't look washed out
		float clarityContrast = VFOG_DETAIL_VISIBILITY * fog.a * 2.0;
		vec3 fogMid = fog.rgb;
		color = fogMid + (color - fogMid) * (1.0 + clarityContrast);
		color = clamp(color, vec3(0.0), vec3(2.0));
	}
	if (isEntity) {
		color = mix(color, fog.rgb, fogAdj.a);
	} else if (isGlass) {
		color = mix(color, fog.rgb, fogAdj.a);
		
		// Now compute fog to the GLASS SURFACE itself for tint fading
		vec3 glassWorldPos = getWorldPos(texcoord, depthAll);
		float glassDistance = length(glassWorldPos - cameraPosition);
		
		// Calculate how much the glass itself should be fogged
		// Use same fog density logic as volumetric fog
		float glassFogAmount = 0.0;
		float vfogBottom = VFOG_HEIGHT_BOTTOM + SEA_LEVEL_OFFSET;
		float vfogTop = VFOG_HEIGHT_TOP + SEA_LEVEL_OFFSET;
		if (glassWorldPos.y >= vfogBottom && glassWorldPos.y <= vfogTop) {
			float distFactor = clamp((glassDistance - VFOG_START_DISTANCE) / (VFOG_DEPTH_DISTANCE - VFOG_START_DISTANCE), 0.0, 1.0);
			glassFogAmount = distFactor * VFOG_DENSITY * 0.05; // Lighter fog on glass surface
			glassFogAmount = clamp(glassFogAmount, 0.0, 0.95);
		}
		
		// Apply glass tint, but fade it with fog (glass becomes less visible in fog)
		// Bliss style: More vibrant transmission with saturation boost
		vec3 glassTintColor = glassTint.rgb;
        float lum = dot(glassTintColor, vec3(0.299, 0.587, 0.114));
        if (lum > 0.001) {
            // Boost saturation by pushing away from luma
            glassTintColor = mix(vec3(lum), glassTintColor, 1.5); 
        }
        
		float tintStrength = glassTint.a * 0.7 * (1.0 - glassFogAmount);
        
        // Bliss Transmission Model: Blend between multiply and screen/add logic
        // for that bright, vibrant "liquid" look in glass
        vec3 tinted = color * glassTintColor * 1.5; // Multiply + boost
        color = mix(color, tinted, tintStrength);
		
		// Blend glass surface toward fog color based on glass fog amount
		vec3 fogColor = getHorizonColor();
		color = mix(color, fogColor, glassFogAmount * 0.7);
	} else if (isWaterSurface) {
		// Water uses the generic translucent fog blend. Applying the glass-only tint
		// transmission pass here can wash underwater detail into harsh black/white.
		color = mix(color, fog.rgb, fogAdj.a);
	} else if (isTranslucent) {
		color = mix(color, fog.rgb, fogAdj.a);
	} else if (isSky) {
		// Keep sky fog mostly at the horizon so it does not darken the full sky dome.
		vec3 skyDir = normalize(postSceneWorldPos - cameraPosition);
		float horizonMask = 1.0 - smoothstep(0.10, 0.42, skyDir.y);
		// Prevent fog from brightening sky; also avoid over-darkening by blending
		// only part-way toward the clamped fog color.
		vec3 fogSkyColor = mix(color, min(fog.rgb, color), 0.55);
		#if defined(CLOUDS_3D_ENABLED) || defined(CLOUDS_VANILLA_ENABLED)
		// Reduce fog on sky pixels when clouds are rendered in composite8 to prevent
		// a dark horizon band (fog darkens sky before clouds composite on top)
		float skyFogAlpha = fog.a * 0.3 * horizonMask;
		color = mix(color, fogSkyColor, skyFogAlpha);
		#else
		float skyFogAlpha = fog.a * horizonMask;
		color = mix(color, fogSkyColor, skyFogAlpha);
		#endif
	} else {
		#ifdef END_SHADER
		// End fog blending
		{
			vec3 additiveResult = color * (1.0 - fogAdj.a * 0.25) + fog.rgb * fogAdj.a;
			vec3 standardResult = mix(color, fog.rgb, fogAdj.a);

			#ifdef END_EVENT_ENABLED
			float endBlendDark = getEndEvent(frameTimeCounter).fogDarkness;
			// Event darkness pushes toward standard mix
			float totalMixWeight = endBlendDark;
			#else
			float totalMixWeight = 0.0;
			#endif

			color = mix(additiveResult, standardResult, totalMixWeight);
		}
		#else
		color = mix(color, fog.rgb, fogAdj.a);
		#endif
	}

	fogAmount = fog.a;


	#endif // VOLUMETRIC_FOG_DEBUG
	#endif // VOLUMETRIC_FOG_ENABLED

	// Water depth tint removed ? water surface alpha=1 is fully opaque,
	// underwater content does not bleed through.

	// Horror blackout fog: short-range opaque black fog during End event
	// Runs AFTER all fog systems (VFOG or distance fog) to override everything
	#if defined(END_SHADER) && defined(END_EVENT_ENABLED)
	if (isEndDimension() && !postIsSky) {
		float horrorEventDark = getEndEvent(frameTimeCounter).fogDarkness;
		if (horrorEventDark > 0.001) {
			float horrorSceneDist = length(postSceneWorldPos - cameraPosition);
			float horrorRange = 20.0;
			float horrorT = clamp(horrorSceneDist / horrorRange, 0.0, 1.0);
			float horrorFog = 1.0 - exp(-horrorT * horrorT * 8.0);
			horrorFog *= horrorEventDark;
			color = mix(color, vec3(0.0), horrorFog);
			fogAmount = max(fogAmount, horrorFog);
		}
	}
	#endif

	// Void clouds over geometry ? runs AFTER all fog (VFOG or distance fog)
	// so clouds appear on top of fogged terrain/DH LODs
	#if defined(END_SHADER) && defined(END_SKY_ENABLED) && defined(END_VOID_CLOUDS_ENABLED)
	if (isEndDimension() && !postIsSky) {
		float vcSceneDist = length(postSceneWorldPos - cameraPosition);
		vec3 vcDir = normalize(postSceneWorldPos - cameraPosition);
		#ifdef END_EVENT_ENABLED
		EndEvent vcEvent = getEndEvent(frameTimeCounter);
		vec4 vcClouds = endVoidClouds(vcDir, vcEvent.cloudTime, frameTimeCounter, cameraPosition, vcSceneDist, vcEvent.suctionWarp);
		#else
		vec4 vcClouds = endVoidClouds(vcDir, frameTimeCounter, frameTimeCounter, cameraPosition, vcSceneDist, 0.0);
		#endif
		if (vcClouds.a > 0.001) {
			vec3 vcCloudRGB = vcClouds.rgb / vcClouds.a;
			#ifdef END_EVENT_ENABLED
			float vcAlpha = vcClouds.a * vcEvent.effectsFade;
			#else
			float vcAlpha = vcClouds.a;
			#endif
			color = mix(color, vcCloudRGB, vcAlpha);
		}
	}
	#endif

	// 3D Volumetric Clouds are now rendered in composite8.fsh (before TAA)
	// Cloud pixels are already composited into colortex0 at this point

	// Floating ender particles in world space ? glowing motes drifting around the player
	#if defined(END_SHADER) && defined(END_SKY_ENABLED) && defined(END_ENDER_PARTICLES_ENABLED)
	if (isEndDimension()) {
		float epSceneDist = postIsSky ? END_ENDER_PARTICLE_RANGE : length(postSceneWorldPos - cameraPosition);
		vec3 epDir = postIsSky ? normalize(mat3(gbufferModelViewInverse) * (gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0)).xyz) : normalize(postSceneWorldPos - cameraPosition);
		vec3 particles = endEnderParticles(epDir, frameTimeCounter, cameraPosition, epSceneDist);
		#ifdef END_EVENT_ENABLED
		particles *= getEndEvent(frameTimeCounter).effectsFade;
		#endif
		color += particles;
	}
	#endif

	#ifndef VOLUMETRIC_FOG_ENABLED
	{
		ivec2 postTexel = ivec2(gl_FragCoord.xy);
		float postDepthMC = texelFetch(depthtex0, postTexel, 0).x;
		float postDepthDH = texelFetch(dhDepthTex, postTexel, 0).x;
		bool postHasDH = hasValidDHDepth(postDepthDH);
		postIsSky = (postDepthMC >= 0.9999 && !postHasDH);
		postFromDH = false;
		if (!postIsSky) {
			if (postDepthMC < 0.9999) {
				postSceneWorldPos = getWorldPos(texcoord, postDepthMC);
				postFromDH = false;
			} else if (postHasDH) {
				postSceneWorldPos = getWorldPosDH(texcoord, postDepthDH);
				postFromDH = true;
			} else {
				postIsSky = true;
				postFromDH = false;
			}
		}
	}
	#endif

	// Chunk Border Volumetric Fog (separate feature)
	// Skip entirely when DH is active ? DH handles distant terrain, and chunk border fog
	// would cover over fake terrain and DH LODs.
	#if defined(CHUNK_BORDER_FOG_ENABLED) && !defined(CHUNK_FADE_OUT_ENABLED) && !defined(NETHER_SHADER) && !defined(END_SHADER)
	{
		ivec2 cbTexel = ivec2(gl_FragCoord.xy);
		float cbDepthMC = texelFetch(depthtex0, cbTexel, 0).x;
		float cbDepthOpaque = texelFetch(depthtex1, cbTexel, 0).x;
		float cbDepthDH = texelFetch(dhDepthTex, cbTexel, 0).x;
		bool cbHasDH = hasValidDHDepth(cbDepthDH);
		// Global DH detection: probe screen edges + check far plane
		bool cbDhGlobalActive = cbHasDH
			|| hasValidDHDepth(texelFetch(dhDepthTex, ivec2(vec2(0.5, 0.05) * vec2(viewWidth, viewHeight)), 0).x)
			|| hasValidDHDepth(texelFetch(dhDepthTex, ivec2(vec2(0.15, 0.05) * vec2(viewWidth, viewHeight)), 0).x)
			|| (dhFarPlane > far * 1.5);
		bool cbSky = (cbDepthMC >= 0.9999 && !cbHasDH);
		bool cbIsTranslucent = (cbDepthMC < cbDepthOpaque - 0.00001);
		bool cbIsWaterSurface = cbIsTranslucent && glassTint.a > 0.01 && glassTint.a <= 0.45;

		if (!cbDhGlobalActive && !postFromDH && !cbHasDH && (!cbIsTranslucent || cbIsWaterSurface)) {
			float cbRadiusStart = max(far * CHUNK_BORDER_FOG_START - 10.0, 0.0);
			float cbRadiusEnd = max(far * CHUNK_BORDER_FOG_END - 10.0, cbRadiusStart + 1.0);
			float cbEdgeMask = 0.0;

			if (!cbSky) {
				float cbSceneDist = length(postSceneWorldPos - cameraPosition);
				float cbRadiusFade = smoothstep(cbRadiusStart, cbRadiusEnd, cbSceneDist);
				float cbDepthEdge = smoothstep(0.990, 0.99998, cbDepthMC);
				cbEdgeMask = cbRadiusFade * cbDepthEdge;
			} else {
				// Sky fallback: only near horizon and only when view implies far distance.
				// This prevents the old camera-locked full-screen fog artifact.
				vec3 cbViewDir = normalize(mat3(gbufferModelViewInverse) *
					(gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0)).xyz);
				float cbPseudoDist = far / max(abs(cbViewDir.y), 0.02);
				float cbRadiusFade = smoothstep(cbRadiusStart, cbRadiusEnd, cbPseudoDist);
				float cbHorizonMask = 1.0 - smoothstep(0.03, 0.22, cbViewDir.y);
				cbEdgeMask = cbRadiusFade * cbHorizonMask;
			}

			if (cbEdgeMask > 0.001) {
				cbEdgeMask = pow(clamp(cbEdgeMask, 0.0, 1.0), 0.65);
				float cbFogAmount = 0.0;

				if (cbIsWaterSurface) {
					// Water path: avoid noisy volumetric sampling to prevent backface speckle
					// when chunks stream in. Keep a smooth border blend.
					float cbWaterGain = 0.85 + 0.30 * clamp(CHUNK_BORDER_FOG_DENSITY, 0.0, 3.0);
					cbFogAmount = cbEdgeMask * CHUNK_BORDER_FOG_OPACITY * cbWaterGain;
				} else {
					float cbSceneDist = cbSky ? cbRadiusEnd : length(postSceneWorldPos - cameraPosition);
					vec3 cbDir = cbSky
						? normalize(mat3(gbufferModelViewInverse) * (gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0)).xyz)
						: normalize(postSceneWorldPos - cameraPosition);
					float cbMarchLen = min(CHUNK_BORDER_FOG_DEPTH, cbSceneDist);
					float cbStepLen = cbMarchLen / float(CHUNK_BORDER_FOG_STEPS);
					float cbStartT = max(cbSceneDist - cbMarchLen, 0.0);

					// Keep border fog temporally stable (no per-frame jitter).
					float cbDither = 0.5;
					float cbTransmittance = 1.0;

					for (int i = 0; i < CHUNK_BORDER_FOG_STEPS; i++) {
						if (cbTransmittance < 0.03) break;
						float t = cbStartT + (float(i) + cbDither) * cbStepLen;
						vec3 samplePos = cameraPosition + cbDir * t;

						float n0 = vcNoise3D(samplePos * CHUNK_BORDER_FOG_SCALE);
						float n1 = vcNoise3D(samplePos * (CHUNK_BORDER_FOG_SCALE * 1.8));
						float shape = n0 * 0.68 + n1 * 0.32;
						// Continuous base density so fog covers the full border band,
						// with noise only modulating thickness/detail.
						float densBase = 0.55 * CHUNK_BORDER_FOG_DENSITY;
						float densDetail = smoothstep(0.35, 0.78, shape) * CHUNK_BORDER_FOG_DENSITY;
						float dens = mix(densBase, densDetail, 0.35);

						float stepOD = dens * cbStepLen * 0.14;
						float stepT = exp(-stepOD);
						cbTransmittance *= stepT;
					}

					cbFogAmount = (1.0 - cbTransmittance) * cbEdgeMask * CHUNK_BORDER_FOG_OPACITY * 1.35;
					// Ensure a minimum continuous blend along the border.
					cbFogAmount = max(cbFogAmount, cbEdgeMask * CHUNK_BORDER_FOG_OPACITY * 0.45);
				}

				cbFogAmount = clamp(cbFogAmount, 0.0, 0.95);

				if (cbFogAmount > 0.001) {
					vec3 cbColor = getForcedBiomeFogColorCat(biome, biome_category, getHorizonColor());
					cbColor *= CHUNK_BORDER_FOG_BRIGHTNESS;
					if (cbFogAmount > chunkBorderFogAmount) {
						chunkBorderFogAmount = cbFogAmount;
						chunkBorderFogColor = cbColor;
					}
				}
			}
		}
	}
	#endif

	// ========================================================================
	// Cave Fog (volumetric 3D-noise fog in low-skylight underground areas)
	// ========================================================================
	#if defined(CAVE_FOG_ENABLED) && !defined(NETHER_SHADER) && !defined(END_SHADER)
	{
		float cfSkylight = texture(colortex1, texcoord).b;
		bool cfIsParticle = cfSkylight > 0.9;

		// Cave fog triggers on low-skylight, non-sky fragments in the overworld only
		if (!cfIsParticle && !postIsSky && cfSkylight < 0.5 && !isForcedNetherBiome(biome) && !isEndDimension()) {
			float cfHeightThreshold = float(CAVE_FOG_HEIGHT);
			float cfWorldY = postSceneWorldPos.y;

			// Fragment or camera should be below height threshold
			if (cfWorldY < cfHeightThreshold || cameraPosition.y < cfHeightThreshold) {
				// Cave strength: lower skylight = stronger fog
				float caveFactor = 1.0 - smoothstep(0.0, 0.35, cfSkylight);
				// Height fade near the threshold ceiling
				float peakY = max(cfWorldY, cameraPosition.y);
				float heightFade = 1.0 - smoothstep(cfHeightThreshold - 20.0, cfHeightThreshold, peakY);
				caveFactor *= heightFade;

				if (caveFactor > 0.01) {
					vec3 cfDir = normalize(postSceneWorldPos - cameraPosition);
					float cfDist = length(postSceneWorldPos - cameraPosition);
					float cfMarchLen = min(cfDist, 96.0);
					float cfStepLen = cfMarchLen / float(CAVE_FOG_STEPS);

					float cfTransmittance = 1.0;
					float cfTime = frameTimeCounter * CAVE_FOG_SPEED;

					for (int i = 0; i < CAVE_FOG_STEPS; i++) {
						if (cfTransmittance < 0.03) break;
						float t = (float(i) + 0.5) * cfStepLen;
						vec3 samplePos = cameraPosition + cfDir * t;

						// Per-sample height fade so fog stays underground
						float sampleHFade = 1.0 - smoothstep(cfHeightThreshold - 15.0, cfHeightThreshold, samplePos.y);
						if (sampleHFade < 0.01) continue;

						// 3D noise with slow random drift
						vec3 noisePos = samplePos + vec3(cfTime * 0.4, cfTime * 0.15, cfTime * 0.25);
						float n0 = vcNoise3D(noisePos * CAVE_FOG_SCALE);
						float n1 = vcNoise3D(noisePos * (CAVE_FOG_SCALE * 2.3));
						float shape = n0 * 0.6 + n1 * 0.4;

						float dens = smoothstep(0.28, 0.72, shape) * CAVE_FOG_DENSITY * sampleHFade;
						float stepOD = dens * cfStepLen * 0.06;
						cfTransmittance *= exp(-stepOD);
					}

					float cfFogAmount = (1.0 - cfTransmittance) * caveFactor;
					cfFogAmount = clamp(cfFogAmount, 0.0, 0.85);

					if (cfFogAmount > 0.001) {
						vec3 cfColor = vec3(CAVE_FOG_COLOR_R, CAVE_FOG_COLOR_G, CAVE_FOG_COLOR_B);
						color = mix(color, cfColor, cfFogAmount);
					}
				}
			}
		}
	}
	#endif

	// ========================================================================
	// Weather Fog (raymarched 3D-noise fog during rain/thunderstorm)
	// Covers terrain, sky, and hides clouds. Surrounds the player with shaped
	// fog patches instead of a flat distance wall.
	// ========================================================================
	#if defined(WEATHER_FOG_ENABLED) && !defined(NETHER_SHADER) && !defined(END_SHADER)
	if (rainStrength > 0.01 && isEyeInWater == 0 && !isForcedNetherBiome(biome) && !isEndDimension()) {
		// Fog strength ? ramps up with rain, extra push during thunder
		float wfRain = smoothstep(0.0, 0.6, rainStrength);
		float wfThunder = smoothstep(0.0, 1.0, thunderStrength) * 0.25;
		float wfStrength = clamp(wfRain + wfThunder, 0.0, 1.0);

		// View direction for sky pixels
		vec3 wfDir;
		float wfMaxDist;
		if (postIsSky) {
			wfDir = normalize(mat3(gbufferModelViewInverse) * (gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0)).xyz);
			wfMaxDist = float(WEATHER_FOG_RADIUS);
		} else {
			wfDir = normalize(postSceneWorldPos - cameraPosition);
			wfMaxDist = min(length(postSceneWorldPos - cameraPosition), float(WEATHER_FOG_RADIUS));
		}

		float wfMarchLen = wfMaxDist;
		float wfStepLen = wfMarchLen / float(WEATHER_FOG_STEPS);
		float wfTransmittance = 1.0;
		float wfTime = frameTimeCounter * WEATHER_FOG_SPEED;

		for (int i = 0; i < WEATHER_FOG_STEPS; i++) {
			if (wfTransmittance < 0.02) break;
			float t = (float(i) + 0.5) * wfStepLen;
			vec3 samplePos = cameraPosition + wfDir * t;

			// Animated 3D noise ? two octaves for billowing cloud-like shapes
			vec3 np0 = samplePos * WEATHER_FOG_SCALE + vec3(wfTime * 0.35, wfTime * 0.10, wfTime * 0.22);
			vec3 np1 = samplePos * (WEATHER_FOG_SCALE * 2.1) + vec3(wfTime * 0.18, wfTime * 0.28, wfTime * 0.09);
			float n0 = vcNoise3D(np0);
			float n1 = vcNoise3D(np1);
			float shape = n0 * 0.65 + n1 * 0.35;

			// Fog exists above a threshold ? creates distinct billowing patches
			float dens = smoothstep(0.30, 0.68, shape) * WEATHER_FOG_DENSITY * wfStrength;
			float stepOD = dens * wfStepLen * 0.055;
			wfTransmittance *= exp(-stepOD);
		}

		float wfFogAmount = (1.0 - wfTransmittance);
		wfFogAmount = clamp(wfFogAmount, 0.0, WEATHER_FOG_MAX_OPACITY);

		if (wfFogAmount > 0.001) {
			// Fog base color ? biome overrides take priority, user-set color is the fallback
			// (desert = creamy, swamp = dark green, snowy = white, normal = purplish)
			vec3 wfBase = getForcedBiomeFogColorCat(biome, biome_category, vec3(WEATHER_FOG_COLOR_R, WEATHER_FOG_COLOR_G, WEATHER_FOG_COLOR_B));
			// Blend a touch of sky color for atmospheric depth
			vec3 wfColor = mix(wfBase, skyColor, 0.25);
			color = mix(color, wfColor, wfFogAmount);
		}
	}
	#endif

	// ========================================================================
	// Rain Darkness ? world dims during rain/thunder at daytime
	// ========================================================================
	#if defined(WEATHER_FOG_ENABLED) && !defined(NETHER_SHADER) && !defined(END_SHADER)
	if (rainStrength > 0.01 && isEyeInWater == 0) {
		// Only darken during day (sunAngle 0.0-0.5 = daytime)
		float wdAngle = fract(sunAngle);
		float isDaytime = smoothstep(0.0, 0.07, wdAngle) * (1.0 - smoothstep(0.43, 0.50, wdAngle));

		float rainDark = mix(1.0, WEATHER_RAIN_DARKNESS, smoothstep(0.0, 0.8, rainStrength) * isDaytime);
		float thunderDark = mix(1.0, WEATHER_THUNDER_DARKNESS, smoothstep(0.0, 1.0, thunderStrength) * isDaytime);
		color *= rainDark * thunderDark;
	}
	#endif

	// Planetary rings ? rendered after depth is resolved so they appear in front of DH LODs
	#if defined(END_SHADER) && defined(END_SKY_ENABLED) && defined(END_RINGS_ENABLED)
	if (isEndDimension()) {
		vec3 ringDir = normalize(mat3(gbufferModelViewInverse) * (gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0)).xyz);
		float ringMaxDist = postIsSky ? 10000.0 : length(postSceneWorldPos - cameraPosition);
		vec3 rings = endRings(ringDir, frameTimeCounter, cameraPosition, ringMaxDist);
		#ifdef END_EVENT_ENABLED
		rings *= getEndEvent(frameTimeCounter).effectsFade;
		#endif
		color += rings;
	}
	#endif

	// === PRE-FOG POSTERIZE (when volumetric fog disabled) ===
	#ifndef VOLUMETRIC_FOG_ENABLED
	#ifdef CG_POSTERIZE_ENABLED
	color = applyPosterize(color, float(CG_POSTERIZE_LEVELS), CG_POSTERIZE_DITHER, gl_FragCoord.xy, frameCounter);
	#endif
	#endif

	#ifndef VOLUMETRIC_FOG_ENABLED
	#ifdef NETHER_FOG_ENABLED
	if (isForcedNetherBiome(biome) && !postIsSky) {
		float sceneDist = length(postSceneWorldPos - cameraPosition);
		float fogStart = max(NETHER_DISTANCE_FOG_START, 0.0);
		float fogEnd = max(float(NETHER_FOG_DISTANCE), fogStart + 1.0);
		float depthT = clamp((sceneDist - fogStart) / max(fogEnd - fogStart, 1.0), 0.0, 1.0);
		float density = max(NETHER_DISTANCE_FOG_OPACITY, 0.01);
		float netherFogAmount = 1.0 - exp(-depthT * depthT * density * 2.2);
		netherFogAmount = clamp(netherFogAmount, 0.0, 0.97);

		vec3 netherFogColor = getForcedBiomeFogColor(biome, vec3(NETHER_FOG_R, NETHER_FOG_G, NETHER_FOG_B));
		netherFogColor *= NETHER_BRIGHTNESS;

		color = mix(color, netherFogColor, netherFogAmount);
		fogAmount = max(fogAmount, netherFogAmount);
	}
	#endif

	#ifdef END_FOG_ENABLED
	if (isEndDimension() && !postIsSky) {
		float sceneDist = length(postSceneWorldPos - cameraPosition);
		float depthRange = max(float(END_FOG_DISTANCE) - END_FOG_START, 1.0);
		float depthT = clamp((sceneDist - END_FOG_START) / depthRange, 0.0, 1.0);
		float density = max(END_FOG_DENSITY, 0.01);
		float endFogAmount = 1.0 - exp(-depthT * depthT * density * 1.5);
		endFogAmount = clamp(endFogAmount, 0.0, 0.6);

		// Mostly additive purple haze + slight depth fade to softly obscure distance
		vec3 endFogColor = vec3(END_FOG_R, END_FOG_G, END_FOG_B) * 2.5;
		#if defined(END_SHADER) && defined(END_EVENT_ENABLED)
		float eventFogDark = getEndEvent(frameTimeCounter).fogDarkness;
		// Normal End fog fades out during event
		endFogAmount *= (1.0 - eventFogDark);
		endFogColor *= (1.0 - eventFogDark);
		#endif
		color = color * (1.0 - endFogAmount * 0.25) + endFogColor * endFogAmount;
		fogAmount = max(fogAmount, endFogAmount);

		// Horror fog is handled after VOLUMETRIC_FOG_ENABLED so it works in both paths
	}
	#endif

	#endif

	// ========================================================================
	// Horizon Fog (non-volumetric distant layer)
	// ========================================================================
	vec3 horizonFogBloom = vec3(0.0); // For optional bloom contribution
	#ifdef HORIZON_FOG_ENABLED
	if (!isEndDimension())
	{
		// Recalculate depth info for horizon fog (needed if volumetric fog is disabled)
		ivec2 hfTexelCoord = ivec2(gl_FragCoord.xy);
		float hfDepthMC = texelFetch(depthtex0, hfTexelCoord, 0).x;
		float hfDepthDH = texelFetch(dhDepthTex, hfTexelCoord, 0).x;
		bool hfHasDH = hasValidDHDepth(hfDepthDH);
		
		bool hfIsSky = (hfDepthMC >= 0.9999 && !hfHasDH);
		
		// Calculate scene distance
		float hfSceneDistance = 0.0;
		if (!hfIsSky) {
			if (hfDepthMC < 0.9999) {
				vec3 hfWorldPos = getWorldPos(texcoord, hfDepthMC);
				hfSceneDistance = length(hfWorldPos - cameraPosition);
			} else if (hfHasDH) {
				vec3 hfWorldPos = getWorldPosDH(texcoord, hfDepthDH);
				hfSceneDistance = length(hfWorldPos - cameraPosition);
			} else {
				hfIsSky = true;
			}
		}
		
		vec4 horizonFog = computeHorizonFog(texcoord, hfIsSky, hfSceneDistance);

		if (horizonFog.a > 0.001) {
			// Reduce horizon fog on sky pixels when clouds are rendered in composite8
			// to prevent a dark band between bright sky and clouds
			#if defined(CLOUDS_3D_ENABLED) || defined(CLOUDS_VANILLA_ENABLED)
			if (hfIsSky) {
				horizonFog.a *= 0.3;
			}
			#endif

			// Blend horizon fog
			color = mix(color, horizonFog.rgb, horizonFog.a);

			// Track combined fog amount
			fogAmount = max(fogAmount, horizonFog.a);
			
			// Store bloom contribution for later
			#ifdef HFOG_BLOOM
			horizonFogBloom = horizonFog.rgb * horizonFog.a * HFOG_BLOOM_INTENSITY;
			#endif
		}
	}
	#endif // HORIZON_FOG_ENABLED


	// ========================================================================
	// Screen-space sun shafts (cinematic crepuscular rays)
	// ========================================================================
	#ifdef SS_SUN_SHAFTS_ENABLED
	{
		if (isEyeInWater != 1 && !isEndDimension() && !isSkylessWorldHeuristic()) {
			float pxDepth = texture(depthtex0, texcoord).r;
			bool isSkyPx = (pxDepth >= 0.9999);
			// DH water: depthtex0 shows sky but colortex5 has water reflection data ? skip shafts
			bool isDhWater = isSkyPx && (texture(colortex5, texcoord).g > 0.001);
			if (!isDhWater) {
				float pxSkylight = texture(colortex1, texcoord).b;
				// Sky pixels should not be suppressed by the skylight gate (some pipelines write 0 there).
				float gate = isSkyPx ? 1.0 : smoothstep(SS_SHAFT_SKYLIGHT_MIN, 1.0, pxSkylight);
				if (gate > 0.001) {
					vec3 shaftAdd = computeScreenSpaceSunShafts(texcoord) * gate;
					color += shaftAdd;
				}
			}
		}
	}
	#endif

	// Restore sun/moon on top of ALL fog.
	// Sun texture pixels are brighter than the sky gradient they're drawn over.
	// Compare saved (pre-fog) brightness vs fogged result ? only restore if
	// the pixel was significantly brighter, meaning it's actual sun texture.
	#if !defined(NETHER_SHADER) && !defined(END_SHADER)
	{
		if (!isSkylessWorldHeuristic()) {
		ivec2 sunTexel = ivec2(gl_FragCoord.xy);
		float sunDepthMC = texelFetch(depthtex0, sunTexel, 0).x;
		float sunDepthDH = texelFetch(dhDepthTex, sunTexel, 0).x;
		bool sunIsSky = (sunDepthMC >= 0.9999 && !hasValidDHDepth(sunDepthDH));
		if (sunIsSky && fogAmount > 0.05) {
			float sunGateAngle = fract(sunAngle);
			float sunTexGate = smoothstep(0.0, 0.04, sunGateAngle) * (1.0 - smoothstep(0.50, 0.54, sunGateAngle));
			float savedLum = dot(savedSunColor, vec3(0.299, 0.587, 0.114));
			float foggedLum = dot(color, vec3(0.299, 0.587, 0.114));
			// Sun texture is significantly brighter than surrounding sky/fog
			// High threshold so only actual sun texture pixels trigger, not dimmed sky
			float sunStrength = smoothstep(0.15, 0.4, savedLum - foggedLum);
			// Reduce restore in heavy fog so sun fades naturally into fog
			sunStrength *= 1.0 - smoothstep(0.3, 0.8, fogAmount);
			sunStrength *= sunTexGate;
			color = mix(color, savedSunColor, sunStrength);
		}
		}
	}
	#endif

	// Composite chunk-border fog late so it is not suppressed by VFOG god-ray/exposure passes.
	#if defined(CHUNK_BORDER_FOG_ENABLED) && !defined(CHUNK_FADE_OUT_ENABLED) && !defined(NETHER_SHADER) && !defined(END_SHADER)
	if (chunkBorderFogAmount > 0.001) {
		color = mix(color, chunkBorderFogColor, chunkBorderFogAmount);
	}
	#endif

	// ========================================================================
	// Eye Spotlight Beam (volumetric column from cosmic eye to player) - End only
	// Self-contained depth fetch and raymarch.
	// The volumetric glow radius is much wider than the ground spotlight radius
	// because the camera is INSIDE the beam ? horizontal rays need a wide gaussian
	// to accumulate visible density before exiting the cylinder.
	// ========================================================================
	#if defined(END_SHADER) && defined(END_EVENT_ENABLED) && defined(END_EVENT_EYE_ENABLED) && defined(END_EVENT_SPOTLIGHT_ENABLED)
	{
		EndEvent ebEvent = getEndEvent(frameTimeCounter);
		if (isEndDimension() && ebEvent.eyeOpen > 0.01) {
			// Fetch depth independently
			ivec2 ebTexel = ivec2(gl_FragCoord.xy);
			float ebDepthMC = texelFetch(depthtex0, ebTexel, 0).x;
			float ebDepthDH = texelFetch(dhDepthTex, ebTexel, 0).x;
			bool ebHasDH = hasValidDHDepth(ebDepthDH);

			// Calculate view ray direction
			vec4 ebClipPos = vec4(texcoord * 2.0 - 1.0, 0.5, 1.0);
			vec4 ebViewPos = gbufferProjectionInverse * ebClipPos;
			vec3 ebViewDir = normalize(ebViewPos.xyz);
			vec4 ebWorldDir4 = gbufferModelViewInverse * vec4(ebViewDir, 0.0);
			vec3 ebRayDir = normalize(ebWorldDir4.xyz);

			// Calculate max raymarch distance
			float ebMaxDist = 1000.0;
			bool ebIsSky = (ebDepthMC >= 0.9999 && !ebHasDH);
			if (!ebIsSky) {
				vec3 ebWorldPos;
				if (ebDepthMC < 0.9999) {
					ebWorldPos = getWorldPos(texcoord, ebDepthMC);
				} else if (ebHasDH) {
					ebWorldPos = getWorldPosDH(texcoord, ebDepthDH);
				} else {
					ebIsSky = true;
				}
				if (!ebIsSky) ebMaxDist = length(ebWorldPos - cameraPosition);
			}

			// Beam: vertical cylinder at the player position, ray-cylinder intersection
			// eyePosition stays on the entity in third-person (not cameraPosition)
			vec3 ebBeamCenter = vec3(eyePosition.x, 0.0, eyePosition.z);
			float ebBeamRadius = END_EVENT_SPOTLIGHT_RADIUS;
			float ebBeamBottom = eyePosition.y - 1.6; // player feet
			float ebBeamTop = ebBeamBottom + 300.0;

			// Ray-cylinder intersection in XZ plane
			// Solve: |cam.xz + t*dir.xz - center.xz|? = R?
			vec2 ebOC = cameraPosition.xz - ebBeamCenter.xz;
			vec2 ebDxz = ebRayDir.xz;
			float ebA = dot(ebDxz, ebDxz);
			float ebB = 2.0 * dot(ebOC, ebDxz);
			float ebC = dot(ebOC, ebOC) - ebBeamRadius * ebBeamRadius;
			float ebDisc = ebB * ebB - 4.0 * ebA * ebC;

			float ebBeam = 0.0;
			if (ebDisc > 0.0 && ebA > 0.0001) {
				float ebSqrtDisc = sqrt(ebDisc);
				float ebT1 = (-ebB - ebSqrtDisc) / (2.0 * ebA); // entry
				float ebT2 = (-ebB + ebSqrtDisc) / (2.0 * ebA); // exit

				// Clamp to forward ray and geometry
				float ebTMax = ebIsSky ? 1000.0 : ebMaxDist;
				ebT1 = max(ebT1, 0.0);
				ebT2 = min(ebT2, ebTMax);

				if (ebT2 > ebT1) {
					// Clamp to beam height range (Y = cam.y + t * dir.y)
					if (abs(ebRayDir.y) > 0.0001) {
						float ebTBot = (ebBeamBottom - cameraPosition.y) / ebRayDir.y;
						float ebTTop = (ebBeamTop - cameraPosition.y) / ebRayDir.y;
						if (ebTBot > ebTTop) { float tmp = ebTBot; ebTBot = ebTTop; ebTTop = tmp; }
						ebT1 = max(ebT1, ebTBot);
						ebT2 = min(ebT2, ebTTop);
					} else {
						// Horizontal ray: only visible if camera Y is within beam height
						if (cameraPosition.y < ebBeamBottom || cameraPosition.y > ebBeamTop) {
							ebT2 = ebT1; // no intersection
						}
					}

					if (ebT2 > ebT1) {
						// Path length through the cylinder = visible beam density
						float ebPathLen = ebT2 - ebT1;
						// Normalize: a ray through the center of a 7-block-wide beam
						// at perpendicular angle travels ~7 blocks. Scale so that looks good.
						ebBeam = ebPathLen / (ebBeamRadius * 2.0);
						// Soft edge: fade near cylinder boundary using closest XZ distance
						vec2 ebMidXZ = cameraPosition.xz + ebDxz * ((ebT1 + ebT2) * 0.5) - ebBeamCenter.xz;
						float ebMidDist = length(ebMidXZ);
						float ebEdgeFade = smoothstep(ebBeamRadius, ebBeamRadius * 0.3, ebMidDist);
						ebBeam *= ebEdgeFade;
						// Fade near top of beam
						float ebMidY = cameraPosition.y + ebRayDir.y * ((ebT1 + ebT2) * 0.5);
						float ebTopFade = smoothstep(ebBeamTop, ebBeamTop - 60.0, ebMidY);
						ebBeam *= ebTopFade;
					}
				}
			}

			// Darken the scene when the eye is open ? cinematic focus on eye + beam
			// Protect: ground spotlight circle and player entity stay bright
			float ebExposureBase = mix(1.0, 0.35, ebEvent.eyeOpen);
			float ebProtect = 0.0;
			if (!ebIsSky) {
				// Reconstruct world pos for this pixel
				vec3 ebPixelWorld;
				if (ebDepthMC < 0.9999) {
					ebPixelWorld = getWorldPos(texcoord, ebDepthMC);
				} else if (ebHasDH) {
					ebPixelWorld = getWorldPosDH(texcoord, ebDepthDH);
				} else {
					ebPixelWorld = cameraPosition;
				}
				// Protect ground spotlight circle (XZ distance to player)
				float ebGroundDist = length(ebPixelWorld.xz - eyePosition.xz);
				float ebSpotProtect = 1.0 - smoothstep(END_EVENT_SPOTLIGHT_RADIUS * 0.3, END_EVENT_SPOTLIGHT_RADIUS * 1.2, ebGroundDist);
				// Protect player entity (3D distance to player eye)
				float ebEntityDist = length(ebPixelWorld - eyePosition);
				float ebEntityProtect = 1.0 - smoothstep(1.0, 3.0, ebEntityDist);
				ebProtect = max(ebSpotProtect, ebEntityProtect);
			}
			float ebExposureDark = mix(ebExposureBase, 1.0, ebProtect);
			color *= ebExposureDark;

			// Beam color from eye iris settings (brighter, washed-out)
			vec3 ebColor = vec3(
				END_EVENT_EYE_IRIS_R * 0.4 + 0.6,
				END_EVENT_EYE_IRIS_G * 0.2 + 0.5,
				END_EVENT_EYE_IRIS_B * 0.3 + 0.7
			);

			color += ebColor * ebBeam * ebEvent.eyeOpen * END_EVENT_SPOTLIGHT_INTENSITY * 0.4;

			// === Atmosphere effects outside the beam ===
			float ebChaos = ebEvent.eyeOpen;
			float ebOutside = 1.0 - clamp(ebBeam * 3.0 + ebProtect, 0.0, 1.0);

			// 1) Desaturation ? world outside beam drains to near-grayscale
			float ebLuma = dot(color, vec3(0.299, 0.587, 0.114));
			color = mix(color, vec3(ebLuma), ebOutside * ebChaos * 0.65);

			// 2) Purple tint ? eerie color shift outside the beam
			vec3 ebEerieTint = vec3(0.35, 0.15, 0.65);
			color = mix(color, color * ebEerieTint * 2.5, ebOutside * ebChaos * 0.3);

			// 3) Vignette ? screen edges darken dramatically
			float ebVigDist = length(texcoord - vec2(0.5));
			float ebVignette = smoothstep(0.25, 0.8, ebVigDist);
			color *= 1.0 - ebVignette * ebChaos * 0.8;
		}
	}
	#endif

	#if OUTLINES != 0 && !defined(NEON_GAME_MODE)
	ivec2 screenTexelCoord = ivec2(gl_FragCoord.xy);
	// Fade outlines aggressively with fog - outlines disappear quickly in fog
	// Use smoothstep for a harder cutoff: outlines fully gone at ~35% fog density
	float outlineFade = smoothstep(OUTLINE_FOG_FADE, 0.0, fogAmount);
	// Suppress outlines on water surface pixels ? the outline samples depthtex0 which
	// sees underwater block edges through the water, creating dark shapes visible from above.
	float outlineWaterMask = isWaterSurface ? 0.0 : 1.0;
	color *= 1.0 + getOutline(screenTexelCoord) * OUTLINE_BRIGHTNESS * outlineMask * outlineFade * outlineWaterMask;
	#endif

	// Dynamic Handheld Light is now handled in the gbuffers passes (gbuffers_terrain,
	// gbuffers_block, gbuffers_entities, gbuffers_water, etc.) by boosting the blocklight
	// value before lighting is computed. This makes it use the same warm torch color and
	// lightmap falloff curve as world block lights, instead of a post-process screen tint.


	// Add bloom ADDITIVELY on top of sharp original
	// This creates glow AROUND bright objects without making them blurry
	#ifdef BLOOM_ENABLED
	vec3 bloom = texture(colortex2, texcoord).rgb;

	// Simple saturation boost to counter blur desaturation
	float bloomLum = dot(bloom, vec3(0.299, 0.587, 0.114));
	if (bloomLum > 0.01) {
		bloom = mix(vec3(bloomLum), bloom, 1.5);
	}

	// Suppress bloom on emissive source pixels so bloom only glows AROUND them
	if (emissiveFlag >= 0.5) {
		bloom *= 0.15;
	}

	// Sun bloom ? active from sunrise until tick 12880 (sunAngle 0.537), then fades off
	#if !defined(NETHER_SHADER) && !defined(END_SHADER)
	if (postIsSky) {
		float bloomAngle = fract(sunAngle);
		// Fade in at sunrise, stay full through day and sunset, fade out at tick 12880 (angle 0.537)
		float sunBloomFactor = smoothstep(0.0, 0.08, bloomAngle) * (1.0 - smoothstep(0.50, 0.56, bloomAngle));
		bloom *= max(sunBloomFactor, 0.0);
	}
	#endif

	// Suppress bloom on entity pixels to prevent see-through bleed from background emissives.
	// Bloom is screen-space blurred with no depth awareness, so glow from emissive blocks
	// near/behind an entity leaks onto the entity making it look see-through.
	if (isEntityPixel && emissiveFlag < 0.5) {
		bloom *= 0.05;
	}

	// Suppress bloom on fake terrain pixels ? bloom was computed before fake terrain
	// exists so emissive glow from behind the water plane bleeds through.
	if (fakeTerrainHitForFog) {
		bloom *= 0.05;
	}

	// Fog bloom - boost bloom visibility through volumetric fog
	#ifdef VFOG_BLOOM_ENABLED
	if (fogAmount > 0.01) {
		float fogBloomBoost = 1.0 + fogAmount * VFOG_BLOOM_INTENSITY * (1.0 - VFOG_BLOOM_FALLOFF);
		// Do not amplify sky bloom from fog when camera is above the volumetric fog layer.
		if (postIsSky) {
			float vfogTopB = VFOG_HEIGHT_TOP + SEA_LEVEL_OFFSET;
			if (cameraPosition.y > vfogTopB + 2.0) {
				fogBloomBoost = 1.0;
			} else {
				fogBloomBoost = mix(1.0, fogBloomBoost, 0.25);
			}
		}
		bloom *= fogBloomBoost;
	}
	#else
	// When vfog bloom is disabled, suppress bloom in fogged areas
	if (fogAmount > 0.01) {
		bloom *= 1.0 - clamp(fogAmount * 0.8, 0.0, 1.0);
	}
	#endif

	// In the nether, suppress bloom based on fog opacity so it doesn't glow through solid fog
	#ifdef NETHER_FOG_ENABLED
	if (isForcedNetherBiome(biome)) {
		bloom *= 1.0 - clamp(fogAmount, 0.0, 1.0);
	}
	#endif

	// In the End, only apply bloom to block geometry (not sky/clouds)
	#ifdef END_SHADER
	if (postIsSky) {
		bloom = vec3(0.0);
	}
	#endif

	// Skyless worlds: suppress bloom/horizon glow to avoid overbright domes.
	float skyLumNow = dot(max(skyColor, vec3(0.0)), vec3(0.299, 0.587, 0.114));
	float fogLumNow = dot(max(fogColor, vec3(0.0)), vec3(0.299, 0.587, 0.114));
	float skyFogDelta = length(max(skyColor, vec3(0.0)) - max(fogColor, vec3(0.0)));
	bool noSkyBloomFallback = postIsSky && (skyFogDelta < 0.14) && (skyLumNow < 0.35 || fogLumNow < 0.35);
	if (isSkylessWorldHeuristic() || noSkyBloomFallback) {
		bloom *= 0.0;
		horizonFogBloom *= 0.0;
	}

	// Note: 3D cloud bloom suppression now handled implicitly since
	// clouds are composited before final.fsh reads the scene color

	// Compensate bloom brightness for increased radius
	// (wider blur spreads energy thinner ? scale up to maintain brightness)
	bloom *= sqrt(BLOOM_RADIUS / 0.3);

	// Suppress bloom entirely underwater ? screen-space blur bleeds surface/sky glow
	// onto all underwater blocks, washing them out to white before fog runs.
	if (isEyeInWater != 1) {
		color += bloom;
		// Add horizon fog bloom (soft glow at horizon)
		color += horizonFogBloom;
	}
	#endif

	// Post-Processing ? skipped underwater (underwater block handles its own grading)
	if (isEyeInWater != 1) {
		// Sharpening filter (unsharp mask ? samples 4 neighbors)
		#ifdef POST_SHARPEN
		{
			vec2 texelSize = 1.0 / vec2(viewWidth, viewHeight);
			vec3 n = texture(colortex0, texcoord + vec2(0.0,  texelSize.y)).rgb;
			vec3 s = texture(colortex0, texcoord + vec2(0.0, -texelSize.y)).rgb;
			vec3 e = texture(colortex0, texcoord + vec2( texelSize.x, 0.0)).rgb;
			vec3 w = texture(colortex0, texcoord + vec2(-texelSize.x, 0.0)).rgb;
			vec3 blur = (n + s + e + w) * 0.25;
			color = color + (color - blur) * POST_SHARPEN_STRENGTH;
		}
		#endif

		color = (color - 0.5) * POST_CONTRAST + 0.5 + POST_BRIGHTNESS;

		float luma = dot(color, vec3(0.299, 0.587, 0.114));
		color = mix(vec3(luma), color, POST_SATURATION);

		// ========================================================================
		// Y-Fade: Global vertical color tint (world-space)
		// ========================================================================
		#ifdef Y_FADE_ENABLED
		{
			if (!postIsSky) {
				float yFade = 1.0 - smoothstep(YFADE_BOTTOM_Y, YFADE_TOP_Y, postSceneWorldPos.y);
				vec3 fadeColor = vec3(YFADE_COLOR_R, YFADE_COLOR_G, YFADE_COLOR_B);
				color = mix(color, fadeColor, yFade * YFADE_OPACITY);
			}
		}
		#endif

		// ========================================================================
		// Color Grading (Cinematic Vibes)
		// ========================================================================
		#ifdef COLOR_GRADING_ENABLED
		color = applyColorGrading(color, texcoord, frameTimeCounter, frameCounter);
		#endif
	}


	// ========================================================================
	// Underwater Effects
	// ========================================================================
	#ifdef UNDERWATER_FOG_ENABLED
	if (isEyeInWater == 1) {
		// Get scene depth for distance-based fog
		ivec2 uwTexel = ivec2(gl_FragCoord.xy);
		float uwDepthMC = texelFetch(depthtex0, uwTexel, 0).x;
		float uwDepthDH = texelFetch(dhDepthTex, uwTexel, 0).x;
		bool uwHasDH = hasValidDHDepth(uwDepthDH);
		
		// Clamp sky pixels to max visibility distance so they fog out cleanly
		bool uwIsSky = (uwDepthMC >= 0.9999 && !uwHasDH);
		float uwDistance = uwIsSky ? UNDERWATER_VISIBILITY_DISTANCE : far;

		if (!uwIsSky) {
			if (uwDepthMC < 0.9999) {
				vec3 uwWorldPos = getWorldPos(texcoord, uwDepthMC);
				uwDistance = length(uwWorldPos - cameraPosition);
			} else if (uwHasDH) {
				vec3 uwWorldPos = getWorldPosDH(texcoord, uwDepthDH);
				uwDistance = length(uwWorldPos - cameraPosition);
			}
		}

		// Underwater fog color
		vec3 uwFogColor = vec3(UNDERWATER_FOG_R, UNDERWATER_FOG_G, UNDERWATER_FOG_B);

		// Fog factor: exponential density + hard visibility limit
		float uwFogFactor = 1.0 - exp(-uwDistance * UNDERWATER_FOG_DENSITY);
		float uwVisLimit = smoothstep(UNDERWATER_VISIBILITY_DISTANCE * 0.5, UNDERWATER_VISIBILITY_DISTANCE, uwDistance);
		uwFogFactor = max(uwFogFactor * UNDERWATER_FOG_OPACITY, uwVisLimit);
		uwFogFactor = clamp(uwFogFactor, 0.0, 1.0);

		// Time-of-day brightness ? clamped to [0,1] so it only dims, never brightens
		float uwAngle = fract(sunAngle);
		float uwDayFactor = smoothstep(0.02, 0.10, uwAngle) * smoothstep(0.48, 0.40, uwAngle);
		float uwBrightness = clamp(mix(0.05, UNDERWATER_BRIGHTNESS, uwDayFactor), 0.0, 1.0) * UW_BRIGHTNESS;

		color *= uwBrightness;

		// Apply underwater color grading BEFORE fog ? grades the scene, not the fog
		color *= UW_EXPOSURE;
		float uwMid = dot(color, vec3(0.299, 0.587, 0.114));
		color = (color - uwMid) * UW_CONTRAST + uwMid;
		color = max(color, vec3(0.0));
		float uwGradeLum = dot(color, vec3(0.299, 0.587, 0.114));
		color = mix(vec3(uwGradeLum), color, UW_SATURATION);
		float uwMaxC = max(color.r, max(color.g, color.b));
		float uwMinC = min(color.r, min(color.g, color.b));
		float uwPixelSat = (uwMaxC > 0.001) ? (uwMaxC - uwMinC) / uwMaxC : 0.0;
		float uwVibBoost = UW_VIBRANCE * (1.0 - uwPixelSat);
		color = mix(vec3(uwGradeLum), color, 1.0 + uwVibBoost);
		color = pow(max(color, vec3(0.0)), vec3(UW_GAMMA));
		color = color * (UW_WHITE_POINT - UW_BLACK_POINT) + vec3(UW_BLACK_POINT);
		color *= UW_TINT;

		// Underwater fog: blend toward tinted fog color
		vec3 uwTint = max(uwFogColor, vec3(0.001));
		vec3 uwFogTarget = uwTint * clamp(uwBrightness * 0.6, 0.02, uwBrightness);
		color = mix(color, uwFogTarget, uwFogFactor);
		
		// Underwater light shafts from surface (procedural, no shadow maps)
		#ifdef UNDERWATER_LIGHT_SHAFTS
		float uwShaftLightFactor = max(uwDayFactor, 0.10);
		if (uwShaftLightFactor > 0.01) {
			vec4 uwClipPos = vec4(texcoord * 2.0 - 1.0, 0.5, 1.0);
			vec4 uwViewPos = gbufferProjectionInverse * uwClipPos;
			uwViewPos /= uwViewPos.w;
			vec3 viewDir = normalize(mat3(gbufferModelViewInverse) * uwViewPos.xyz);

			float surfaceY = SEA_LEVEL_OFFSET;
			float maxDist = min(uwDistance, UNDERWATER_VISIBILITY_DISTANCE * 0.95);
			float stepSize = max(maxDist / float(UNDERWATER_SHAFT_SAMPLES), 0.001);
			float dither = fract(sin(dot(gl_FragCoord.xy + float(frameCounter) * 0.37, vec2(12.9898, 78.233))) * 43758.5453);
			vec3 sunDirWorld = normalize(mat3(gbufferModelViewInverse) * normalize(shadowLightPosition));

			// Actual sun direction into water ? no abs(), allows angled shafts
			vec3 uwLightDir = normalize(vec3(sunDirWorld.x, -sunDirWorld.y, sunDirWorld.z));
			// Ensure light points at least slightly downward
			if (uwLightDir.y > -0.08) uwLightDir.y = -0.08;
			uwLightDir = normalize(uwLightDir);

			float shafts = 0.0;

			for (int i = 0; i < UNDERWATER_SHAFT_SAMPLES; i++) {
				float tDist = (float(i) + dither) * stepSize;
				vec3 samplePos = cameraPosition + viewDir * tDist;

				// Fade with depth below water surface
				float depthBelowSurface = max(surfaceY - samplePos.y, 0.0);
				float depthFade = exp(-depthBelowSurface * 0.012);

				// Project sample to water surface along light direction for caustic UV
				float tToSurface = (surfaceY - samplePos.y) / max(-uwLightDir.y, 0.1);
				vec2 causticUV = samplePos.xz + uwLightDir.xz * tToSurface;

				// Organic caustic pattern from layered value noise
				float caustic = waterCaustic(causticUV * 0.08, frameTimeCounter);

				// Forward-scatter phase function
				float phase = pow(max(dot(viewDir, -uwLightDir), 0.0), 2.0) * 0.7 + 0.3;

				float rangeFade = 1.0 - smoothstep(maxDist * 0.3, maxDist, tDist);
				shafts += caustic * depthFade * rangeFade * phase;
			}

			shafts /= float(UNDERWATER_SHAFT_SAMPLES);

			float shaftDistFade = 1.0 - smoothstep(24.0, UNDERWATER_VISIBILITY_DISTANCE * 1.15, uwDistance);
			float shaftFogFade = 1.0 - smoothstep(0.80, 1.00, uwFogFactor);
			vec3 shaftColor = mix(uwTint, vec3(0.82, 0.93, 1.0), 0.65);
			float shaftIntensity = UNDERWATER_SHAFT_INTENSITY * uwShaftLightFactor * shaftDistFade * shaftFogFade;
			vec3 shaftAdd = shaftColor * shafts * shaftIntensity;

			// Clamp brightness to avoid blown-out shafts
			float shaftLum = dot(shaftAdd, vec3(0.299, 0.587, 0.114));
			float maxShaftLum = 0.25 * max(uwBrightness, 0.35);
			if (shaftLum > maxShaftLum && shaftLum > 0.0001) {
				shaftAdd *= maxShaftLum / shaftLum;
			}
			color += shaftAdd;
		}
		#endif
		
		color = clamp(color, 0.0, 1.0);
	}
	#endif

	// === BLOCK ID OUTLINE DEBUG ===
	// Connected texture fade - blend edges between different block types
	#ifdef BLOCK_ID_OUTLINE_DEBUG
	{
		vec2 px = 1.0 / vec2(viewWidth, viewHeight);
		float cID = texture(colortex6, texcoord).r;
		
		if (cID > 0.001) {
			float minD = 99.0;
			
			// Check distance 1
			float s1L = texture(colortex6, texcoord + vec2(-px.x, 0.0)).r;
			float s1R = texture(colortex6, texcoord + vec2(px.x, 0.0)).r;
			float s1U = texture(colortex6, texcoord + vec2(0.0, -px.y)).r;
			float s1D = texture(colortex6, texcoord + vec2(0.0, px.y)).r;
			if ((s1L > 0.001 && abs(s1L - cID) > 0.00001) || 
			    (s1R > 0.001 && abs(s1R - cID) > 0.00001) ||
			    (s1U > 0.001 && abs(s1U - cID) > 0.00001) ||
			    (s1D > 0.001 && abs(s1D - cID) > 0.00001)) minD = 1.0;
			
			// Check distance 2
			if (minD > 1.5) {
				float s2L = texture(colortex6, texcoord + vec2(-px.x*2.0, 0.0)).r;
				float s2R = texture(colortex6, texcoord + vec2(px.x*2.0, 0.0)).r;
				float s2U = texture(colortex6, texcoord + vec2(0.0, -px.y*2.0)).r;
				float s2D = texture(colortex6, texcoord + vec2(0.0, px.y*2.0)).r;
				if ((s2L > 0.001 && abs(s2L - cID) > 0.00001) || 
				    (s2R > 0.001 && abs(s2R - cID) > 0.00001) ||
				    (s2U > 0.001 && abs(s2U - cID) > 0.00001) ||
				    (s2D > 0.001 && abs(s2D - cID) > 0.00001)) minD = 2.0;
			}
			
			// Check distance 3
			if (minD > 2.5) {
				float s3L = texture(colortex6, texcoord + vec2(-px.x*3.0, 0.0)).r;
				float s3R = texture(colortex6, texcoord + vec2(px.x*3.0, 0.0)).r;
				float s3U = texture(colortex6, texcoord + vec2(0.0, -px.y*3.0)).r;
				float s3D = texture(colortex6, texcoord + vec2(0.0, px.y*3.0)).r;
				if ((s3L > 0.001 && abs(s3L - cID) > 0.00001) || 
				    (s3R > 0.001 && abs(s3R - cID) > 0.00001) ||
				    (s3U > 0.001 && abs(s3U - cID) > 0.00001) ||
				    (s3D > 0.001 && abs(s3D - cID) > 0.00001)) minD = 3.0;
			}
			
			// Check distance 4
			if (minD > 3.5) {
				float s4L = texture(colortex6, texcoord + vec2(-px.x*4.0, 0.0)).r;
				float s4R = texture(colortex6, texcoord + vec2(px.x*4.0, 0.0)).r;
				float s4U = texture(colortex6, texcoord + vec2(0.0, -px.y*4.0)).r;
				float s4D = texture(colortex6, texcoord + vec2(0.0, px.y*4.0)).r;
				if ((s4L > 0.001 && abs(s4L - cID) > 0.00001) || 
				    (s4R > 0.001 && abs(s4R - cID) > 0.00001) ||
				    (s4U > 0.001 && abs(s4U - cID) > 0.00001) ||
				    (s4D > 0.001 && abs(s4D - cID) > 0.00001)) minD = 4.0;
			}
			
			// Check distance 5
			if (minD > 4.5) {
				float s5L = texture(colortex6, texcoord + vec2(-px.x*5.0, 0.0)).r;
				float s5R = texture(colortex6, texcoord + vec2(px.x*5.0, 0.0)).r;
				float s5U = texture(colortex6, texcoord + vec2(0.0, -px.y*5.0)).r;
				float s5D = texture(colortex6, texcoord + vec2(0.0, px.y*5.0)).r;
				if ((s5L > 0.001 && abs(s5L - cID) > 0.00001) || 
				    (s5R > 0.001 && abs(s5R - cID) > 0.00001) ||
				    (s5U > 0.001 && abs(s5U - cID) > 0.00001) ||
				    (s5D > 0.001 && abs(s5D - cID) > 0.00001)) minD = 5.0;
			}
			
			// Check distance 6
			if (minD > 5.5) {
				float s6L = texture(colortex6, texcoord + vec2(-px.x*6.0, 0.0)).r;
				float s6R = texture(colortex6, texcoord + vec2(px.x*6.0, 0.0)).r;
				float s6U = texture(colortex6, texcoord + vec2(0.0, -px.y*6.0)).r;
				float s6D = texture(colortex6, texcoord + vec2(0.0, px.y*6.0)).r;
				if ((s6L > 0.001 && abs(s6L - cID) > 0.00001) || 
				    (s6R > 0.001 && abs(s6R - cID) > 0.00001) ||
				    (s6U > 0.001 && abs(s6U - cID) > 0.00001) ||
				    (s6D > 0.001 && abs(s6D - cID) > 0.00001)) minD = 6.0;
			}
			
			// Visualize: red = close to edge, green = far
			if (minD <= 6.0) {
				float t = minD / 6.0;
				color = vec3(1.0 - t, t, 0.0);
			}
		}
	}
	#endif

	// ========================================================================
	// Underwater water surface / glass: overlay solid fog color.
	// Opacity = 1 - UNDERWATER_SURFACE_VISIBILITY so the setting controls how much
	// of the scene bleeds through (0.03 = 97% opaque, 0.30 = 70% opaque).
	if (isEyeInWater == 1 && (isUnderwaterSurface || isTranslucentPx)) {
		vec3 uwTint = vec3(UNDERWATER_FOG_R, UNDERWATER_FOG_G, UNDERWATER_FOG_B);
		float uwAngle = fract(sunAngle);
		float uwDay = smoothstep(0.02, 0.10, uwAngle) * smoothstep(0.48, 0.40, uwAngle);
		float uwBright = clamp(mix(0.05, UNDERWATER_BRIGHTNESS, uwDay), 0.0, 1.0) * UW_BRIGHTNESS;
		vec3 surfaceColor = uwTint * clamp(uwBright * 0.6, 0.02, uwBright);
		float opacity = 1.0 - UNDERWATER_SURFACE_VISIBILITY;
		color = mix(color, surfaceColor, opacity);
	}
	gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}



