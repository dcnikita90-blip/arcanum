/* RENDERTARGETS: 0,1,3,4,5 */

// Translucent entity pass - catches text_display backgrounds, name tag
// backgrounds, and translucent entity overlays (player skin layers, etc.)
// when ENTITY_TRANSLUCENT is active.

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"

uniform sampler2D gtexture;
uniform int entityId;
uniform float frameTimeCounter;
uniform float sunAngle;
uniform vec3 fogColor;
uniform int biome_category;
uniform float fogStart;
uniform float fogEnd;
uniform vec3 cameraPosition;
uniform sampler2D shadowtex0;
uniform vec3 shadowLightPosition;
uniform int frameCounter;

#include "/include/shadow.glsl"
#include "/include/lighting.glsl"
#if defined(END_SHADER) && defined(END_EVENT_ENABLED)
#include "/include/end_event.glsl"
#endif

in vec2 texcoord;
in vec4 glcolor;
in vec3 worldPos;
in float skylight;
in float blocklight;
in float viewDistance;
in float nametagHolo;
in vec4 shadowPos;
in vec3 normal;

// Get view-independent fog color based on time of day
vec3 getTimeBasedFogColor() {
    float angle = fract(sunAngle);
    float isDay = smoothstep(0.02, 0.08, angle) * smoothstep(0.48, 0.42, angle);
    float twilight = smoothstep(0.40, 0.46, angle) * smoothstep(0.58, 0.52, angle)
                   + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);
    float blueHour = smoothstep(0.50, 0.56, angle) * smoothstep(0.66, 0.60, angle);
    float isNight = smoothstep(0.58, 0.64, angle) * smoothstep(0.98, 0.92, angle);
    float totalWeight = max(isDay + twilight + blueHour + isNight, 0.001);
    isDay /= totalWeight; twilight /= totalWeight; blueHour /= totalWeight; isNight /= totalWeight;
    if (isForcedNetherBiome(biome)) {
        return getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    }    float biomeDayGate = smoothstep(0.18, 0.78, isDay + twilight * 0.30);
    float biomeBlendStrength = SKY_BIOME_BLEND * biomeDayGate;
    float biomeTintDay = biomeBlendStrength;
    float biomeTintTwilight = biomeBlendStrength * 0.55;
    float biomeTintBlueHour = biomeBlendStrength * 0.40;
    float biomeTintNight = biomeBlendStrength * 0.20;
    vec3 biomeFogOverride = getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    vec3 dayFog = mix(vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B), biomeFogOverride, biomeTintDay) * DAY_BRIGHTNESS;
    vec3 sunsetFog = mix(vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B), biomeFogOverride, biomeTintTwilight) * SUNSET_BRIGHTNESS;
    vec3 blueFog = mix(vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B), biomeFogOverride, biomeTintBlueHour) * BLUEHOUR_BRIGHTNESS;
    vec3 nightFog = mix(vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B), biomeFogOverride, biomeTintNight) * NIGHT_BRIGHTNESS;
    return dayFog * isDay + sunsetFog * twilight + blueFog * blueHour + nightFog * isNight;
}

float hash12_entity_t(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float smoothChunkNoiseEntityT(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12_entity_t(i);
    float b = hash12_entity_t(i + vec2(1.0, 0.0));
    float c = hash12_entity_t(i + vec2(0.0, 1.0));
    float d = hash12_entity_t(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
        vec4 color = texture(gtexture, texcoord) * glcolor;

        // Very low alpha threshold for translucent geometry
        if (color.a < 0.01) {
                discard;
        }

        #if defined(CHUNK_FADE_OUT_ENABLED) && !defined(DISTANT_HORIZONS)
        if (!isForcedNetherBiome(biome) && !isForcedEndBiome(biome)) {
                float horizontalDist = length(worldPos.xz - cameraPosition.xz);
                float distGate = smoothstep(CHUNK_FADE_OUT_RADIUS, CHUNK_FADE_OUT_RADIUS + 24.0, horizontalDist);
                if (distGate > 0.001) {
                        float reveal = 1.0 - distGate; // Near=1, Far=0
                        float minY = SEA_LEVEL_OFFSET - 96.0;
                        float maxY = SEA_LEVEL_OFFSET + 320.0;
                        float mask = smoothChunkNoiseEntityT(worldPos.xz * 0.12);
                        float jitterY = (mask - 0.5) * 10.0;
                        float revealY = mix(minY, maxY, reveal) + jitterY;
                        float visible = 1.0 - smoothstep(revealY - 8.0, revealY + 8.0, worldPos.y);
                        color.a *= visible;
                        if (color.a < 0.01) {
                                discard;
                        }
                }
        }
        #endif

        vec3 entityRawColor = color.rgb;
        float emissive = 0.0;

        // Procedural entity glow for mobs that don't have native emissive render layers
        if (entityId == 100) { // Piglin variants
            if (color.r > 0.95 && color.g > 0.95 && color.b > 0.95) emissive = 1.0 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 101) { // Ghast
            if (color.r > 0.8 && color.g < 0.2 && color.b < 0.2) emissive = 1.0 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 102) { // Stray
            if (color.r > 0.95 && color.g > 0.95 && color.b > 0.95) emissive = 1.0 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 103) { // Bogged
            if (color.r > 0.7 && color.g > 0.8 && color.b < 0.4) emissive = 0.8 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 104) { // Breeze
            if (color.r > 0.8 && color.g > 0.9 && color.b > 0.9) emissive = 0.9 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 105) { // Blaze
            if (color.r > 0.8 && color.g > 0.5 && color.b < 0.2) emissive = 0.7 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 106) { // Vex
            if (color.r > 0.5 && color.g > 0.8 && color.b > 0.9) emissive = 0.8 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 107) { // Endermite
            if (color.r > 0.6 && color.g < 0.3 && color.b < 0.3) emissive = 0.9 * PROCEDURAL_GLOW_STRENGTH;
        } else if (entityId == 108) { // Guardian/Elder
            if (color.r > 0.9 && color.g > 0.5 && color.b < 0.6) emissive = 0.6 * PROCEDURAL_GLOW_STRENGTH;
        }

        if (emissive > 0.5) {
            color.rgb *= mix(1.0, EMISSIVE_BRIGHTNESS, float(0.5)) * PROCEDURAL_GLOW_STRENGTH;
        }

        #ifdef SHADOWS_ENABLED
        if (shadowPos.w > 0.5) {
                float dotNL = dot(normal, normalize(shadowLightPosition));

                float dither = hash12_entity_t(gl_FragCoord.xy); // pseudo-dither using entity hash
                float r = quartic_length(shadowPos.xy * 2.0 - 1.0);
                float distortFactor = r + SHADOW_DISTORTION;

                float selfShadowBias = 0.003;
                float slopeBias = (SHADOW_NORMAL_BIAS * 0.0001) * (1.1 - dotNL);
                float totalBias = selfShadowBias + slopeBias;

                vec3 biasedShadowPos = shadowPos.xyz;
                biasedShadowPos.z -= totalBias;

                vec3 shadow = getShadowColorPCF(shadowtex0, shadowcolor0, biasedShadowPos, distortFactor, dither, 0.0);

                float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
                shadow = mix(shadow, vec3(1.0), fadeFactor);

                // Fix skylight for translucent entities (e.g. Iris player model)
                float rawShadowVal = dot(shadow, vec3(0.299, 0.587, 0.114));
                float entitySkylight = max(skylight, rawShadowVal * 0.95);

                shadow = mix(vec3(1.0), shadow, entitySkylight);
                shadow = mix(vec3(1.0), shadow, SHADOW_OPACITY);

                color.rgb = applyLightingWithShadow(color.rgb, sunAngle, entitySkylight, blocklight, emissive, shadow);
        } else {
                color.rgb = applyLightingEmissive(color.rgb, sunAngle, skylight, blocklight, emissive);
        }
        #else
        color.rgb = applyLightingEmissive(color.rgb, sunAngle, skylight, blocklight, emissive);
        #endif
        #ifdef HANDHELD_LIGHT_ENABLED
        if (emissive < 0.5) color.rgb += getHandheldLightBoost(worldPos, entityRawColor, color.rgb);
        #endif
        color.rgb *= TERRAIN_BRIGHTNESS;

        // End dimension: darken entities and add bluish-purple ambient tint (matches terrain)
        #ifdef END_SHADER
        if (emissive < 0.5) {
                float entBaseDarken = 0.55;
                vec3 purpleTint = vec3(0.08, 0.06, 0.35);
                float entTintMult = 0.15;
                float entColorShift = 0.55;

                float entPreserveBlend = 0.0;
                vec3 entPreservedLight = vec3(0.0);

                #if defined(END_SHADER) && defined(END_EVENT_ENABLED)
                float entEventDarkness = getEndEventTerrainDarkness(frameTimeCounter);
                if (entEventDarkness > 0.001) {
                        float bFalloff = getBlocklightFalloff(blocklight, skylight);
                        vec3 endBlockColor = vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B);
                        entPreservedLight = entityRawColor * endBlockColor * bFalloff * bFalloff * END_BLOCKLIGHT_BRIGHTNESS * TERRAIN_BRIGHTNESS;

                        #ifdef HANDHELD_LIGHT_ENABLED
                        entPreservedLight += getHandheldLightBoost(worldPos, entityRawColor, vec3(0.0)) * TERRAIN_BRIGHTNESS;
                        #endif

                        entPreserveBlend = entEventDarkness;
                }
                entBaseDarken = mix(entBaseDarken, 0.02, entEventDarkness);
                entTintMult = mix(entTintMult, 0.0, entEventDarkness);
                entColorShift = mix(entColorShift, 0.0, entEventDarkness);
                #endif

                color.rgb *= entBaseDarken;
                color.rgb += purpleTint * entTintMult;
                color.rgb = mix(color.rgb, color.rgb * vec3(0.55, 0.58, 1.35), entColorShift);

                color.rgb += entPreservedLight * entPreserveBlend;
        }
        #endif

        // Fog
        float denom = max(fogEnd - fogStart, 0.0001);
        float fogFactor = clamp((fogEnd - viewDistance) / denom, 0.0, 1.0);
        color.rgb = mix(getTimeBasedFogColor(), color.rgb, fogFactor);

        gl_FragData[0] = color;
        gl_FragData[1] = vec4(1.0, emissive, 0.0, 0.5);
        gl_FragData[2] = vec4(emissive > 0.5 ? color.rgb * EMISSIVE_BRIGHTNESS : vec3(0.0), 1.0);
        gl_FragData[3] = vec4(0.0);
        gl_FragData[4] = vec4(0.0);
}




