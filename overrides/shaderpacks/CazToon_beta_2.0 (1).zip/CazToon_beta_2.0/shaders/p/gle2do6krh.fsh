/* RENDERTARGETS: 0,1,2,4,5 */

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"
#include "/include/shadow.glsl"
#include "/include/hovering.glsl"
#include "/include/water_color.glsl"

uniform sampler2D gtexture;
uniform sampler2D shadowtex0;
#ifdef PBR_ENABLED
uniform sampler2D normals;
uniform sampler2D specular;
#endif
uniform sampler2D depthtex1;  // Depth without translucents (for foam)
uniform mat4 gbufferProjectionInverse;
uniform float near;
uniform float far;
uniform float alphaTestRef;
uniform vec3 fogColor;
uniform int biome_category;
uniform float fogStart;
uniform float fogEnd;
uniform float sunAngle;
uniform vec3 shadowLightPosition;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

#include "/include/lighting.glsl"
uniform float frameTimeCounter;
uniform int frameCounter;
uniform int isEyeInWater;

in vec2 texcoord;
in vec4 glcolor;
in float viewDistance;
in float postMask;
in float isWater;
in float isHologram;
in vec3 worldPos;
in vec3 viewPos;
in vec3 normal;
in float skylight;
in float blocklight;
in vec3 waveNormal; // Wave-perturbed normal from vertex shader
in vec4 shadowPos;
flat in float isIce;  // 1.0 = ice block (for SSR)
flat in float isHeatSource;
#ifdef PBR_ENABLED
in vec3 tangentVec;
in vec3 binormalVec;
#endif

// Get view-independent fog color based on time of day
vec3 getTimeBasedFogColor() {
    float angle = fract(sunAngle);
    float isDay = smoothstep(0.02, 0.08, angle) * smoothstep(0.48, 0.42, angle);
    float twilight = smoothstep(0.40, 0.46, angle) * smoothstep(0.58, 0.52, angle)
                   + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);
    float blueHour = smoothstep(0.50, 0.56, angle) * smoothstep(0.66, 0.60, angle);
    float isNight = smoothstep(0.58, 0.64, angle) * smoothstep(0.98, 0.92, angle);
    float totalWeight = max(isDay + twilight + blueHour + isNight, 0.001);
    isDay /= totalWeight; twilight /= totalWeight; blueHour /= totalWeight; isNight /= totalWeight;
    if (isForcedNetherBiome(biome)) {
        return getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    }    float biomeDayGate = smoothstep(0.18, 0.78, isDay + twilight * 0.30);
    float biomeBlendStrength = SKY_BIOME_BLEND * biomeDayGate;
    float biomeTintDay = biomeBlendStrength;
    float biomeTintTwilight = biomeBlendStrength * 0.55;
    float biomeTintBlueHour = biomeBlendStrength * 0.40;
    float biomeTintNight = biomeBlendStrength * 0.20;
    vec3 biomeFogOverride = getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    vec3 dayFog = mix(vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B), biomeFogOverride, biomeTintDay) * DAY_BRIGHTNESS;
    vec3 sunsetFog = mix(vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B), biomeFogOverride, biomeTintTwilight) * SUNSET_BRIGHTNESS;
    vec3 blueFog = mix(vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B), biomeFogOverride, biomeTintBlueHour) * BLUEHOUR_BRIGHTNESS;
    vec3 nightFog = mix(vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B), biomeFogOverride, biomeTintNight) * NIGHT_BRIGHTNESS;
    return dayFog * isDay + sunsetFog * twilight + blueFog * blueHour + nightFog * isNight;
}

float random(float x) {
    return fract(sin(x * 12.9898) * 43758.5453);
}

float hash12_water(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float smoothChunkNoiseWater(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12_water(i);
    float b = hash12_water(i + vec2(1.0, 0.0));
    float c = hash12_water(i + vec2(0.0, 1.0));
    float d = hash12_water(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

vec3 getBiomeWaterTint() {
    vec3 tint = vec3(WATER_COLOR_R, WATER_COLOR_G, WATER_COLOR_B);

    if (biome == BIOME_SWAMP) {
        tint = vec3(0.38, 0.482, 0.392);
    } else if (biome == BIOME_LUKEWARM_OCEAN || biome == BIOME_DEEP_LUKEWARM_OCEAN) {
        tint = vec3(0.271, 0.678, 0.949);
    } else if (biome == BIOME_WARM_OCEAN) {
        tint = vec3(0.263, 0.835, 0.933);
    } else if (biome == BIOME_COLD_OCEAN || biome == BIOME_DEEP_COLD_OCEAN || biome == BIOME_SNOWY_TAIGA || biome == BIOME_SNOWY_BEACH) {
        tint = vec3(0.239, 0.341, 0.839);
    } else if (biome == BIOME_FROZEN_RIVER || biome == BIOME_FROZEN_OCEAN || biome == BIOME_DEEP_FROZEN_OCEAN) {
        tint = vec3(0.224, 0.22, 0.788);
    } else if (biome == BIOME_MEADOW) {
        tint = vec3(0.055, 0.306, 0.812);
    } else if (biome == BIOME_MANGROVE_SWAMP) {
        tint = vec3(0.227, 0.478, 0.416);
    }

    return tint;
}

// Detect glass/translucent non-water blocks
float detectGlass(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    float minC = min(min(color.r, color.g), color.b);
    float saturation = brightness > 0.01 ? (brightness - minC) / brightness : 0.0;

    bool isWaterLike = (color.b > color.r * 1.2) && (color.b > 0.25) && (saturation > 0.3);
    if (isWaterLike) return 0.0;

    bool isIceLike = (color.b > color.r) && (brightness > 0.6) && (saturation < 0.4);
    if (isIceLike) return 0.0;

    return 1.0;
}

void main() {
    vec4 tex = texture(gtexture, texcoord);
    vec4 color = tex * glcolor;
    if (color.a < alphaTestRef) {
        discard;
    }

    // Note: water surface quads are kept when underwater (they provide the
    // subtle "looking up through water" visual), but colortex4 and colortex5
    // are suppressed below to avoid confusing final.fsh fog classification.

    // Chunk fade-out dissolve.
    if (!isForcedNetherBiome(biome) && !isForcedEndBiome(biome) && isEyeInWater != 1) {
        #if defined(CHUNK_FADE_OUT_ENABLED) && !defined(DISTANT_HORIZONS)
        float horizontalDist = length(worldPos.xz - cameraPosition.xz);
        float distGate = smoothstep(CHUNK_FADE_OUT_RADIUS, CHUNK_FADE_OUT_RADIUS + 24.0, horizontalDist);
        if (distGate > 0.001) {
            float reveal = 1.0 - distGate;
            float minY = SEA_LEVEL_OFFSET - 96.0;
            float maxY = SEA_LEVEL_OFFSET + 320.0;
            float mask = smoothChunkNoiseWater(worldPos.xz * 0.12);
            float jitterY = (mask - 0.5) * 10.0;
            float revealY = mix(minY, maxY, reveal) + jitterY;
            float visible = 1.0 - smoothstep(revealY - 8.0, revealY + 8.0, worldPos.y);
            color.a *= visible;
            if (color.a < 0.01) {
                discard;
            }
        }
        #endif
    }

    vec3 rawColor = color.rgb;
    float emissive = 0.0;
    vec3 lightColor = vec3(0.0);
    vec3 waterTint = vec3(0.0);
    bool isBackFace = !gl_FrontFacing;

    // Calculate shadows (used by non-water translucents and foam)
    float shadow = 1.0;
    #ifdef SHADOWS_ENABLED
    if (skylight > 0.1) {
        #ifdef SHARP_SHADOWS
            float mapDepth = texture(shadowtex0, shadowPos.xy).r;
            shadow = step(shadowPos.z, mapDepth);
            float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
            shadow = mix(shadow, 1.0, fadeFactor);
        #else
            float dither = interleavedGradientNoise(gl_FragCoord.xy, frameCounter);
            float r = quartic_length(shadowPos.xy * 2.0 - 1.0);
            float distortFactor = r + SHADOW_DISTORTION;
            shadow = getShadowFaded(shadowtex0, shadowPos.xyz, distortFactor, viewDistance, dither);
        #endif

        shadow = mix(1.0, shadow, skylight);
        shadow = mix(1.0, shadow, SHADOW_OPACITY);
    }
    #endif

    float bl_water = blocklight;

    // ========================================================================
    // WATER
    // ========================================================================
    if (isWater > 0.5) {
        // --- Base color: biome tint (vertex color) + texture pattern ---
        vec3 finalTint = glcolor.rgb;
        float texPattern = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
        vec3 waterColorSetting = finalTint * mix(0.85, texPattern * 1.7, 0.35);

        waterTint = finalTint;

        // --- Lighting: shared waterLitColor (NO shadow maps on water) ---
        color.rgb = waterLitColor(waterColorSetting, sunAngle);

        // --- MC water surface color grading ---
        // Exposure
        color.rgb *= MC_WATER_EXPOSURE;
        // Contrast (pivot at luminance midpoint)
        {
            float cMid = dot(color.rgb, vec3(0.299, 0.587, 0.114));
            color.rgb = (color.rgb - cMid) * MC_WATER_CONTRAST + cMid;
        }
        // Saturation ? applied after lighting so sky tint doesn't undo it
        {
            float cLum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
            color.rgb = mix(vec3(cLum), color.rgb, WATER_SATURATION * MC_WATER_SATURATION);
        }
        // Vibrance ? boost low-saturation channels
        {
            float cLum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
            float maxC = max(max(color.rgb.r, color.rgb.g), color.rgb.b);
            float sat = (maxC > 0.001) ? (maxC - min(min(color.rgb.r, color.rgb.g), color.rgb.b)) / maxC : 0.0;
            color.rgb = mix(color.rgb, vec3(cLum) + (color.rgb - vec3(cLum)) * (1.0 + MC_WATER_VIBRANCE * (1.0 - sat)), 1.0);
        }
        // Gamma
        color.rgb = pow(max(color.rgb, vec3(0.0)), vec3(MC_WATER_GAMMA));
        // Black/white point
        color.rgb = (color.rgb - MC_WATER_BLACK_POINT) / max(MC_WATER_WHITE_POINT - MC_WATER_BLACK_POINT, 0.001);
        // Tint + brightness
        color.rgb *= MC_WATER_TINT * MC_WATER_BRIGHTNESS;
        color.rgb = max(color.rgb, vec3(0.0));

        // --- Opacity ---
        vec3 waterWorldNormal = normalize(mat3(gbufferModelViewInverse) * normal);

        // Discard water fragments whose geometry normal points downward ? these are the
        // underside/back-face of the horizontal water surface. They render through solid
        // blocks (ice, glass) due to sort order and have no visible purpose above water.
        if (isEyeInWater != 1 && waterWorldNormal.y < -0.3) {
            discard;
        }

        if (isEyeInWater == 1) {
            color.a = MC_WATER_OPACITY * UNDERWATER_SURFACE_VISIBILITY;
        } else if (isBackFace) {
            color.a = MC_WATER_OPACITY * 0.7;
        } else {
            color.a = 1.0;
        }

        // --- Water Foam ---
        #ifdef WATER_FOAM_ENABLED
        if (isEyeInWater != 1 && !isBackFace) {
            vec2 screenCoord = gl_FragCoord.xy / vec2(textureSize(depthtex1, 0));
            float terrainDepth = texture(depthtex1, screenCoord).r;

            float waterLinear = (2.0 * near * far) / (far + near - (gl_FragCoord.z * 2.0 - 1.0) * (far - near));
            float terrainLinear = (2.0 * near * far) / (far + near - (terrainDepth * 2.0 - 1.0) * (far - near));

            float depthDiff = terrainLinear - waterLinear;
            float foamFactor = 1.0 - smoothstep(0.0, WATER_FOAM_WIDTH, depthDiff);
            foamFactor *= foamFactor;

            vec3 foamColor = vec3(WATER_FOAM_COLOR_R, WATER_FOAM_COLOR_G, WATER_FOAM_COLOR_B);
            foamColor = waterLitColor(foamColor, sunAngle);
            vec3 foamTinted = mix(color.rgb, foamColor, 0.45);
            float foamBlend = foamFactor * WATER_FOAM_INTENSITY * 0.85;
            color.rgb = mix(color.rgb, foamTinted, foamBlend);
        }
        #endif

        // --- Specular (front faces only, above water only) ---
        if (!isBackFace && isEyeInWater != 1) {
            #ifdef WATER_WAVES_ENABLED
            vec3 waterNormal = normalize(waveNormal);
            #else
            vec3 waterNormal = normal;
            #endif

            vec3 viewDir = normalize(-viewPos);
            vec3 sunDir = normalize(shadowLightPosition);
            vec3 spec = waterSpecular(viewDir, sunDir, waterNormal, sunAngle);
            color.rgb += spec * skylight;
        }

        // NOTE: Reflections (sky and SSR) are handled in composite7.fsh
    }

    // ========================================================================
    // NON-WATER TRANSLUCENTS (glass, ice, etc.)
    // ========================================================================
    if (isWater < 0.5) {
        color.rgb = applyLightingWithShadow(color.rgb, sunAngle, skylight, bl_water, 0.0, shadow);

        // PBR specular on non-water translucent blocks (ice, glass, etc.)
        #ifdef PBR_ENABLED
        {
            vec4 normalData = texture(normals, texcoord);
            vec4 specData = texture(specular, texcoord);
            bool normalIsFlat = abs(normalData.r - 0.5) < 0.02 && abs(normalData.g - 0.5) < 0.02 && normalData.b > 0.95;
            bool specIsEmpty = (specData.r + specData.g + specData.b + specData.a) < 0.01;
            bool hasPBR = !normalIsFlat || !specIsEmpty;
            if (hasPBR) {
                float pbrRoughness;
                float pbrF0;
                #ifdef MC_TEXTURE_FORMAT_LAB_PBR
                pbrRoughness = pow(1.0 - specData.r, 2.0);
                pbrF0 = (specData.g * 255.0 > 229.5) ? 0.7 : max(specData.g * (255.0 / 229.0), 0.02);
                #else
                pbrRoughness = pow(1.0 - specData.r, 2.0);
                pbrF0 = step(0.5, specData.g) > 0.5 ? 0.7 : 0.04;
                #endif

                vec3 N;
                if ((normalData.r + normalData.g + normalData.b) > 0.01) {
                    vec3 tN = normalData.rgb * 2.0 - 1.0;
                    tN.xy *= PBR_NORMAL_STRENGTH;
                    mat3 TBN = mat3(normalize(tangentVec), normalize(binormalVec), normalize(normal));
                    N = normalize(TBN * normalize(tN));
                } else {
                    N = normalize(normal);
                }

                vec3 L = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
                vec3 Nw = normalize(mat3(gbufferModelViewInverse) * N);
                vec3 Vw = normalize(cameraPosition - worldPos);
                vec3 Hw = normalize(Vw + L);
                float NdotL = max(dot(Nw, L), 0.0);
                float NdotH = max(dot(Nw, Hw), 0.0);
                float NdotV = max(dot(Nw, Vw), 0.001);

                float a = max(pbrRoughness, 0.04);
                float a2 = a * a;
                float a4 = a2 * a2;
                float denom = NdotH * NdotH * (a4 - 1.0) + 1.0;
                float D = a4 / (3.14159265 * denom * denom);
                float ct = max(NdotV, 0.05);
                float F = pbrF0 + (1.0 - pbrF0) * pow(1.0 - ct, 5.0);
                float spec = D * F * NdotL;

                float dayFactor = smoothstep(0.02, 0.10, fract(sunAngle)) * smoothstep(0.48, 0.40, fract(sunAngle));
                color.rgb += spec * PBR_SPECULAR_STRENGTH * shadow * skylight * dayFactor;
            }
        }
        #endif
    }

    #ifdef HANDHELD_LIGHT_ENABLED
    if (emissive < 0.5) color.rgb += getHandheldLightBoost(worldPos, rawColor, color.rgb);
    #endif

    // Fog - only for non-water translucents (glass, ice, etc.)
    // Water surface gets no fog ? any view-distance-based tint creates a
    // horizontal line at camera eye level where fogFactor changes sign.
    if (emissive < 0.5 && isWater < 0.5) {
        float denom = max(fogEnd - fogStart, 0.0001);
        float fogFactor = clamp((fogEnd - viewDistance) / denom, 0.0, 1.0);
        if (isEyeInWater == 1) {
            vec3 uwFogCol = vec3(UNDERWATER_FOG_R, UNDERWATER_FOG_G, UNDERWATER_FOG_B);
            color.rgb = mix(uwFogCol, color.rgb, fogFactor);
        }
    }

    gl_FragData[0] = color;
    gl_FragData[1] = vec4(postMask, emissive, skylight, isHeatSource);
    gl_FragData[2] = vec4(lightColor, 1.0);

    // Glass tint for color filtering.
    // Suppress underwater: glassTint.a = 0 prevents final.fsh from classifying
    // the underwater water-surface pixel as isWaterSurface, which would skip
    // normal underwater fog application.
    if (isWater > 0.5 && isEyeInWater != 1) {
        gl_FragData[3] = vec4(waterTint, 0.3);
    } else if (isWater > 0.5 && isEyeInWater == 1) {
        // Marker: water surface back face seen from underwater (a=0.2)
        gl_FragData[3] = vec4(0.0, 0.0, 0.0, 0.2);
    } else {
        gl_FragData[3] = vec4(0.0);
    }

    // Output water data for reflections (colortex5).
    // Suppress underwater: composite7 SSR should not fire on underwater water-surface pixels.
    #ifdef WATER_REFLECTIONS_ENABLED
    if ((isWater > 0.5 || isIce > 0.5) && isEyeInWater != 1) {
        vec3 viewNormal;
        float reflAmount;
        if (isWater > 0.5) {
            #ifdef WATER_WAVES_ENABLED
            viewNormal = normalize(waveNormal);
            #else
            viewNormal = normalize(normal);
            #endif
            reflAmount = WATER_REFLECTION_AMOUNT;
        } else {
            viewNormal = normalize(normal);
            reflAmount = MATERIAL_REFLECTION_AMOUNT;
        }

        vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * viewNormal);
        float packedLmcoord = dot(floor(255.0 * vec2(blocklight, skylight) + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
        float packedReflect = dot(floor(255.0 * vec2(reflAmount, 0.0) + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
        vec3 encodedNormal = worldNormal * 0.5 + 0.5;

        gl_FragData[4] = vec4(packedLmcoord, packedReflect, encodedNormal.x, encodedNormal.y);
    } else {
        gl_FragData[4] = vec4(0.0);
    }
    #else
    gl_FragData[4] = vec4(0.0);
    #endif
}




