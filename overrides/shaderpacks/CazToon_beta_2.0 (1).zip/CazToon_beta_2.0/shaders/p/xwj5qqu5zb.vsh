
// Simple pass-through vertex shader for cloud geometry
// We discard all cloud pixels in the fragment shader

out vec2 texcoord;
out vec4 glcolor;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
}
