// End Void Event — Cinematic sky collapse & cosmic eye cycle
// Shared by end_sky.glsl (sky rendering) and gbuffers_terrain.fsh (terrain darkness)
// No uniform dependencies — all values passed as parameters

#ifndef END_EVENT_GLSL
#define END_EVENT_GLSL

struct EndEvent {
    float skyDarkness;      // 0 = normal, 1 = full blackout
    float vortexSpeedMult;  // 1.0 = normal speed, higher = faster spiral
    float vortexSizeMult;   // 1.0 = normal, 0 = collapsed to point
    float effectsFade;      // 1.0 = all effects visible, 0 = all off
    float cloudSpeedMult;   // 1.0 = normal cloud orbit speed, higher = faster
    float eyeOpen;          // 0 = closed, 1 = fully open
    float bangFlash;        // 0 = no flash, 1 = peak white flash
    float bangProgress;     // 0..1 progress through the bang phase (for ring expansion)
    float terrainDarkness;  // 0 = normal terrain, 1 = maximum terrain darkening
    float fogDarkness;      // 0 = normal fog, 1 = fog goes black
    float suctionWarp;      // 0 = no warp, 1 = full black-hole distortion toward zenith
    float vortexTime;       // integrated vortex animation time (accounts for speed changes smoothly)
    float cloudTime;        // integrated cloud animation time (same approach as vortexTime)
};

// Hermite smoothstep helper
float eventSmooth(float t) {
    return t * t * (3.0 - 2.0 * t);
}

EndEvent getEndEvent(float time) {
    EndEvent e;
    e.skyDarkness = 0.0;
    e.vortexSpeedMult = 1.0;
    e.vortexSizeMult = 1.0;
    e.effectsFade = 1.0;
    e.cloudSpeedMult = 1.0;
    e.eyeOpen = 0.0;
    e.bangFlash = 0.0;
    e.bangProgress = -1.0;
    e.terrainDarkness = 0.0;
    e.fogDarkness = 0.0;
    e.suctionWarp = 0.0;
    e.vortexTime = time; // default: use raw time
    e.cloudTime = time;  // default: use raw time

    float cycleTime = END_EVENT_CYCLE;
    // Phase durations (blackout is configurable, rest are fixed)
    float p1Dur = 12.0;  // acceleration
    float p2Dur = 10.0;  // suction/implosion
    float p3Dur = END_EVENT_BLACKOUT; // blackout (configurable)
    float p4Dur = 4.0;   // big bang
    float p5Dur = 12.0;  // eye
    float p6Dur = 10.0;  // settle to normal

    float eventDuration = p1Dur + p2Dur + p3Dur + p4Dur + p5Dur + p6Dur;
    float eventStart = cycleTime - eventDuration;
    float t = mod(time, cycleTime);

    // Phase 0: Normal — before event starts
    // vortexTime = raw time (speedMult = 1.0, no correction needed)
    if (t < eventStart) return e;

    // Remap t to event-local time
    float et = t - eventStart;

    // Phase boundary times
    float p1End = p1Dur;
    float p2End = p1End + p2Dur;
    float p3End = p2End + p3Dur;
    float p4End = p3End + p4Dur;
    float p5End = p4End + p5Dur;

    // ── Integrated vortex time ──
    // Instead of time * speedMult (which jumps when speedMult changes),
    // we integrate speedMult over the event to get smooth continuous rotation.
    //
    // Phase 1: speedMult ramps 1→6, integral = t + 5*t³/(3*12²), full = 32
    // Phase 2: speedMult ramps 6→12, full ≈ 90
    // Phase 3: vortex invisible — smoothly absorb excess rotation so that
    //          by end of blackout, integ = real elapsed time (no excess)
    // Phase 4-6: speedMult = 1, integ = et (real time, seamless with Phase 0)
    //
    // vortexTime = (time - t) + eventStart + integ
    // Uses absolute cycle base (time - t) so it's continuous across cycle boundaries.

    float p1FullInteg = p1Dur + 5.0 * p1Dur / 3.0; // 12 + 20 = 32
    // Phase 2: smoothstep integral is approximately 0.5, so avg speed ≈ (6+12)/2 = 9
    float p2FullInteg = (6.0 + 12.0) * 0.5 * p2Dur; // 9 * 10 = 90

    // ── Integrated cloud time (same approach as vortex) ──
    // Cloud speed: Phase 1: 1→5, Phase 2: 5→10, Phase 3: 0, Phase 4: 0→1, Phase 5-6: 1
    float cp1FullInteg = p1Dur + 4.0 * p1Dur / 3.0; // 12 + 16 = 28
    float cp2FullInteg = (5.0 + 10.0) * 0.5 * p2Dur; // 7.5 * 10 = 75

    float integ = 0.0; // accumulated vortex-time from event start
    float cInteg = 0.0; // accumulated cloud-time from event start

    // ── Phase 1: Acceleration ──
    if (et < p1End) {
        float p = et / p1Dur;
        p = p * p;
        e.vortexSpeedMult = mix(1.0, 6.0, p);
        e.cloudSpeedMult = mix(1.0, 5.0, p);
        e.vortexSizeMult = mix(1.0, 0.5, p);

        // Integral of (1 + 5*(t/12)^2) from 0 to et = et + 5*et^3/(3*144)
        integ = et + 5.0 * et * et * et / (3.0 * p1Dur * p1Dur);
        // Cloud: integral of (1 + 4*(t/12)^2) from 0 to et = et + 4*et^3/(3*144)
        cInteg = et + 4.0 * et * et * et / (3.0 * p1Dur * p1Dur);
    }
    // ── Phase 2: Suction / Implosion ──
    else if (et < p2End) {
        float p = (et - p1End) / p2Dur;
        float ease = eventSmooth(p);
        e.vortexSpeedMult = mix(6.0, 12.0, ease);
        e.cloudSpeedMult = mix(5.0, 10.0, ease);
        e.vortexSizeMult = mix(0.5, 0.0, ease);
        e.skyDarkness = ease;
        e.effectsFade = 1.0 - ease;
        e.suctionWarp = ease;
        e.terrainDarkness = ease;
        e.fogDarkness = ease;

        // Phase 1 full + Phase 2 partial (approximate with linear interpolation of speed)
        float p2Local = et - p1End;
        float avgSpeed = mix(6.0, mix(6.0, 12.0, ease), 0.5);
        integ = p1FullInteg + avgSpeed * p2Local;
        // Cloud: same approach with cloud speeds (5→10)
        float cAvgSpeed = mix(5.0, mix(5.0, 10.0, ease), 0.5);
        cInteg = cp1FullInteg + cAvgSpeed * p2Local;
    }
    // ── Phase 3: Blackout (configurable duration) ──
    else if (et < p3End) {
        e.skyDarkness = 1.0;
        e.effectsFade = 0.0;
        e.vortexSpeedMult = 0.0;
        e.vortexSizeMult = 0.0;
        e.cloudSpeedMult = 0.0;
        e.suctionWarp = 1.0;
        e.terrainDarkness = 1.0;
        e.fogDarkness = 1.0;

        // During blackout the vortex/clouds are invisible, so we use this time to
        // smoothly absorb the excess integrated rotation. By end of blackout,
        // integ = p3End (real elapsed time) so phases 4-6 (speed=1) end with
        // vortexTime/cloudTime matching raw time at cycle boundary — no snap.
        float p3Local = et - p2End;
        float p3Frac = p3Local / p3Dur; // 0..1 through blackout
        float smoothP3 = eventSmooth(p3Frac);
        // Lerp from the fast-integrated value to the real-time value
        float integ_fast = p1FullInteg + p2FullInteg;                  // where we were
        float integ_real = (p1Dur + p2Dur) + p3Local;                  // where real time is
        integ = mix(integ_fast, integ_real, smoothP3);
        // Cloud: same absorption
        float cInteg_fast = cp1FullInteg + cp2FullInteg;
        cInteg = mix(cInteg_fast, integ_real, smoothP3);
    }
    // ── Phase 4: Big Bang ──
    else if (et < p4End) {
        float p = (et - p3End) / p4Dur;
        float bang = pow(p, 0.4);
        float vortexGrow = p * p;
        e.bangProgress = p;
        e.bangFlash = max(1.0 - p * 4.0, 0.0);
        e.bangFlash *= e.bangFlash;
        e.skyDarkness = 1.0 - bang;
        e.effectsFade = bang;
        e.vortexSpeedMult = 1.0;
        e.vortexSizeMult = vortexGrow;
        e.cloudSpeedMult = mix(0.0, 1.0, bang);
        e.suctionWarp = 1.0 - bang;
        e.terrainDarkness = 1.0 - bang;
        e.fogDarkness = 1.0 - bang;

        // Speed=1, corrected base from blackout: integ = real event time
        integ = et;
        cInteg = et;
    }
    // ── Phase 5: Eye opens right after bang ──
    else if (et < p5End) {
        float p = (et - p4End) / p5Dur;

        #ifdef END_EVENT_EYE_ENABLED
        if (p < 0.20) {
            e.eyeOpen = eventSmooth(p / 0.20);
        } else if (p < 0.51) {
            e.eyeOpen = 1.0;
        } else if (p < 0.535) {
            float blinkP = (p - 0.51) / 0.025;
            e.eyeOpen = 1.0 - eventSmooth(blinkP);
        } else if (p < 0.555) {
            float blinkP = (p - 0.535) / 0.02;
            e.eyeOpen = eventSmooth(blinkP);
        } else if (p < 0.80) {
            e.eyeOpen = 1.0;
        } else {
            float closeP = (p - 0.80) / 0.20;
            e.eyeOpen = 1.0 - eventSmooth(closeP);
        }
        #endif

        // Speed=1 throughout, corrected base: integ = real event time
        integ = et;
        cInteg = et;
    }
    // ── Phase 6: Settle to normal ──
    else {
        // Speed=1, corrected base: integ = real event time
        integ = et;
        cInteg = et;
    }

    // vortexTime = absolute cycle base + event-local integrated time
    // (time - t) gives the absolute time at the start of this cycle,
    // then we add eventStart + integ for the event-local portion.
    // This is continuous across phase boundaries AND across cycle boundaries
    // because at end of Phase 6: integ = eventDuration, so
    // vortexTime = (time - t) + eventStart + eventDuration = (time - t) + cycleTime
    // which matches Phase 0 of the next cycle: vortexTime = time = (time-t) + cycleTime + small
    e.vortexTime = (time - t) + eventStart + integ;
    e.cloudTime = (time - t) + eventStart + cInteg;

    return e;
}

// Lightweight version for terrain passes — only returns darkness value
float getEndEventTerrainDarkness(float time) {
    float cycleTime = END_EVENT_CYCLE;
    float p1End = 12.0;
    float p2End = p1End + 10.0;
    float p3End = p2End + END_EVENT_BLACKOUT;
    float p4End = p3End + 4.0;
    float eventDuration = p4End + 12.0 + 10.0;
    float eventStart = cycleTime - eventDuration;
    float t = mod(time, cycleTime);

    if (t < eventStart) return 0.0;
    float et = t - eventStart;

    // Phase 2: Suction ramp
    if (et >= p1End && et < p2End) {
        float p = (et - p1End) / 10.0;
        return eventSmooth(p);
    }
    // Phase 3: Blackout
    if (et >= p2End && et < p3End) return 1.0;
    // Phase 4: Big Bang restore
    if (et >= p3End && et < p4End) {
        float p = (et - p3End) / 4.0;
        return 1.0 - pow(p, 0.4);
    }
    return 0.0;
}

#endif
