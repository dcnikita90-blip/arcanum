// Shared water wave functions (used by MC water + DH water)

#ifndef WATER_WAVES_GLSL
#define WATER_WAVES_GLSL

#ifdef WATER_WAVES_ENABLED

// --------------------------------------------------------------------------
// Bliss-style water waves (original implementation)
// - Coherent wind-driven swells (Gerstner-like height field)
// - Small ripples layered on top
// - Analytic derivatives for stable normals (no LOD/finite-diff artifacts)
//
// Controls (existing sliders):
// - WATER_WAVE_HEIGHT : overall amplitude
// - WATER_WAVE_SPEED  : phase speed multiplier
// - WATER_WAVE_SCALE  : frequency multiplier (higher = smaller waves)
// - WATER_WAVE_DETAIL : ripple intensity
// --------------------------------------------------------------------------

const float WATER_PI = 3.14159265359;

// "Wind" direction in world XZ (fixed for coherence; tweakable later via setting if desired)
vec2 waterWindDir() {
	return normalize(vec2(0.82, 0.57));
}

// Phase helper
float waterWavePhase(vec2 dir, float k, float w, vec2 pos, float t) {
	return k * dot(dir, pos) + w * t;
}

// Returns height and accumulates dh/dx, dh/dz for analytic normal
float waterWaveHeightAndDeriv(in vec2 pos, in float t, out vec2 dHdXZ) {
	// Map scale slider to a sane frequency multiplier.
	// Higher WATER_WAVE_SCALE => tighter waves.
	// NOTE: WATER_WAVE_SCALE is already authored as a small (0.05..0.50) frequency control.
	// Do NOT shrink it further, otherwise wavelengths become enormous and the surface just "bobs".
	float freqMul = max(WATER_WAVE_SCALE, 0.001);
	float speedMul = max(WATER_WAVE_SPEED, 0.0) * 0.9;
	float ampMul = WATER_WAVE_HEIGHT;
	float rippleMul = clamp(WATER_WAVE_DETAIL, 0.0, 1.0);

	// Base directions (dominant + cross components)
	vec2 d1 = waterWindDir();
	vec2 d2 = normalize(vec2(-d1.y, d1.x));
	vec2 d3 = normalize(mix(d1, d2, 0.35));
	vec2 d4 = normalize(mix(d1, -d2, 0.55));

	// Wavelengths in blocks (before applying freqMul).
	// Tuned so default settings show clear wave SHAPE across typical view distances.
	float L1 = 36.0;
	float L2 = 18.0;
	float L3 = 9.0;
	float L4 = 5.0;

	// Convert to wavenumber; incorporate slider frequency
	float k1 = (2.0 * WATER_PI / L1) * freqMul;
	float k2 = (2.0 * WATER_PI / L2) * freqMul;
	float k3 = (2.0 * WATER_PI / L3) * freqMul;
	float k4 = (2.0 * WATER_PI / L4) * freqMul;

	// Phase speeds (not physically exact; tuned for pleasant motion)
	float w1 = 0.65 * speedMul;
	float w2 = 0.95 * speedMul;
	float w3 = 1.35 * speedMul;
	float w4 = 1.90 * speedMul;

	// Amplitudes (relative). Keep small enough to avoid extreme displacement.
	float A1 = 0.60 * ampMul;
	float A2 = 0.26 * ampMul;
	float A3 = 0.12 * ampMul;
	float A4 = 0.06 * ampMul;

	float p1 = waterWavePhase(d1, k1, w1, pos, t);
	float p2 = waterWavePhase(d2, k2, w2, pos, t);
	float p3 = waterWavePhase(d3, k3, w3, pos, t);
	float p4 = waterWavePhase(d4, k4, w4, pos, t);

	float s1 = sin(p1); float c1 = cos(p1);
	float s2 = sin(p2); float c2 = cos(p2);
	float s3 = sin(p3); float c3 = cos(p3);
	float s4 = sin(p4); float c4 = cos(p4);

	float height = A1 * s1 + A2 * s2 + A3 * s3 + A4 * s4;

	// Derivatives: d/dx sin(k dot(d,pos)+wt) = cos(phase) * k * d.x
	dHdXZ = vec2(0.0);
	dHdXZ += A1 * c1 * k1 * d1;
	dHdXZ += A2 * c2 * k2 * d2;
	dHdXZ += A3 * c3 * k3 * d3;
	dHdXZ += A4 * c4 * k4 * d4;

	// Ripples: tiny high-frequency detail that reads like wind texture
	if (rippleMul > 0.001) {
		// Ripple wavelengths (blocks), scaled by freqMul.
		float rL1 = 4.0;
		float rL2 = 2.5;
		float rK1 = (2.0 * WATER_PI / rL1) * (freqMul * 3.0);
		float rK2 = (2.0 * WATER_PI / rL2) * (freqMul * 3.0);
		float rW = 3.2 * speedMul;
		vec2 rd1 = normalize(d1 + vec2(0.37, -0.19));
		vec2 rd2 = normalize(d1 + vec2(-0.21, 0.41));
		float rp1 = rK1 * dot(rd1, pos) + rW * t;
		float rp2 = rK2 * dot(rd2, pos) - (rW * 0.9) * t;
		float rA = 0.035 * ampMul * rippleMul;
		float rs1 = sin(rp1); float rc1 = cos(rp1);
		float rs2 = sin(rp2); float rc2 = cos(rp2);
		height += rA * (rs1 + 0.7 * rs2);
		dHdXZ += rA * (rc1 * rK1 * rd1 + 0.7 * rc2 * rK2 * rd2);
	}

	return height;
}

// Generate wave height at a world XZ position
float waterGetWaveHeight(vec2 pos, float time) {
	vec2 dHdXZ;
	return waterWaveHeightAndDeriv(pos, time, dHdXZ);
}

// Calculate wave normal analytically using dh/dx, dh/dz
vec3 waterCalcWaveNormal(vec2 pos, float time) {
	vec2 dHdXZ;
	waterWaveHeightAndDeriv(pos, time, dHdXZ);
	// Normal for height field y = h(x,z): n = normalize((-dh/dx, 1, -dh/dz))
	return normalize(vec3(-dHdXZ.x, 1.0, -dHdXZ.y));
}

#endif // WATER_WAVES_ENABLED

#endif // WATER_WAVES_GLSL
