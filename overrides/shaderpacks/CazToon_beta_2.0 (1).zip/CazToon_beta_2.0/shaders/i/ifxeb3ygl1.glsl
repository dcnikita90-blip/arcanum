// Shadow sampling utilities
// Based on iterationT shader approach

#ifndef SHADOW_GLSL
#define SHADOW_GLSL

float pow4(float x) { return x * x * x * x; }

float quartic_length(vec2 v) {
    return sqrt(sqrt(pow4(v.x) + pow4(v.y)));
}

// Distortion function - MUST be identical in shadow.vsh and when sampling
// Uses quartic length for better detail distribution at the center of the shadow map
// Outside SHADOWS_ENABLED guard because shadow.vsh always needs it
vec3 distortShadowClipPos(vec3 pos) {
    float factor = quartic_length(pos.xy) + SHADOW_DISTORTION;
    return vec3(pos.xy / factor, pos.z * SHADOW_DEPTH_SCALE);
}

#ifdef SHADOWS_ENABLED

uniform sampler2D shadowcolor0;

// Bias computation - reciprocal of derivative of quartic distortion
// Scaled by (0.5 / SHADOW_DEPTH_SCALE) to compensate for Z compression
float computeBias(vec3 pos) {
    float r = quartic_length(pos.xy);
    float factor = r + SHADOW_DISTORTION;
    float numerator = factor * factor; // Quadratic derivative scale (more stable)
    
    // Scale bias inversely with depth scale (0.2 needs more bias than 0.5)
    float depthScaleCompensation = 0.5 / SHADOW_DEPTH_SCALE;
    return SHADOW_NORMAL_BIAS / float(shadowMapResolution) * (numerator / SHADOW_DISTORTION) * depthScaleCompensation;
}

// Normal bias method from Complementary Reimagined (via Photon shader)
// Offsets position along surface normal - works at all sun angles including noon/midnight
vec3 getShadowBias(vec3 scenePos, vec3 normal, float NoL) {
    // Scale bias with distance to prevent peter-panning on close objects
    float distanceFactor = clamp(0.12 + 0.01 * length(scenePos), 0.0, 1.0);
    // More bias at grazing angles (when NoL is low)
    float angleFactor = 2.0 - clamp(NoL, 0.0, 1.0);
    return 0.25 * normal * distanceFactor * angleFactor;
}

// Interleaved gradient noise for dithering
float interleavedGradientNoise(vec2 pos) {
    return fract(52.9829189 * fract(0.06711056 * pos.x + 0.00583715 * pos.y));
}
float interleavedGradientNoise(vec2 pos, int t) {
    return interleavedGradientNoise(pos + 5.588238 * float(t & 63));
}

mat2 getRotationMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat2(c, -s, s, c);
}

const vec2[16] blueNoiseDisk = vec2[](
    vec2( 0.478712,  0.875764),
    vec2(-0.337956, -0.793959),
    vec2(-0.955259, -0.028164),
    vec2( 0.864527,  0.325689),
    vec2( 0.209342, -0.395657),
    vec2(-0.106779,  0.672585),
    vec2( 0.156213,  0.235113),
    vec2(-0.413644, -0.082856),
    vec2(-0.415667,  0.323909),
    vec2( 0.141896, -0.939980),
    vec2( 0.954932, -0.182516),
    vec2(-0.766184,  0.410799),
    vec2(-0.434912, -0.458845),
    vec2( 0.415242, -0.078724),
    vec2( 0.728335, -0.491777),
    vec2(-0.058086, -0.066401)
);

// PCF shadow sampling - soft edges
float getShadowPCF(sampler2D shadowtex, vec3 shadowScreenPos, float distortFactor, float dither) {
    // Check bounds
    if (shadowScreenPos.x < 0.001 || shadowScreenPos.x > 0.999 ||
        shadowScreenPos.y < 0.001 || shadowScreenPos.y > 0.999 ||
        shadowScreenPos.z < 0.0 || shadowScreenPos.z > 1.0) {
        return 1.0;
    }
    
    float filterRadius = SHADOW_PCF_RADIUS * (1.0 / float(shadowMapResolution)) * distortFactor;
    mat2 rotateAndScale = getRotationMatrix(6.28318 * dither) * filterRadius;
    
    float shadow = 0.0;
    const int sampleCount = 6;
    
    for (int i = 0; i < sampleCount; ++i) {
        vec2 offset = rotateAndScale * blueNoiseDisk[i];
        vec2 sampleCoord = shadowScreenPos.xy + offset;
        
        float sampleDepth = texture(shadowtex, sampleCoord).r;
        shadow += step(shadowScreenPos.z, sampleDepth);
    }
    
    return shadow / float(sampleCount);
}

// Colored PCF shadow sampling - returns the tint multiplier
vec3 getShadowColorPCF(sampler2D shadowtex, sampler2D colortex, vec3 shadowScreenPos, float distortFactor, float dither, float bias) {
    if (shadowScreenPos.x < 0.001 || shadowScreenPos.x > 0.999 ||
        shadowScreenPos.y < 0.001 || shadowScreenPos.y > 0.999 ||
        shadowScreenPos.z < 0.0 || shadowScreenPos.z > 1.0) {
        return vec3(1.0);
    }
    
    float filterRadius = SHADOW_PCF_RADIUS * (1.0 / float(shadowMapResolution)) * distortFactor;
    mat2 rotateAndScale = getRotationMatrix(6.28318 * dither) * filterRadius;
    
    vec3 shadowColor = vec3(0.0);
    const int sampleCount = 6;
    
    for (int i = 0; i < sampleCount; ++i) {
        vec2 offset = rotateAndScale * blueNoiseDisk[i];
        vec2 sampleCoord = shadowScreenPos.xy + offset;
        
        float sampleDepth = texture(shadowtex, sampleCoord).r;
        if (shadowScreenPos.z - bias > sampleDepth) {
            vec4 col = texture(colortex, sampleCoord);
            // Bliss style: Transmission is (1.0 - alpha) * color
            // Higher saturation for that Bliss "pop"
            vec3 transmit = col.rgb * (1.0 - col.a);
            shadowColor += transmit;
        } else {
            shadowColor += vec3(1.0);
        }
    }
    
    return shadowColor / float(sampleCount);
}

// Hardware-filtered shadow - sharp edges but no visible pixels (bilinear-interpolated comparison)
float getShadowHardwareFiltered(sampler2DShadow shadowtex, vec3 shadowScreenPos) {
    if (shadowScreenPos.x < 0.001 || shadowScreenPos.x > 0.999 ||
        shadowScreenPos.y < 0.001 || shadowScreenPos.y > 0.999 ||
        shadowScreenPos.z < 0.0 || shadowScreenPos.z > 1.0) {
        return 1.0;
    }
    // texture() with sampler2DShadow does hardware depth comparison with bilinear filtering
    return texture(shadowtex, shadowScreenPos);
}

// Optimized Sharp Shadow - uses single sample from sampler2D
float getShadowSharp(sampler2D shadowtex, vec3 shadowScreenPos) {
    if (shadowScreenPos.x < 0.001 || shadowScreenPos.x > 0.999 ||
        shadowScreenPos.y < 0.001 || shadowScreenPos.y > 0.999 ||
        shadowScreenPos.z < 0.0 || shadowScreenPos.z > 1.0) {
        return 1.0;
    }
    float mapDepth = texture(shadowtex, shadowScreenPos.xy).r;
    return step(shadowScreenPos.z, mapDepth);
}

// Distance faded sharp shadow
float getShadowFaded(sampler2D shadowtex, vec3 shadowScreenPos, float viewDistance) {
    float shadow = getShadowSharp(shadowtex, shadowScreenPos);
    
    float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
    return mix(shadow, 1.0, fadeFactor);
}

// Hardware-filtered variant (deprecated but kept for compatibility)
float getShadowSharp(sampler2DShadow shadowtex, vec3 shadowScreenPos) {
    return getShadowHardwareFiltered(shadowtex, shadowScreenPos);
}

// Shadow with distance fade
float getShadowFaded(sampler2D shadowtex, vec3 shadowScreenPos, float distortFactor, float viewDistance, float dither) {
    float shadow = getShadowPCF(shadowtex, shadowScreenPos, distortFactor, dither);
    
    float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
    return mix(shadow, 1.0, fadeFactor);
}

// New overload for sharp shadows with distance fade
float getShadowFaded(sampler2DShadow shadowtex, vec3 shadowScreenPos, float viewDistance) {
    float shadow = getShadowHardwareFiltered(shadowtex, shadowScreenPos);
    
    float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
    return mix(shadow, 1.0, fadeFactor);
}

// Legacy overload for compatibility
float getShadowFaded(sampler2D shadowtex, vec3 shadowScreenPos, vec3 shadowClipPos, float viewDistance, float dither) {
    float r = quartic_length(shadowClipPos.xy);
    float distortFactor = r + SHADOW_DISTORTION;
    return getShadowFaded(shadowtex, shadowScreenPos, distortFactor, viewDistance, dither);
}

// Wide PCF for leaf blocks — blurs shadow edges to hide blocky leaf geometry
float getShadowLeafSoft(sampler2D shadowtex, vec3 shadowScreenPos, float distortFactor, float dither) {
    if (shadowScreenPos.x < 0.001 || shadowScreenPos.x > 0.999 ||
        shadowScreenPos.y < 0.001 || shadowScreenPos.y > 0.999 ||
        shadowScreenPos.z < 0.0 || shadowScreenPos.z > 1.0) {
        return 1.0;
    }

    float filterRadius = LEAF_SHADOW_SOFTNESS * (1.0 / float(shadowMapResolution)) * distortFactor;
    mat2 rotateAndScale = getRotationMatrix(6.28318 * dither) * filterRadius;

    float shadow = 0.0;
    for (int i = 0; i < 16; ++i) {
        vec2 offset = rotateAndScale * blueNoiseDisk[i];
        float sampleDepth = texture(shadowtex, shadowScreenPos.xy + offset).r;
        shadow += step(shadowScreenPos.z, sampleDepth);
    }
    return shadow / 16.0;
}

// Distance-faded leaf soft shadow
float getShadowLeafFaded(sampler2D shadowtex, vec3 shadowScreenPos, float distortFactor, float viewDistance, float dither) {
    float shadow = getShadowLeafSoft(shadowtex, shadowScreenPos, distortFactor, dither);
    float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
    return mix(shadow, 1.0, fadeFactor);
}

#endif // SHADOWS_ENABLED

#endif
