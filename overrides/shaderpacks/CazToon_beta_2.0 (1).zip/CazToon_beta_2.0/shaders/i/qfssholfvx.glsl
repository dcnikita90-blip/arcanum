// Shared water color/lighting/specular — used by MC water, DH water, and fake terrain
// This ensures all three water types produce the SAME base color.
#ifndef WATER_COLOR_GLSL
#define WATER_COLOR_GLSL

// =========================================================================
// ALL WATER TWEAKABLES — edit these here, one place for everything
// =========================================================================

// --- MC water surface (gbuffers_water) ---
const float MC_WATER_BRIGHTNESS  = 0.4;              // overall brightness multiplier
const float MC_WATER_EXPOSURE    = 1.0;              // exposure (applied before tonemap)
const float MC_WATER_CONTRAST    = 1.0;              // contrast (1.0 = neutral, >1 = more contrast)
const float MC_WATER_SATURATION  = 0.6;              // saturation multiplier (on top of WATER_SATURATION)
const float MC_WATER_VIBRANCE    = 0.0;              // vibrance — boosts low-sat colors only (-1 to 1)
const float MC_WATER_GAMMA       = 1.5;              // gamma (1.0 = neutral, <1 = brighter mids)
const float MC_WATER_BLACK_POINT = 0.0;              // lift blacks (0.0 = true black)
const float MC_WATER_WHITE_POINT = 1.0;              // compress whites (1.0 = full range)
const vec3  MC_WATER_TINT        = vec3(1.0, 1.0, 1.0); // color tint multiplier
// MC_WATER_OPACITY = 1.0             // opacity — edit in settings.glsl ~1047 (also in-game menu)
//   Only affects back-faces and the underwater upward view. Front face from above is always alpha=1.

// --- DH water surface (dh_water) ---
// Defaults match MC_WATER_* so MC/DH water looks identical out of the box.
// Tweak these independently to adjust DH LOD water without touching MC water.
const float DH_WATER_BRIGHTNESS  = 0.3;              // overall brightness multiplier
const float DH_WATER_EXPOSURE    = 1.0;              // exposure (applied before tonemap)
const float DH_WATER_CONTRAST    = 1.5;              // contrast (1.0 = neutral, >1 = more contrast)
const float DH_WATER_SATURATION  = 0.9;              // saturation multiplier (on top of WATER_SATURATION)
const float DH_WATER_VIBRANCE    = 0.0;              // vibrance — boosts low-sat colors only (-1 to 1)
const float DH_WATER_GAMMA       = 1.5;              // gamma (1.0 = neutral, <1 = brighter mids)
const float DH_WATER_BLACK_POINT = 0.0;              // lift blacks (0.0 = true black)
const float DH_WATER_WHITE_POINT = 1.0;              // compress whites (1.0 = full range)
const vec3  DH_WATER_TINT        = vec3(1.0, 1.0, 1.0); // color tint multiplier
// DH_WATER_OPACITY = 1.0             // opacity — edit in settings.glsl line ~1009 (also in-game menu)

// --- Underwater fog (final.fsh) ---
// Note: fog color (R/G/B), density, opacity, visibility distance, and brightness
// are in settings.glsl and exposed in the in-game menu (search UNDERWATER_FOG_*).
// These constants control the shape of the fog curve and are not in the menu.
const float UW_FOG_SCATTER      = 0.6;              // how much of the fog target is in-scattered light (0=pure absorption, 1=bright glow)
const float UW_FOG_SCATTER_MIN  = 0.02;             // minimum fog target brightness — floor of how dark full fog gets (0=pitch black, 0.1=always some glow)
const float UW_FOG_SCATTER_MAX  = 0.4;              // maximum fog target brightness — ceiling for shallow/bright water (0.4=medium, 1.0=very bright)
const float UW_FOG_DEPTH_DECAY  = 0.015;            // how fast light fades per block below the surface (higher = faster falloff, e.g. 0.005=slow, 0.05=fast)
const float UW_FOG_RANGE_START  = 1.5;              // shaft/fog range fade start, fraction of max distance (0.3 = fade starts at 30%)

// --- Underwater color grading (final.fsh) ---
const float UW_BRIGHTNESS  = 1.0;              // overall brightness multiplier (use UNDERWATER_BRIGHTNESS in settings for base level)
const float UW_EXPOSURE    = 1.0;              // exposure (applied before tonemap)
const float UW_CONTRAST    = 1.0;              // contrast (1.0 = neutral, >1 = more contrast)
const float UW_SATURATION  = 1.0;              // color saturation (1.0 = neutral, 0 = grey)
const float UW_VIBRANCE    = 1.0;              // vibrance — boosts low-sat colors only (-1 to 1)
const float UW_GAMMA       = 1.0;              // gamma curve (1.0 = neutral, <1 = brighter mids, >1 = darker)
const float UW_BLACK_POINT = 0.0;              // lift blacks (0.0 = true black, 0.05 = lifted)
const float UW_WHITE_POINT = 1.0;              // compress whites (1.0 = full, 0.8 = dimmer highlights)
const vec3  UW_TINT        = vec3(1.0, 1.0, 1.0); // color tint (e.g. vec3(0.8, 0.95, 1.1) for cool)

// =========================================================================

// Time-of-day blend weights + brightness for water
// Returns: xyz = (day, sunset, night) weights, w = brightness
vec4 waterTimeOfDay(float sunAngle) {
    float angle = fract(sunAngle);
    float day = smoothstep(0.03, 0.10, angle) * (1.0 - smoothstep(0.40, 0.47, angle));
    float sunset = smoothstep(0.38, 0.45, angle) * (1.0 - smoothstep(0.48, 0.55, angle))
                 + smoothstep(0.95, 1.0, angle) + (1.0 - smoothstep(0.0, 0.05, angle));
    float night = smoothstep(0.52, 0.58, angle) * (1.0 - smoothstep(0.92, 0.98, angle));
    float total = max(day + sunset + night, 0.25);
    day /= total; sunset /= total; night /= total;
    // Brightness curve matches getTimeOfDayLighting in lighting.glsl
    float brightness = 1.0 * day + 0.85 * sunset + max(0.04, NIGHT_AMBIENT * 2.0) * night;
    return vec4(day, sunset, night, brightness);
}

// Ambient sky tint for water surfaces
vec3 waterAmbientTint(float day, float sunset, float night) {
    vec3 daySky = mix(vec3(DAY_MID_R, DAY_MID_G, DAY_MID_B),
                      vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B), 0.35);
    vec3 sunsetSky = mix(vec3(SUNSET_MID_R, SUNSET_MID_G, SUNSET_MID_B),
                         vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B), 0.75);
    vec3 nightSky = mix(vec3(NIGHT_MID_R, NIGHT_MID_G, NIGHT_MID_B),
                        vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B), 0.55);
    // Normalize luminance so dark sky colors don't crush water brightness
    float dL = dot(daySky, vec3(0.299, 0.587, 0.114));
    daySky = clamp(daySky / max(dL, 0.35), vec3(0.0), vec3(2.0));
    float sL = dot(sunsetSky, vec3(0.299, 0.587, 0.114));
    sunsetSky = clamp(sunsetSky / max(sL, 0.35), vec3(0.0), vec3(2.0));
    float nL = dot(nightSky, vec3(0.299, 0.587, 0.114));
    nightSky = clamp(nightSky / max(nL, 0.35), vec3(0.0), vec3(2.0));
    vec3 tint = daySky * day + sunsetSky * sunset + nightSky * night;
    return mix(vec3(1.0), tint, SKYLIGHT_COLOR_TINT);
}

// Compute lit water color — THE single formula for all water types
vec3 waterLitColor(vec3 baseColor, float sunAngle) {
    vec4 tod = waterTimeOfDay(sunAngle);
    vec3 tint = waterAmbientTint(tod.x, tod.y, tod.z);
    return baseColor * tod.w * tint;
}

// Sun/moon specular highlight on water — shared by all water types
// viewDir and sunDir should be in the SAME space (view-space or world-space)
vec3 waterSpecular(vec3 viewDir, vec3 sunDir, vec3 normal, float sunAngle) {
    vec3 halfDir = normalize(viewDir + sunDir);
    float spec = pow(max(dot(normal, halfDir), 0.0), 128.0);
    vec4 tod = waterTimeOfDay(sunAngle);
    vec3 sunColor = vec3(1.0, 0.95, 0.8) * tod.x
                  + vec3(1.0, 0.6, 0.3) * tod.y
                  + vec3(0.5, 0.6, 0.8) * tod.z * 0.3;
    return sunColor * spec * WATER_SPECULAR_INTENSITY;
}

#endif

