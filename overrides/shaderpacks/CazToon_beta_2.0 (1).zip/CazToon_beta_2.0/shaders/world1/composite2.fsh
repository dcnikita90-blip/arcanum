#version 330 compatibility

#define END_SHADER

#include "/program/composite2.fsh"
