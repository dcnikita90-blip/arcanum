#version 330 compatibility

// End dimension: discard sun and moon
void main() {
    discard;
}
